var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
/**
 * Core domain model.
 *
 * ONE master scenario object holds every user input. UI components never own a
 * second copy of a calculated value - they read from ScenarioOutputs, which is
 * produced by a single pure function (runScenario) in a one-direction chain.
 */
define("src/core/types", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
/** Date helpers. All dates are handled as ISO yyyy-mm-dd strings in UTC to keep
 *  the engine deterministic and timezone-proof. */
define("src/core/utils/dates", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.MONTH_NAMES = void 0;
    exports.toISO = toISO;
    exports.parseISO = parseISO;
    exports.isValidISO = isValidISO;
    exports.today = today;
    exports.endOfMonth = endOfMonth;
    exports.defaultClosingDate = defaultClosingDate;
    exports.perDiemDays = perDiemDays;
    exports.defaultFirstPaymentDate = defaultFirstPaymentDate;
    exports.monthLabel = monthLabel;
    exports.addDaysISO = addDaysISO;
    function toISO(date) {
        const y = date.getUTCFullYear();
        const m = `${date.getUTCMonth() + 1}`.padStart(2, '0');
        const d = `${date.getUTCDate()}`.padStart(2, '0');
        return `${y}-${m}-${d}`;
    }
    function parseISO(iso) {
        if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso))
            return null;
        const [y, m, d] = iso.split('-').map(Number);
        const date = new Date(Date.UTC(y, m - 1, d));
        if (date.getUTCFullYear() !== y ||
            date.getUTCMonth() !== m - 1 ||
            date.getUTCDate() !== d) {
            return null; // impossible date such as 2026-02-31
        }
        return date;
    }
    function isValidISO(iso) {
        return parseISO(iso) !== null;
    }
    function today() {
        return toISO(new Date());
    }
    /** Last calendar day of the month `offset` months after `iso`. */
    function endOfMonth(iso, offset = 0) {
        var _a;
        const base = (_a = parseISO(iso)) !== null && _a !== void 0 ? _a : new Date();
        const d = new Date(Date.UTC(base.getUTCFullYear(), base.getUTCMonth() + offset + 1, 0));
        return toISO(d);
    }
    /** Default estimated closing date: last calendar day of NEXT month. */
    function defaultClosingDate(asOf) {
        return endOfMonth(asOf, 1);
    }
    /** Per-diem days: closing date through the end of that month, inclusive. */
    function perDiemDays(closingISO) {
        const close = parseISO(closingISO);
        if (!close)
            return 0;
        const eom = parseISO(endOfMonth(closingISO, 0));
        if (!eom)
            return 0;
        const ms = eom.getTime() - close.getTime();
        return Math.max(0, Math.round(ms / 86400000) + 1);
    }
    /** First payment date convention: first day of the second month after closing. */
    function defaultFirstPaymentDate(closingISO) {
        const close = parseISO(closingISO);
        if (!close)
            return closingISO;
        const d = new Date(Date.UTC(close.getUTCFullYear(), close.getUTCMonth() + 2, 1));
        return toISO(d);
    }
    exports.MONTH_NAMES = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    function monthLabel(monthIndex1to12, year) {
        const idx = ((monthIndex1to12 - 1) % 12 + 12) % 12;
        return year ? `${exports.MONTH_NAMES[idx]} ${year}` : exports.MONTH_NAMES[idx];
    }
    function addDaysISO(iso, days) {
        const d = parseISO(iso);
        if (!d)
            return iso;
        d.setUTCDate(d.getUTCDate() + days);
        return toISO(d);
    }
});
define("src/core/defaults", ["require", "exports", "src/core/utils/dates"], function (require, exports, dates_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CONVENTIONAL_RATE_PREMIUM = exports.FHA_MIP_RATE_OPTIONS = exports.CLOSING_ROUNDING_OPTIONS = exports.PAYMENT_ROUNDING_OPTIONS = void 0;
    exports.defaultScenario = defaultScenario;
    exports.blankScenario = blankScenario;
    function borrowers() {
        return [1, 2, 3, 4].map((n) => ({
            name: `Borrower ${n}`,
            grossMonthlyIncome: 0,
            otherMonthlyIncome: 0,
            monthlyDebts: 0,
        }));
    }
    const NO_OVERRIDES = {
        lenderOrigination: null,
        lenderProcessing: null,
        appraisal: null,
        creditReport: null,
        floodTaxService: null,
        titleInsurance: null,
        titleSearchSettlement: null,
        attorney: null,
        survey: null,
        recording: null,
        inspections: null,
        other: null,
    };
    /** RESET DEFAULTS - the documented default scenario. */
    function defaultScenario(asOf = (0, dates_1.today)(), id = 'scenario-1') {
        const closingDate = (0, dates_1.defaultClosingDate)(asOf);
        return {
            id,
            name: 'Default scenario',
            borrowerName: '',
            propertyAddress: '',
            zipCode: '11530',
            asOfDate: asOf,
            closingDate,
            transactionType: 'Purchase',
            occupancy: 'Primary Residence',
            loanProgram: 'FHA',
            renovation: true,
            renovationScope: 'Auto',
            conventionalRatePremiumApplied: 0,
            state: 'New York',
            nyCounty: 'Nassau',
            isNYC: false,
            units: 1,
            creditScore: 660,
            fhaAreaSelection: 'Auto',
            basePurchasePrice: 500000,
            sellerConcessionPct: 0,
            sellerConcessionAmount: 0,
            concessionInputMode: 'percent',
            concessionIncreasesPrice: true,
            baseDownPaymentPct: 0.035,
            finalDownPaymentPct: 0.035,
            reno: {
                baseCost: 100000,
                architectural: 0,
                consultant: 2000,
                inspectionFees: 1875,
                titleUpdateFees: 375,
                permits: 0,
                feasibilityOther: 0,
                otherFinanceable: 0,
                contingencyPct: 0.1,
                utilitiesOff: false,
                supplementalOriginationOverride: 0,
                discountPointsRehabPct: 0,
                paymentReserveMonths: 0,
                energyImprovements: 0,
                syncDrawFees: false,
            },
            draws: {
                manualOverride: false,
                manualDrawCount: 5,
                inspectionFeePerDraw: 375,
                titleFeePerDraw: 75,
                initialMaterialRelease: 0,
            },
            ufmipRate: 0.0175,
            fhaAnnualMipRate: 0.0055,
            fhaMipOverrideRate: 0,
            pmiOverrideRate: 0,
            interestRate: 0.06875,
            termYears: 30,
            asIsValue: 0,
            afterRepairValue: 0,
            projection: { years: 5, appreciationRateOverride: 0 },
            propertyTaxAmount: 13000,
            propertyTaxBasis: 'Annual',
            insuranceAmount: 3000,
            insuranceBasis: 'Annual',
            taxInsuranceOverrideMonthly: 0,
            hoaMonthly: 0,
            taxSourceType: 'Manual',
            taxHasExemption: false,
            exemptionType: '',
            paymentRoundingIncrement: 50,
            closing: {
                overrides: { ...NO_OVERRIDES },
                originationPointsPct: 0.01,
                otherStateMortgageTaxRate: 0,
                taxPickupMonths: 6,
                insurancePickupMonths: 12,
                cushionPct: 0.1,
                roundingIncrement: 100,
                useAggregateEscrowForPrepaids: false,
                earnestMoneyDeposit: 0,
            },
            escrow: {
                firstPaymentDate: (0, dates_1.defaultFirstPaymentDate)(closingDate),
                autoFirstPaymentDate: true,
                annualFlood: 0,
                cushionMonthsOverride: -1,
                customDisbursements: [],
                useCustomDisbursements: false,
            },
            bps: {
                leadSource: 'Self Generated',
                bps: null,
                percent: null,
                dollars: null,
                loanAmountOverride: 0,
                cap: 35000,
            },
            borrowers: borrowers(),
            assets: { liquidAssets: 0, retirementOtherAssets: 0, giftFunds: 0 },
            rental: {
                mainUnit: { gross: 0, qualifyingPct: 0.75 },
                adu: { gross: 0, qualifyingPct: 0.75 },
                unit2: { gross: 0, qualifyingPct: 0.75 },
                unit3: { gross: 0, qualifyingPct: 0.75 },
                unit4: { gross: 0, qualifyingPct: 0.75 },
                propertyTypeOverride: 'Auto',
                includeVacatingRental: false,
                vacatingGrossRent: 0,
                vacatingQualifyingPct: 0.75,
                vacatingHousingExpense: 0,
            },
        };
    }
    /** CLEAR ALL - blanks every manually entered value, keeps the structure valid. */
    function blankScenario(asOf = (0, dates_1.today)(), id = 'scenario-1') {
        const base = defaultScenario(asOf, id);
        const closingDate = (0, dates_1.defaultClosingDate)(asOf);
        return {
            ...base,
            name: 'New scenario',
            zipCode: '',
            basePurchasePrice: 0,
            sellerConcessionPct: 0,
            sellerConcessionAmount: 0,
            baseDownPaymentPct: 0,
            finalDownPaymentPct: 0,
            creditScore: 0,
            closingDate,
            reno: {
                ...base.reno,
                baseCost: 0,
                consultant: 0,
                inspectionFees: 0,
                titleUpdateFees: 0,
                contingencyPct: 0,
                paymentReserveMonths: 0,
            },
            draws: { ...base.draws, initialMaterialRelease: 0 },
            fhaAnnualMipRate: 0,
            ufmipRate: 0,
            interestRate: 0,
            asIsValue: 0,
            afterRepairValue: 0,
            propertyTaxAmount: 0,
            insuranceAmount: 0,
            taxInsuranceOverrideMonthly: 0,
            hoaMonthly: 0,
            closing: {
                ...base.closing,
                overrides: { ...NO_OVERRIDES },
                originationPointsPct: 0,
                otherStateMortgageTaxRate: 0,
                taxPickupMonths: 0,
                insurancePickupMonths: 0,
                earnestMoneyDeposit: 0,
            },
            escrow: { ...base.escrow, firstPaymentDate: (0, dates_1.defaultFirstPaymentDate)(closingDate), annualFlood: 0 },
            bps: { ...base.bps, leadSource: 'Manual', bps: null, percent: null, dollars: null, loanAmountOverride: 0 },
            borrowers: borrowers(),
            assets: { liquidAssets: 0, retirementOtherAssets: 0, giftFunds: 0 },
        };
    }
    exports.PAYMENT_ROUNDING_OPTIONS = [25, 50, 100];
    exports.CLOSING_ROUNDING_OPTIONS = [100, 500, 1000];
    exports.FHA_MIP_RATE_OPTIONS = [0.0015, 0.0025, 0.005, 0.0055, 0.007, 0.0075, 0.0095];
    /** Rate premium applied when switching FHA -> Conventional (editable afterwards). */
    exports.CONVENTIONAL_RATE_PREMIUM = 0.00375;
});
/**
 * Reference-data metadata contract.
 *
 * ARCHITECTURE RULE: no changing regulatory rule may live inside a React
 * component. Everything that can change over time lives in this folder as a
 * versioned table row carrying an effective date, a source and a review date.
 */
define("src/core/data/meta", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PLANNING_DISCLAIMER = void 0;
    exports.effectiveRows = effectiveRows;
    /** Pick the row in effect on `asOf` from a list of dated rows. */
    function effectiveRows(rows, asOf) {
        return rows.filter((r) => {
            if (!r.meta)
                return true;
            if (r.meta.effectiveDate && r.meta.effectiveDate > asOf)
                return false;
            if (r.meta.expirationDate && r.meta.expirationDate < asOf)
                return false;
            return true;
        });
    }
    exports.PLANNING_DISCLAIMER = 'Planning estimate only. The purchase contract and the title/escrow preliminary closing statement are the final authority for transfer tax, mansion tax, mortgage tax, payer responsibility and fee amounts.';
});
define("src/core/data/stateClosingRules", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.STATE_CLOSING_RULES = void 0;
    exports.lookupClosingRule = lookupClosingRule;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'State closing / attorney reference (uploaded knowledge pack, State Closing Rules tab)',
        sourceUrl: 'https://www.docjacket.com/resources/attorney-vs-title-states',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'Confirm state-specific practice with local counsel or the title provider.',
    };
    const TITLE_NOTE = 'Title or escrow companies may handle the closing without required full attorney involvement.';
    const S = (state, closingMethod, earnestHolder, note, marital) => ({ state, closingMethod, earnestHolder, note, marital });
    exports.STATE_CLOSING_RULES = {
        id: 'state_closing_rules',
        title: 'State closing rules',
        description: 'Closing method, typical earnest-money holder, rule note and marital-property classification.',
        columns: [
            { key: 'state', label: 'State', type: 'text' },
            { key: 'closingMethod', label: 'Closing method', type: 'text' },
            { key: 'earnestHolder', label: 'Earnest holder', type: 'text' },
            { key: 'marital', label: 'Spousal / community', type: 'text' },
            { key: 'note', label: 'Rule note', type: 'text' },
        ],
        rows: [
            S('Alabama', 'Partial Attorney', 'Attorney or Title Company', 'Attorney prepares legal documents; title companies may perform searches and insurance.', 'Spousal State'),
            S('Alaska', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Arizona', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Community Property State'),
            S('Arkansas', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('California', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Community Property State'),
            S('Colorado', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Connecticut', 'Attorney Required', 'Attorney', 'Attorney must conduct the closing.', ''),
            S('Delaware', 'Attorney Required', 'Attorney', 'Attorney required for real estate closings.', ''),
            S('District of Columbia', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, ''),
            S('Florida', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Georgia', 'Attorney Required', 'Attorney', 'Attorney must control the closing from beginning to end.', ''),
            S('Hawaii', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, ''),
            S('Idaho', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Community Property State'),
            S('Illinois', 'Title / Escrow Company', 'Title Company, Broker, or Attorney', 'Chicago area commonly uses attorneys; title companies are common downstate.', 'Spousal State'),
            S('Indiana', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, ''),
            S('Iowa', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Kansas', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Kentucky', 'Attorney Required', 'Attorney', 'Attorney required for real estate closings.', 'Spousal State'),
            S('Louisiana', 'Partial Attorney', 'Attorney', 'Attorney examines and certifies title.', 'Community Property State'),
            S('Maine', 'Partial Attorney', 'Attorney or Title Company', 'Attorney required if the lender mandates a title search.', ''),
            S('Maryland', 'Partial Attorney', 'Attorney or Title Company', 'Attorney certifies deed and mortgage preparation.', ''),
            S('Massachusetts', 'Attorney Required', 'Attorney', 'Attorney conducts the closing; notaries cannot conduct closings.', 'Spousal State'),
            S('Michigan', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Minnesota', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Mississippi', 'Partial Attorney', 'Attorney', 'Attorney required for title examination.', 'Spousal State'),
            S('Missouri', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Montana', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Nebraska', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Nevada', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Community Property State'),
            S('New Hampshire', 'Attorney Required', 'Attorney', 'Attorney required for closing.', 'Spousal State'),
            S('New Jersey', 'Title / Escrow Company', 'Attorney or Title Company', 'Regional practice: attorneys are common in North Jersey; title companies common in South Jersey.', 'Spousal State'),
            S('New Mexico', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Community Property State'),
            S('New York', 'Attorney Required', 'Attorney', 'Attorney use is universally customary; the source notes it is not legally required.', ''),
            S('North Carolina', 'Attorney Required', 'Attorney', 'Attorney involvement is required for legal closing work.', 'Spousal State'),
            S('North Dakota', 'Partial Attorney', 'Attorney', 'Attorney required for title opinion.', 'Spousal State'),
            S('Ohio', 'Title / Escrow Company', 'Broker', TITLE_NOTE, 'Spousal State'),
            S('Oklahoma', 'Title / Escrow Company', 'Title Company', 'Title companies close; an attorney may be needed for some title work.', 'Spousal State'),
            S('Oregon', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, ''),
            S('Pennsylvania', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, ''),
            S('Rhode Island', 'Partial Attorney', 'Attorney', 'Attorney involvement required for specific closing tasks.', ''),
            S('South Carolina', 'Attorney Required', 'Attorney', 'Attorney required from start to finish.', ''),
            S('South Dakota', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Tennessee', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Spousal State'),
            S('Texas', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Community Property State'),
            S('Utah', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, ''),
            S('Vermont', 'Attorney Required', 'Attorney', 'Attorney required for real estate closings.', 'Spousal State'),
            S('Virginia', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, ''),
            S('Washington', 'Title / Escrow Company', 'Escrow Company', TITLE_NOTE, 'Community Property State'),
            S('West Virginia', 'Attorney Required', 'Attorney', 'Attorney required for closing.', 'Spousal State'),
            S('Wisconsin', 'Title / Escrow Company', 'Title Company', TITLE_NOTE, 'Community Property State'),
            S('Wyoming', 'Title / Escrow Company', 'Title Company', 'Attorney may examine title but is not required for closing.', 'Spousal State'),
        ],
        meta: META,
    };
    function lookupClosingRule(state, table = exports.STATE_CLOSING_RULES) {
        var _a;
        return (_a = table.rows.find((r) => r.state === state)) !== null && _a !== void 0 ? _a : null;
    }
});
define("src/core/data/transferTaxes", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NY_TRANSFER_TAX = exports.TRANSFER_TAX_TABLE = void 0;
    exports.lookupTransferTax = lookupTransferTax;
    exports.nyTransferTaxRate = nyTransferTaxRate;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'State transfer-tax planning table (uploaded State Tax & Escrow Reference, section 1)',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'Base state planning rates only. Counties and cities frequently add local transfer taxes that are NOT in this table.',
    };
    const R = (state, rate, payer, note = '') => ({
        state,
        rate,
        payer,
        buyerShare: payer === 'Buyer' ? 1 : payer === 'Split' ? 0.5 : 0,
        note,
    });
    exports.TRANSFER_TAX_TABLE = {
        id: 'state_transfer_taxes',
        title: 'State transfer taxes',
        description: 'Base state deed/transfer tax planning rate, typical payer and assumed buyer share.',
        columns: [
            { key: 'state', label: 'State', type: 'text' },
            { key: 'rate', label: 'Rate', type: 'percent' },
            { key: 'payer', label: 'Typical payer', type: 'text' },
            { key: 'buyerShare', label: 'Buyer share', type: 'percent' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: [
            R('Alabama', 0.001, 'Seller', 'No common local surcharge'),
            R('Alaska', null, 'None', 'No state/local transfer tax'),
            R('Arizona', null, 'None', 'No state transfer tax'),
            R('Arkansas', 0.0033, 'Seller', 'County may add'),
            R('California', 0.0011, 'Seller', 'Cities may add significantly'),
            R('Colorado', 0.0001, 'Seller', 'Minimal state rate'),
            R('Connecticut', 0.0075, 'Seller', 'Additional surcharge may apply'),
            R('Delaware', 0.02, 'Split', 'County additions can be significant'),
            R('District of Columbia', 0.0145, 'Split', 'Graduated'),
            R('Florida', 0.007, 'Seller', 'County surtax may apply'),
            R('Georgia', 0.001, 'Seller', ''),
            R('Hawaii', 0.001, 'Seller', 'Graduated local/state treatment'),
            R('Idaho', null, 'None', ''),
            R('Illinois', 0.001, 'Seller', 'Chicago adds local taxes'),
            R('Indiana', null, 'None', ''),
            R('Iowa', 0.0016, 'Seller', ''),
            R('Kansas', null, 'None', ''),
            R('Kentucky', 0.001, 'Seller', ''),
            R('Louisiana', null, 'None', ''),
            R('Maine', 0.0044, 'Split', ''),
            R('Maryland', 0.005, 'Split', 'County adds'),
            R('Massachusetts', 0.00456, 'Seller', 'Barnstable surcharge'),
            R('Michigan', 0.0075, 'Seller', 'County adds'),
            R('Minnesota', 0.0033, 'Seller', 'Deed tax; mortgage registry tax also relevant'),
            R('Mississippi', null, 'None', ''),
            R('Missouri', null, 'None', ''),
            R('Montana', null, 'None', ''),
            R('Nebraska', 0.00225, 'Seller', ''),
            R('Nevada', 0.0026, 'Seller', 'County surcharge varies'),
            R('New Hampshire', 0.015, 'Split', ''),
            R('New Jersey', 0.01, 'Seller', 'Buyer mansion tax at $1M+'),
            R('New Mexico', null, 'None', ''),
            R('New York', 0.004, 'Seller', 'NYC adds local transfer tax; 0.65% at/above $3M; buyer mansion tax $1M+'),
            R('North Carolina', 0.002, 'Seller', ''),
            R('North Dakota', null, 'None', ''),
            R('Ohio', 0.001, 'Seller', 'County may add'),
            R('Oklahoma', 0.0015, 'Seller', ''),
            R('Oregon', null, 'None', 'Local fees may apply'),
            R('Pennsylvania', 0.01, 'Split', 'Local municipality often adds'),
            R('Rhode Island', 0.0046, 'Seller', ''),
            R('South Carolina', 0.0037, 'Seller', ''),
            R('South Dakota', 0.0005, 'Seller', ''),
            R('Tennessee', 0.0037, 'Seller', 'County may add'),
            R('Texas', null, 'None', ''),
            R('Utah', null, 'None', ''),
            R('Vermont', 0.0125, 'Seller', 'Local additions may apply'),
            R('Virginia', 0.0025, 'Seller', 'Recordation tax may add'),
            R('Washington', 0.0128, 'Seller', 'REET is graduated'),
            R('West Virginia', 0.0011, 'Seller', 'County excise may add'),
            R('Wisconsin', 0.003, 'Seller', ''),
            R('Wyoming', null, 'None', ''),
        ],
        meta: META,
    };
    function lookupTransferTax(state, table = exports.TRANSFER_TAX_TABLE) {
        var _a;
        return (_a = table.rows.find((r) => r.state === state)) !== null && _a !== void 0 ? _a : null;
    }
    // ---------------------------------------------------------------------------
    // New York specifics
    // ---------------------------------------------------------------------------
    exports.NY_TRANSFER_TAX = {
        baseRate: 0.004,
        highPriceRate: 0.0065,
        highPriceThreshold: 3000000,
        nycRateUnder500k: 0.01,
        nycRate500kPlus: 0.01425,
        nycThreshold: 500000,
        meta: {
            effectiveDate: '2026-01-01',
            sourceName: 'NY State + NYC RPT planning rates (uploaded knowledge pack, Tax Tables I5:J6)',
            lastReviewed: '2026-01-01',
            confidence: 'planning-table',
            overrideAllowed: true,
        },
    };
    /** Combined NY (state + NYC where applicable) transfer-tax rate for a price. */
    function nyTransferTaxRate(price, isNYC) {
        const stateRate = price >= exports.NY_TRANSFER_TAX.highPriceThreshold
            ? exports.NY_TRANSFER_TAX.highPriceRate
            : exports.NY_TRANSFER_TAX.baseRate;
        const cityRate = isNYC
            ? price < exports.NY_TRANSFER_TAX.nycThreshold
                ? exports.NY_TRANSFER_TAX.nycRateUnder500k
                : exports.NY_TRANSFER_TAX.nycRate500kPlus
            : 0;
        return stateRate + cityRate;
    }
});
define("src/core/data/escrowRules", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ESCROW_RULES = exports.DEFAULT_CUSHION_MONTHS = void 0;
    exports.lookupEscrowRule = lookupEscrowRule;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'Aggregate escrow rules + state tax setup (uploaded State Tax & Escrow Reference, sections 4-5)',
        sourceUrl: 'https://www.consumerfinance.gov/rules-policy/regulations/1024/17/',
        lastReviewed: '2026-01-01',
        confidence: 'lender-guide',
        overrideAllowed: true,
        notes: 'RESPA permits a cushion of up to 1/6 of annual disbursements (2 months). Nebraska and Vermont are carried at 1 month in the supplied workflow.',
    };
    exports.DEFAULT_CUSHION_MONTHS = 2;
    const D = (state, jurisdiction, cushionMonths, taxStructure, taxDisbursementMonths, note = '') => ({
        state,
        jurisdiction,
        cushionMonths,
        taxStructure,
        taxDisbursementMonths,
        insuranceDisbursementMonth: 1,
        note,
    });
    exports.ESCROW_RULES = {
        id: 'escrow_rules',
        title: 'Escrow cushion + tax disbursement rules',
        description: 'State/jurisdiction -> cushion months, tax structure and disbursement months.',
        columns: [
            { key: 'state', label: 'State', type: 'text' },
            { key: 'jurisdiction', label: 'Jurisdiction', type: 'text' },
            { key: 'cushionMonths', label: 'Cushion months', type: 'number' },
            { key: 'taxStructure', label: 'Tax structure', type: 'text' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: [
            D('Nebraska', 'Nebraska', 1, 'Single annual tax line', [4, 8], 'State exception: 1-month cushion'),
            D('Vermont', 'Vermont', 1, 'Single annual tax line', [8], 'State exception: 1-month cushion'),
            D('New York', 'New York City', 2, 'Quarterly: July, October, January, April', [1, 4, 7, 10], 'NYC quarterly tax schedule'),
            D('New York', 'Nassau', 2, 'Separate General Tax and School Tax', [1, 10], 'General tax January, school tax October'),
            D('New York', 'Suffolk', 2, 'Single bill / two installments', [1, 5], 'Two-installment structure'),
            D('New York', 'New York', 2, 'County + town + school', [1, 9], 'Verify the town schedule'),
            D('Michigan', 'Michigan', 2, 'Summer and Winter taxes split', [7, 12], 'Summer July, winter December'),
            D('Pennsylvania', 'Pennsylvania', 2, 'County + Municipal + School separately', [3, 7], 'County/municipal spring, school summer'),
            D('Texas', 'Texas', 2, 'Combine taxing entities into one annual line', [12], 'Single combined annual disbursement'),
            D('California', 'California', 2, 'Two installments', [3, 11], 'March and November disbursement planning'),
            D('Florida', 'Florida', 2, 'Single annual tax line', [11], 'November payment planning (discount month)'),
            D('Tennessee', 'Tennessee', 2, 'Single annual tax line', [12], 'Year-end payment planning'),
            D('Wisconsin', 'Wisconsin', 2, 'Single annual tax line', [1], 'Year-end / early-payment planning'),
        ],
        meta: META,
    };
    function lookupEscrowRule(state, jurisdiction, isNYC, table = exports.ESCROW_RULES) {
        var _a;
        if (state === 'New York' && isNYC) {
            const nyc = (_a = table.rows.find((r) => r.jurisdiction === 'New York City')) !== null && _a !== void 0 ? _a : null;
            if (nyc)
                return { row: nyc, cushionMonths: nyc.cushionMonths, source: 'New York City rule' };
        }
        const exact = table.rows.find((r) => r.state === state && r.jurisdiction === jurisdiction);
        if (exact)
            return { row: exact, cushionMonths: exact.cushionMonths, source: `${jurisdiction} rule` };
        const stateRow = table.rows.find((r) => r.state === state && r.jurisdiction === state);
        if (stateRow)
            return { row: stateRow, cushionMonths: stateRow.cushionMonths, source: `${state} rule` };
        const anyStateRow = table.rows.find((r) => r.state === state);
        if (anyStateRow) {
            return { row: anyStateRow, cushionMonths: anyStateRow.cushionMonths, source: `${state} rule` };
        }
        return { row: null, cushionMonths: exports.DEFAULT_CUSHION_MONTHS, source: 'Default (all other states)' };
    }
});
define("src/core/data/marketData", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.MARKET_TABLE = void 0;
    exports.lookupMarket = lookupMarket;
    exports.lookupZip = lookupZip;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'State market planning assumptions (appreciation, effective tax rate, insurance)',
        lastReviewed: '2026-01-01',
        confidence: 'estimate',
        overrideAllowed: true,
        notes: 'PLANNING ESTIMATES ONLY. Appreciation is a forward assumption, not a forecast. Taxes must be confirmed with a tax certificate and insurance with a binder.',
    };
    const M = (state, appreciation, effectiveTaxRate, insurancePer1000, medianValue) => ({ state, appreciation, effectiveTaxRate, insurancePer1000, medianValue });
    exports.MARKET_TABLE = {
        id: 'state_market_assumptions',
        title: 'State market assumptions',
        description: 'Appreciation, effective tax rate, insurance rate and typical value by state.',
        columns: [
            { key: 'state', label: 'State', type: 'text' },
            { key: 'appreciation', label: 'Annual appreciation', type: 'percent' },
            { key: 'effectiveTaxRate', label: 'Effective tax rate', type: 'percent' },
            { key: 'insurancePer1000', label: 'Insurance / $1,000', type: 'number' },
            { key: 'medianValue', label: 'Typical value', type: 'currency' },
        ],
        rows: [
            M('Alabama', 0.035, 0.0041, 5.4, 245000),
            M('Alaska', 0.028, 0.0104, 4.2, 355000),
            M('Arizona', 0.038, 0.0063, 3.6, 425000),
            M('Arkansas', 0.034, 0.0062, 5.0, 215000),
            M('California', 0.041, 0.0071, 4.0, 760000),
            M('Colorado', 0.036, 0.0051, 4.4, 545000),
            M('Connecticut', 0.040, 0.0179, 4.2, 400000),
            M('Delaware', 0.035, 0.0058, 3.4, 355000),
            M('District of Columbia', 0.030, 0.0057, 4.0, 640000),
            M('Florida', 0.037, 0.0080, 7.4, 405000),
            M('Georgia', 0.038, 0.0083, 5.0, 335000),
            M('Hawaii', 0.030, 0.0028, 3.6, 840000),
            M('Idaho', 0.036, 0.0063, 3.4, 445000),
            M('Illinois', 0.033, 0.0208, 4.0, 265000),
            M('Indiana', 0.036, 0.0081, 3.6, 235000),
            M('Iowa', 0.032, 0.0149, 3.4, 215000),
            M('Kansas', 0.033, 0.0133, 4.6, 220000),
            M('Kentucky', 0.034, 0.0080, 4.2, 210000),
            M('Louisiana', 0.028, 0.0056, 8.2, 200000),
            M('Maine', 0.040, 0.0109, 4.0, 385000),
            M('Maryland', 0.034, 0.0105, 4.0, 415000),
            M('Massachusetts', 0.040, 0.0104, 4.4, 600000),
            M('Michigan', 0.034, 0.0138, 3.6, 235000),
            M('Minnesota', 0.032, 0.0102, 3.8, 330000),
            M('Mississippi', 0.030, 0.0065, 6.2, 175000),
            M('Missouri', 0.034, 0.0093, 4.4, 235000),
            M('Montana', 0.035, 0.0074, 4.2, 450000),
            M('Nebraska', 0.032, 0.0161, 4.4, 250000),
            M('Nevada', 0.037, 0.0048, 3.4, 440000),
            M('New Hampshire', 0.041, 0.0177, 3.8, 460000),
            M('New Jersey', 0.040, 0.0223, 3.8, 495000),
            M('New Mexico', 0.033, 0.0067, 4.0, 295000),
            M('New York', 0.038, 0.0140, 4.2, 460000),
            M('North Carolina', 0.039, 0.0073, 4.4, 330000),
            M('North Dakota', 0.029, 0.0097, 4.0, 255000),
            M('Ohio', 0.035, 0.0140, 3.6, 225000),
            M('Oklahoma', 0.032, 0.0083, 6.0, 200000),
            M('Oregon', 0.034, 0.0087, 4.0, 495000),
            M('Pennsylvania', 0.035, 0.0143, 3.6, 265000),
            M('Rhode Island', 0.041, 0.0130, 4.2, 465000),
            M('South Carolina', 0.038, 0.0053, 5.2, 300000),
            M('South Dakota', 0.031, 0.0114, 4.2, 290000),
            M('Tennessee', 0.038, 0.0056, 4.6, 310000),
            M('Texas', 0.034, 0.0158, 6.0, 305000),
            M('Utah', 0.036, 0.0057, 3.4, 525000),
            M('Vermont', 0.038, 0.0182, 3.8, 385000),
            M('Virginia', 0.035, 0.0080, 3.8, 395000),
            M('Washington', 0.036, 0.0087, 4.0, 605000),
            M('West Virginia', 0.030, 0.0057, 3.8, 165000),
            M('Wisconsin', 0.034, 0.0148, 3.4, 300000),
            M('Wyoming', 0.031, 0.0055, 4.4, 340000),
        ],
        meta: META,
    };
    function lookupMarket(state, table = exports.MARKET_TABLE) {
        var _a;
        return ((_a = table.rows.find((r) => r.state === state)) !== null && _a !== void 0 ? _a : M('Default', 0.035, 0.0100, 4.2, 350000));
    }
    const ZIP_RANGES = [
        { from: 5, to: 5, state: 'New York' }, // military
        { from: 6, to: 9, state: 'Puerto Rico / VI' },
        { from: 10, to: 27, state: 'Massachusetts' },
        { from: 28, to: 29, state: 'Rhode Island' },
        { from: 30, to: 38, state: 'New Hampshire' },
        { from: 39, to: 49, state: 'Maine' },
        { from: 50, to: 59, state: 'Vermont' },
        { from: 60, to: 69, state: 'Connecticut' },
        { from: 70, to: 89, state: 'New Jersey' },
        { from: 90, to: 98, state: 'New York' }, // APO/FPO
        { from: 100, to: 149, state: 'New York' },
        { from: 150, to: 196, state: 'Pennsylvania' },
        { from: 197, to: 199, state: 'Delaware' },
        { from: 200, to: 205, state: 'District of Columbia' },
        { from: 206, to: 219, state: 'Maryland' },
        { from: 220, to: 246, state: 'Virginia' },
        { from: 247, to: 268, state: 'West Virginia' },
        { from: 270, to: 289, state: 'North Carolina' },
        { from: 290, to: 299, state: 'South Carolina' },
        { from: 300, to: 319, state: 'Georgia' },
        { from: 320, to: 349, state: 'Florida' },
        { from: 350, to: 369, state: 'Alabama' },
        { from: 370, to: 385, state: 'Tennessee' },
        { from: 386, to: 397, state: 'Mississippi' },
        { from: 398, to: 399, state: 'Georgia' },
        { from: 400, to: 427, state: 'Kentucky' },
        { from: 430, to: 458, state: 'Ohio' },
        { from: 460, to: 479, state: 'Indiana' },
        { from: 480, to: 499, state: 'Michigan' },
        { from: 500, to: 528, state: 'Iowa' },
        { from: 530, to: 549, state: 'Wisconsin' },
        { from: 550, to: 567, state: 'Minnesota' },
        { from: 570, to: 577, state: 'South Dakota' },
        { from: 580, to: 588, state: 'North Dakota' },
        { from: 590, to: 599, state: 'Montana' },
        { from: 600, to: 629, state: 'Illinois' },
        { from: 630, to: 658, state: 'Missouri' },
        { from: 660, to: 679, state: 'Kansas' },
        { from: 680, to: 693, state: 'Nebraska' },
        { from: 700, to: 714, state: 'Louisiana' },
        { from: 716, to: 729, state: 'Arkansas' },
        { from: 730, to: 749, state: 'Oklahoma' },
        { from: 750, to: 799, state: 'Texas' },
        { from: 800, to: 816, state: 'Colorado' },
        { from: 820, to: 831, state: 'Wyoming' },
        { from: 832, to: 838, state: 'Idaho' },
        { from: 840, to: 847, state: 'Utah' },
        { from: 850, to: 865, state: 'Arizona' },
        { from: 870, to: 884, state: 'New Mexico' },
        { from: 889, to: 898, state: 'Nevada' },
        { from: 900, to: 961, state: 'California' },
        { from: 967, to: 968, state: 'Hawaii' },
        { from: 970, to: 979, state: 'Oregon' },
        { from: 980, to: 994, state: 'Washington' },
        { from: 995, to: 999, state: 'Alaska' },
    ];
    /** Metro refinements: ZIP3 -> label, county (where useful) and typical value. */
    const ZIP_METROS = {
        '100': { label: 'Manhattan, NY', county: 'New York', isNYC: true, value: 1250000 },
        '101': { label: 'Manhattan, NY', county: 'New York', isNYC: true, value: 1250000 },
        '102': { label: 'Manhattan, NY', county: 'New York', isNYC: true, value: 1250000 },
        '103': { label: 'Staten Island, NY', county: 'Richmond', isNYC: true, value: 680000 },
        '104': { label: 'Bronx, NY', county: 'Bronx', isNYC: true, value: 610000 },
        '105': { label: 'Westchester County, NY', county: 'Westchester', value: 760000 },
        '106': { label: 'Westchester County, NY', county: 'Westchester', value: 760000 },
        '107': { label: 'Westchester County, NY', county: 'Westchester', value: 760000 },
        '108': { label: 'Westchester County, NY', county: 'Westchester', value: 760000 },
        '109': { label: 'Rockland County, NY', county: 'Rockland', value: 640000 },
        '110': { label: 'Queens, NY', county: 'Queens', isNYC: true, value: 760000 },
        '111': { label: 'Queens, NY', county: 'Queens', isNYC: true, value: 760000 },
        '112': { label: 'Brooklyn, NY', county: 'Kings', isNYC: true, value: 900000 },
        '113': { label: 'Queens, NY', county: 'Queens', isNYC: true, value: 780000 },
        '114': { label: 'Queens, NY', county: 'Queens', isNYC: true, value: 780000 },
        '115': { label: 'Nassau County, NY', county: 'Nassau', value: 720000 },
        '116': { label: 'Queens / Nassau, NY', county: 'Nassau', value: 720000 },
        '117': { label: 'Suffolk County, NY', county: 'Suffolk', value: 620000 },
        '118': { label: 'Suffolk County, NY', county: 'Suffolk', value: 620000 },
        '119': { label: 'Suffolk County, NY', county: 'Suffolk', value: 660000 },
        '070': { label: 'Newark / Essex, NJ', value: 520000 },
        '076': { label: 'Bergen County, NJ', value: 640000 },
        '900': { label: 'Los Angeles, CA', value: 960000 },
        '941': { label: 'San Francisco, CA', value: 1300000 },
        '981': { label: 'Seattle, WA', value: 830000 },
        '022': { label: 'Boston, MA', value: 780000 },
        '331': { label: 'Miami, FL', value: 590000 },
        '787': { label: 'Austin, TX', value: 470000 },
        '750': { label: 'Dallas, TX', value: 420000 },
        '770': { label: 'Houston, TX', value: 350000 },
        '606': { label: 'Chicago, IL', value: 380000 },
        '802': { label: 'Denver, CO', value: 590000 },
        '303': { label: 'Atlanta, GA', value: 430000 },
        '852': { label: 'Phoenix, AZ', value: 460000 },
    };
    /**
     * lookupZip() - offline planning lookup. TEST FEATURE: it returns area-level
     * planning assumptions, never a property-specific value.
     */
    function lookupZip(zip) {
        var _a, _b, _c;
        const clean = String(zip !== null && zip !== void 0 ? zip : '').replace(/\D/g, '').slice(0, 5);
        const empty = {
            zip: clean,
            valid: false,
            state: '',
            county: '',
            isNYC: false,
            areaLabel: 'Enter a 5-digit ZIP code',
            typicalValue: 0,
            appreciation: 0,
            effectiveTaxRate: 0,
            estimatedAnnualTaxes: 0,
            estimatedAnnualInsurance: 0,
            source: 'ZIP prefix table (offline planning data)',
        };
        if (clean.length !== 5)
            return empty;
        const prefix = Number(clean.slice(0, 3));
        const range = ZIP_RANGES.find((r) => prefix >= r.from && prefix <= r.to);
        if (!range)
            return { ...empty, zip: clean, areaLabel: 'ZIP prefix not recognised' };
        const metro = ZIP_METROS[clean.slice(0, 3)];
        const market = lookupMarket(range.state);
        const typicalValue = (_a = metro === null || metro === void 0 ? void 0 : metro.value) !== null && _a !== void 0 ? _a : market.medianValue;
        return {
            zip: clean,
            valid: true,
            state: range.state,
            county: (_b = metro === null || metro === void 0 ? void 0 : metro.county) !== null && _b !== void 0 ? _b : '',
            isNYC: Boolean(metro === null || metro === void 0 ? void 0 : metro.isNYC),
            areaLabel: (_c = metro === null || metro === void 0 ? void 0 : metro.label) !== null && _c !== void 0 ? _c : `${range.state} (state average)`,
            typicalValue,
            appreciation: market.appreciation,
            effectiveTaxRate: market.effectiveTaxRate,
            estimatedAnnualTaxes: Math.round(typicalValue * market.effectiveTaxRate),
            estimatedAnnualInsurance: Math.round((typicalValue / 1000) * market.insurancePer1000),
            source: metro
                ? 'ZIP metro table + state market assumptions (offline planning data)'
                : 'ZIP prefix table + state market assumptions (offline planning data)',
        };
    }
});
/** Numeric helpers. Every engine entry point runs user input through `num()` so
 *  a NaN can never enter the calculation chain. */
define("src/core/utils/num", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.num = num;
    exports.nonNegative = nonNegative;
    exports.clamp = clamp;
    exports.round = round;
    exports.roundDownTo = roundDownTo;
    exports.roundUpTo = roundUpTo;
    exports.safeDivide = safeDivide;
    exports.sum = sum;
    exports.currency = currency;
    exports.percent = percent;
    function num(value, fallback = 0) {
        if (typeof value === 'number')
            return Number.isFinite(value) ? value : fallback;
        if (typeof value === 'string') {
            const cleaned = value.replace(/[$,%\s,]/g, '');
            if (cleaned === '' || cleaned === '-' || cleaned === '.')
                return fallback;
            const parsed = Number(cleaned);
            return Number.isFinite(parsed) ? parsed : fallback;
        }
        return fallback;
    }
    /** Clamp to >= 0. Used everywhere a negative amount would be nonsense. */
    function nonNegative(value) {
        const n = num(value);
        return n < 0 ? 0 : n;
    }
    function clamp(value, min, max) {
        const n = num(value);
        if (n < min)
            return min;
        if (n > max)
            return max;
        return n;
    }
    /** Round half away from zero at `dp` decimals (money-safe). */
    function round(value, dp = 2) {
        const n = num(value);
        const f = Math.pow(10, dp);
        return Math.sign(n) * Math.round(Math.abs(n) * f + Number.EPSILON) / f;
    }
    function roundDownTo(value, increment) {
        const inc = num(increment);
        if (inc <= 0)
            return num(value);
        return Math.floor(num(value) / inc) * inc;
    }
    function roundUpTo(value, increment) {
        const inc = num(increment);
        if (inc <= 0)
            return num(value);
        return Math.ceil(num(value) / inc) * inc;
    }
    function safeDivide(numerator, denominator, fallback = 0) {
        const d = num(denominator);
        if (d === 0)
            return fallback;
        return num(numerator) / d;
    }
    function sum(...values) {
        return values.reduce((acc, v) => acc + num(v), 0);
    }
    function currency(value, dp = 0) {
        const n = num(value);
        const abs = Math.abs(n).toLocaleString('en-US', {
            minimumFractionDigits: dp,
            maximumFractionDigits: dp,
        });
        return `${n < 0 ? '-' : ''}$${abs}`;
    }
    function percent(value, dp = 3) {
        return `${(num(value) * 100).toFixed(dp).replace(/\.?0+$/, '')}%`;
    }
});
define("src/core/calc/trace", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.text = exports.count = exports.pct = exports.money = exports.TraceCollector = void 0;
    /** Collects calculation traces so every output can explain itself in the UI. */
    class TraceCollector {
        constructor() {
            this.map = {};
        }
        add(trace) {
            this.map[trace.key] = trace;
            return trace.result;
        }
        record(key, label, formula, inputs, result, extra = {}) {
            return this.add({ key, label, formula, inputs, result, ...extra });
        }
        get() {
            return this.map;
        }
    }
    exports.TraceCollector = TraceCollector;
    const money = (label, value) => ({
        label,
        value,
        format: 'currency',
    });
    exports.money = money;
    const pct = (label, value) => ({
        label,
        value,
        format: 'percent',
    });
    exports.pct = pct;
    const count = (label, value) => ({
        label,
        value,
        format: 'number',
    });
    exports.count = count;
    const text = (label, value) => ({
        label,
        value,
        format: 'text',
    });
    exports.text = text;
});
define("src/core/calc/program", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculateProgram = calculateProgram;
    /**
     * calculateProgram()
     *   FHA          + Renovation Yes -> FHA 203(k)
     *   Conventional + Renovation Yes -> HomeStyle
     *   FHA          + Renovation No  -> FHA Purchase
     *   Conventional + Renovation No  -> Conventional Purchase
     *
     * The switches returned here are the ONLY thing the rest of the engine consults
     * when deciding whether an FHA-only or Conventional-only value applies. That is
     * what keeps FHA fields out of Conventional math and vice versa.
     */
    function calculateProgram(loanProgram, renovation) {
        const isFha = loanProgram === 'FHA';
        const code = isFha
            ? renovation
                ? 'FHA_203K'
                : 'FHA_PURCHASE'
            : renovation
                ? 'CONV_HOMESTYLE'
                : 'CONV_PURCHASE';
        const label = {
            FHA_203K: 'FHA 203(k)',
            FHA_PURCHASE: 'FHA Purchase',
            CONV_HOMESTYLE: 'Conventional HomeStyle',
            CONV_PURCHASE: 'Conventional Purchase',
        }[code];
        return {
            code,
            label,
            isFha,
            renovationActive: renovation,
            fhaLimitsEnabled: isFha,
            ufmipEnabled: isFha,
            fhaMipEnabled: isFha,
            pmiEnabled: !isFha,
            renovationProgramLabel: renovation ? (isFha ? '203(k)' : 'HomeStyle') : 'No Renovation',
        };
    }
});
define("src/core/data/concessionLimits", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CONCESSION_LIMIT_TABLE = exports.CONCESSION_LIMITS_META = exports.CONCESSION_LIMITS = void 0;
    exports.concessionLimitFor = concessionLimitFor;
    exports.CONCESSION_LIMITS = [
        {
            program: 'FHA',
            occupancy: 'Primary Residence',
            minLtv: 0,
            maxLtv: 1,
            limitPct: 0.06,
            note: 'FHA allows 6% at any LTV',
        },
        {
            program: 'FHA',
            occupancy: 'Second Home',
            minLtv: 0,
            maxLtv: 1,
            limitPct: 0.06,
            note: 'FHA allows 6% at any LTV',
        },
        {
            program: 'FHA',
            occupancy: 'Investment',
            minLtv: 0,
            maxLtv: 1,
            limitPct: 0.06,
            note: 'FHA allows 6% at any LTV',
        },
        {
            program: 'Conventional',
            occupancy: 'Primary Residence',
            minLtv: 0.9001,
            maxLtv: 1,
            limitPct: 0.03,
            note: 'Over 90% LTV - less than 10% down',
        },
        {
            program: 'Conventional',
            occupancy: 'Primary Residence',
            minLtv: 0.7501,
            maxLtv: 0.9,
            limitPct: 0.06,
            note: '75.01% - 90% LTV',
        },
        {
            program: 'Conventional',
            occupancy: 'Primary Residence',
            minLtv: 0,
            maxLtv: 0.75,
            limitPct: 0.09,
            note: '75% LTV or less',
        },
        {
            program: 'Conventional',
            occupancy: 'Second Home',
            minLtv: 0.9001,
            maxLtv: 1,
            limitPct: 0.03,
            note: 'Over 90% LTV - less than 10% down',
        },
        {
            program: 'Conventional',
            occupancy: 'Second Home',
            minLtv: 0.7501,
            maxLtv: 0.9,
            limitPct: 0.06,
            note: '75.01% - 90% LTV',
        },
        {
            program: 'Conventional',
            occupancy: 'Second Home',
            minLtv: 0,
            maxLtv: 0.75,
            limitPct: 0.09,
            note: '75% LTV or less',
        },
        {
            program: 'Conventional',
            occupancy: 'Investment',
            minLtv: 0,
            maxLtv: 1,
            limitPct: 0.02,
            note: 'Investment property - 2% at any LTV',
        },
    ];
    exports.CONCESSION_LIMITS_META = {
        effectiveDate: '2025-01-01',
        sourceName: 'HUD 4000.1 II.A.4.d / Fannie Mae B3-4.1-02 interested party contributions',
        sourceUrl: 'https://selling-guide.fanniemae.com/sel/b3-4.1-02/interested-party-contributions-ipcs',
        lastReviewed: '2025-01-01',
        confidence: 'official',
        overrideAllowed: true,
        notes: 'The limit is a percentage of the sales price and covers closing costs and prepaids only - it can never fund the down payment. A credit above the limit is not applied to cash to close.',
    };
    /**
     * The maximum usable seller concession for this scenario.
     *
     * `ltv` is the loan-to-value the file is heading for; the down payment
     * percentage is the practical stand-in on a purchase, which is what makes the
     * "less than 10% down" band read the way a loan officer expects.
     */
    function concessionLimitFor(program, occupancy, ltv) {
        const occ = occupancy === 'Second Home' ? 'Second Home' : occupancy === 'Investment' ? 'Investment' : 'Primary Residence';
        const clamped = Math.min(1, Math.max(0, ltv));
        const row = exports.CONCESSION_LIMITS.find((r) => r.program === program && r.occupancy === occ && clamped >= r.minLtv && clamped <= r.maxLtv);
        // The bands cover 0-100%, so this fallback only fires if a row is edited out.
        return (row !== null && row !== void 0 ? row : {
            program,
            occupancy: occ,
            minLtv: 0,
            maxLtv: 1,
            limitPct: 0.03,
            note: 'No matching band - the most restrictive limit is applied',
        });
    }
    /** The editable table shown on the ADVANCED tab. */
    exports.CONCESSION_LIMIT_TABLE = {
        id: 'concession_limits',
        title: 'Seller concession / interested-party limits',
        description: 'The most a seller may credit toward closing costs and prepaids, as a percentage of the sales price. A Conventional file under 10% down is held to 3%; FHA allows 6% at any LTV.',
        columns: [
            { key: 'program', label: 'Program', type: 'text' },
            { key: 'occupancy', label: 'Occupancy', type: 'text' },
            { key: 'minLtv', label: 'LTV from', type: 'percent' },
            { key: 'maxLtv', label: 'LTV to', type: 'percent' },
            { key: 'limitPct', label: 'Limit', type: 'percent' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: exports.CONCESSION_LIMITS,
        meta: exports.CONCESSION_LIMITS_META,
    };
});
define("src/core/calc/purchase", ["require", "exports", "src/core/utils/num", "src/core/data/concessionLimits", "src/core/calc/trace"], function (require, exports, num_1, concessionLimits_1, trace_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculateSellerConcession = calculateSellerConcession;
    exports.calculatePurchase = calculatePurchase;
    exports.minimumDownPaymentPct = minimumDownPaymentPct;
    /**
     * calculateSellerConcession()
     *   percent mode -> $ = Base Purchase Price x %
     *   dollar mode  -> % = $ / Base Purchase Price
     *
     * Exactly one direction runs per call (driven by concessionInputMode), so the
     * two fields can stay synchronised without a circular dependency.
     */
    function calculateSellerConcession(inputs) {
        const base = (0, num_1.nonNegative)(inputs.basePurchasePrice);
        if (inputs.concessionInputMode === 'dollar') {
            const amount = (0, num_1.nonNegative)(inputs.sellerConcessionAmount);
            return { amount, percent: (0, num_1.safeDivide)(amount, base, 0) };
        }
        const percent = (0, num_1.nonNegative)(inputs.sellerConcessionPct);
        return { amount: (0, num_1.round)(base * percent, 2), percent };
    }
    /** calculatePurchasePrice() + calculateDownPayment(). */
    function calculatePurchase(inputs, trace) {
        const basePurchasePrice = (0, num_1.nonNegative)(inputs.basePurchasePrice);
        const { amount: sellerConcessionAmount, percent: sellerConcessionPct } = calculateSellerConcession(inputs);
        const finalPurchasePrice = inputs.concessionIncreasesPrice
            ? basePurchasePrice + sellerConcessionAmount
            : basePurchasePrice;
        const baseDownPaymentPct = (0, num_1.nonNegative)(inputs.baseDownPaymentPct);
        const finalDownPaymentPct = (0, num_1.nonNegative)(inputs.finalDownPaymentPct);
        const baseDownPayment = (0, num_1.round)(basePurchasePrice * baseDownPaymentPct, 2);
        const finalDownPayment = (0, num_1.round)(finalPurchasePrice * finalDownPaymentPct, 2);
        const downPaymentDifference = (0, num_1.round)(finalDownPayment - baseDownPayment, 2);
        // Interested-party contribution ceiling. The LTV band is keyed on the down
        // payment, so a Conventional file under 10% down is held to 3% of the price.
        const limitRow = (0, concessionLimits_1.concessionLimitFor)(inputs.loanProgram === 'FHA' ? 'FHA' : 'Conventional', inputs.occupancy, 1 - finalDownPaymentPct);
        const sellerConcessionLimit = (0, num_1.round)(finalPurchasePrice * limitRow.limitPct, 2);
        const sellerConcessionAllowed = Math.min(sellerConcessionAmount, sellerConcessionLimit);
        const sellerConcessionOverLimit = (0, num_1.round)(Math.max(0, sellerConcessionAmount - sellerConcessionLimit), 2);
        trace.record('sellerConcession', 'Seller concession', inputs.concessionInputMode === 'dollar'
            ? 'Seller Concession % = Seller Concession $ / Base Purchase Price'
            : 'Seller Concession $ = Base Purchase Price x Seller Concession %', [(0, trace_1.money)('Base purchase price', basePurchasePrice), (0, trace_1.pct)('Seller concession %', sellerConcessionPct)], sellerConcessionAmount, {
            resultFormat: 'currency',
            notes: [
                inputs.concessionInputMode === 'dollar'
                    ? 'Dollar amount is the entered value; the percentage is derived.'
                    : 'Percentage is the entered value; the dollar amount is derived.',
            ],
        });
        trace.record('finalPurchasePrice', 'Final purchase price', inputs.concessionIncreasesPrice
            ? 'Final Purchase Price = Base Purchase Price + Seller Concession'
            : 'Final Purchase Price = Base Purchase Price (credit paid out of the agreed price)', [(0, trace_1.money)('Base purchase price', basePurchasePrice), (0, trace_1.money)('Seller concession', sellerConcessionAmount)], finalPurchasePrice, { resultFormat: 'currency' });
        trace.record('baseDownPayment', 'Base down payment', 'Base Down Payment = Base Purchase Price x Base Down Payment %', [(0, trace_1.money)('Base purchase price', basePurchasePrice), (0, trace_1.pct)('Base down payment %', baseDownPaymentPct)], baseDownPayment, { resultFormat: 'currency' });
        trace.record('finalDownPayment', 'Final down payment', 'Final Down Payment = Final Purchase Price x Final Down Payment %', [(0, trace_1.money)('Final purchase price', finalPurchasePrice), (0, trace_1.pct)('Final down payment %', finalDownPaymentPct)], finalDownPayment, { resultFormat: 'currency' });
        trace.record('downPaymentDifference', 'Down payment difference', 'Difference = Final Down Payment - Base Down Payment', [(0, trace_1.money)('Final down payment', finalDownPayment), (0, trace_1.money)('Base down payment', baseDownPayment)], downPaymentDifference, { resultFormat: 'currency' });
        return {
            basePurchasePrice,
            sellerConcessionPct,
            sellerConcessionAmount,
            sellerConcessionLimitPct: limitRow.limitPct,
            sellerConcessionLimit,
            sellerConcessionAllowed,
            sellerConcessionOverLimit,
            concessionLimitNote: `${limitRow.program} ${limitRow.occupancy.toLowerCase()} - ${limitRow.note}`,
            finalPurchasePrice,
            baseDownPayment,
            finalDownPayment,
            downPaymentDifference,
        };
    }
    /** Program minimum down payment for the warning engine. */
    function minimumDownPaymentPct(isFha, renovationActive, units) {
        if (isFha)
            return 0.035;
        // Conventional planning minimums: 5% for renovation, 3% for a 1-unit purchase.
        if (renovationActive)
            return 0.05;
        return (0, num_1.num)(units) > 1 ? 0.15 : 0.03;
    }
});
define("src/core/data/renovationRules", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.FHA_203K_ARV_FACTOR = exports.HOMESTYLE_MAX_LTV = exports.FEE_RULES = exports.DRAW_MILESTONES = exports.DRAW_RULES = void 0;
    exports.suggestDrawCount = suggestDrawCount;
    exports.supplementalOriginationFee = supplementalOriginationFee;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'Renovation draw planning bands (uploaded 203(k) / HomeStyle Reference, section 3)',
        lastReviewed: '2026-01-01',
        confidence: 'lender-guide',
        overrideAllowed: true,
        notes: 'Draw counts are PLANNING suggestions, not permanent agency rules. Cross-check contractor milestones and current lender guidance.',
    };
    exports.DRAW_RULES = {
        id: 'renovation_draw_rules',
        title: 'Renovation draw rules',
        description: 'Repair volume band -> suggested and maximum draw count.',
        columns: [
            { key: 'program', label: 'Program', type: 'text' },
            { key: 'band', label: 'Repair band', type: 'text' },
            { key: 'suggestedDraws', label: 'Suggested draws', type: 'number' },
            { key: 'maxDraws', label: 'Max draws', type: 'number' },
            { key: 'initialReleaseRule', label: 'Initial release', type: 'text' },
        ],
        rows: [
            { program: 'Both', band: 'Under $35,000', minRepair: 0, maxRepair: 34999.99, suggestedDraws: 2, maxDraws: 2, initialReleaseRule: 'Limited / streamline style: material release only where allowed' },
            { program: 'Both', band: '$35,000 - $75,000', minRepair: 35000, maxRepair: 75000, suggestedDraws: 3, maxDraws: 4, initialReleaseRule: 'Initial material release permitted per lender overlay' },
            { program: 'Both', band: 'Over $75,000', minRepair: 75000.01, maxRepair: Number.MAX_SAFE_INTEGER, suggestedDraws: 5, maxDraws: 5, initialReleaseRule: 'Initial material release permitted per lender overlay' },
        ],
        meta: META,
    };
    exports.DRAW_MILESTONES = [
        'Initial / material release',
        'Demolition',
        'Foundation / framing',
        'Rough mechanicals (plumbing, electrical, HVAC)',
        'Drywall',
        'Finish work',
        'Final / completion',
    ];
    function suggestDrawCount(repairAmount, table = exports.DRAW_RULES) {
        var _a;
        const row = (_a = table.rows.find((r) => repairAmount >= r.minRepair && repairAmount <= r.maxRepair)) !== null && _a !== void 0 ? _a : null;
        if (!row)
            return { suggested: 1, maxDraws: 5, row: null };
        return { suggested: row.suggestedDraws, maxDraws: row.maxDraws, row };
    }
    exports.FEE_RULES = {
        id: 'fee_rules',
        title: 'Renovation fee rules',
        description: 'Default, range and financeability for each renovation fee line.',
        columns: [
            { key: 'program', label: 'Program', type: 'text' },
            { key: 'feeType', label: 'Fee', type: 'text' },
            { key: 'defaultAmount', label: 'Default', type: 'currency' },
            { key: 'financeable', label: 'Financeable', type: 'boolean' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: [
            { program: 'FHA 203(k)', feeType: '203(k) consultant fee', defaultAmount: 2000, min: 0, max: 6000, financeable: true, note: 'Not applicable to limited/streamline 203(k)' },
            { program: 'Both', feeType: 'Draw inspection fee (per draw)', defaultAmount: 375, min: 0, max: 1000, financeable: true, note: 'Multiply by the draw count' },
            { program: 'Both', feeType: 'Title update fee (per draw)', defaultAmount: 75, min: 0, max: 250, financeable: true, note: 'Multiply by the draw count' },
            { program: 'Both', feeType: 'Permit fees', defaultAmount: 0, min: 0, max: 100000, financeable: true, note: 'Local building permits' },
            { program: 'Both', feeType: 'Architectural / engineering', defaultAmount: 0, min: 0, max: 100000, financeable: true, note: 'Structural plans / professional design' },
            { program: 'FHA 203(k)', feeType: 'Supplemental origination fee', defaultAmount: 0, min: 0, max: 100000, financeable: true, note: 'HUD-92700 line B11: greater of $350 or 1.5% of the B10 sub-total' },
            { program: 'Both', feeType: 'Contingency reserve', defaultAmount: 0.1, min: 0.1, max: 0.2, financeable: true, note: 'HUD-92700 line B2: 10% to 20% of repair costs' },
        ],
        meta: {
            effectiveDate: '2026-01-01',
            sourceName: 'HUD-92700 maximum mortgage worksheet + uploaded renovation reference',
            sourceUrl: 'https://www.hud.gov/sites/documents/92700.PDF',
            lastReviewed: '2026-01-01',
            confidence: 'official',
            overrideAllowed: true,
        },
    };
    /** HUD-92700 line B11: supplemental origination fee = greater of $350 or 1.5%. */
    function supplementalOriginationFee(subTotalB10) {
        return Math.max(350, subTotalB10 * 0.015);
    }
    /**
     * HomeStyle is limited by LOAN-TO-VALUE against the as-completed value, not by
     * a percentage of value the way FHA 203(k) is.
     *
     *   FHA 203(k)  value basis is capped at 110% of the after-repair value
     *   HomeStyle   the loan itself is capped at 95% of the as-completed value
     *
     * So a HomeStyle borrower putting 3% down is still held to 95% LTV, and the
     * minimum ARV the file needs is the loan divided by 0.95.
     */
    exports.HOMESTYLE_MAX_LTV = 0.95;
    /** FHA 203(k) value ceiling, expressed against the after-repair value. */
    exports.FHA_203K_ARV_FACTOR = 1.1;
});
define("src/core/calc/renovation", ["require", "exports", "src/core/data/renovationRules", "src/core/utils/num", "src/core/calc/trace"], function (require, exports, renovationRules_1, num_2, trace_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculateRenovation = calculateRenovation;
    /** Draw stage templates. Each draw is a named construction stage. */
    const STAGE_TEMPLATES = {
        1: [{ stage: 'Completion / final release', share: 1 }],
        2: [
            { stage: 'Initial / material release', share: 0.5 },
            { stage: 'Completion / final release', share: 0.5 },
        ],
        3: [
            { stage: 'Demolition & structural', share: 0.4 },
            { stage: 'Rough mechanicals & drywall', share: 0.35 },
            { stage: 'Finish work & final', share: 0.25 },
        ],
        4: [
            { stage: 'Initial / material release', share: 0.25 },
            { stage: 'Demolition, foundation & framing', share: 0.3 },
            { stage: 'Rough mechanicals & drywall', share: 0.25 },
            { stage: 'Finish work & final', share: 0.2 },
        ],
        5: [
            { stage: 'Initial / material release', share: 0.2 },
            { stage: 'Demolition & framing', share: 0.2 },
            { stage: 'Rough mechanicals (plumbing, electrical, HVAC)', share: 0.2 },
            { stage: 'Drywall & interior', share: 0.2 },
            { stage: 'Finish work & final', share: 0.2 },
        ],
        6: [
            { stage: 'Initial / material release', share: 0.15 },
            { stage: 'Demolition', share: 0.15 },
            { stage: 'Foundation & framing', share: 0.2 },
            { stage: 'Rough mechanicals', share: 0.2 },
            { stage: 'Drywall & interior', share: 0.15 },
            { stage: 'Finish work & final', share: 0.15 },
        ],
        7: [
            { stage: 'Initial / material release', share: 0.14 },
            { stage: 'Demolition', share: 0.13 },
            { stage: 'Foundation & framing', share: 0.16 },
            { stage: 'Rough mechanicals', share: 0.17 },
            { stage: 'Drywall', share: 0.14 },
            { stage: 'Finish work', share: 0.14 },
            { stage: 'Final / completion', share: 0.12 },
        ],
    };
    function stagesFor(drawCount) {
        if (drawCount <= 0)
            return [];
        const template = STAGE_TEMPLATES[drawCount];
        if (template)
            return template;
        const even = 1 / drawCount;
        return Array.from({ length: drawCount }, (_, i) => ({
            stage: i === 0 ? 'Initial / material release' : i === drawCount - 1 ? 'Final / completion' : `Construction stage ${i + 1}`,
            share: even,
        }));
    }
    /**
     * calculateRenovation() - HUD-92700 aligned renovation budget.
     *
     *   B1  base construction              B6  architectural
     *   B2  contingency reserve            B7  consultant
     *   B3  inspections + title updates    B8  permits
     *   B4  mortgage payments escrowed     B9  other fees
     *   B5  = B1..B4  (rehabilitation escrow)
     *   B10 = B5 + B6..B9
     *   B11 supplemental origination = MAX($350, 1.5% x B10)   <- auto, synced
     *   B12 discount points on rehab = B10 x points %          <- auto, synced
     *   B13 = B6..B9 + B11 + B12   (released at closing)
     *   B14 = B5 + B13 - A6        (total rehabilitation cost)
     *
     * When renovation is OFF every output is $0; the saved inputs are untouched.
     */
    function calculateRenovation(inputs, renovationActive, paymentReserveAmount, trace) {
        const r = inputs.reno;
        const baseCost = (0, num_2.nonNegative)(r.baseCost);
        const contingencyPct = (0, num_2.nonNegative)(r.contingencyPct);
        const suggestedContingencyPct = r.utilitiesOff ? 0.2 : 0.1;
        const { suggested } = (0, renovationRules_1.suggestDrawCount)(baseCost);
        const drawCount = inputs.draws.manualOverride
            ? Math.round((0, num_2.clamp)(inputs.draws.manualDrawCount, 0, 12))
            : suggested;
        const expectedInspectionFees = (0, num_2.round)(drawCount * (0, num_2.nonNegative)(inputs.draws.inspectionFeePerDraw), 2);
        const expectedTitleFees = (0, num_2.round)(drawCount * (0, num_2.nonNegative)(inputs.draws.titleFeePerDraw), 2);
        const inspectionFees = r.syncDrawFees ? expectedInspectionFees : (0, num_2.nonNegative)(r.inspectionFees);
        const titleUpdateFees = r.syncDrawFees ? expectedTitleFees : (0, num_2.nonNegative)(r.titleUpdateFees);
        if (!renovationActive) {
            return {
                active: false,
                baseCost: 0,
                contingencyReserve: 0,
                suggestedContingencyPct,
                inspectionFees: 0,
                titleUpdateFees: 0,
                rehabEscrowSubtotal: 0,
                subtotalB10: 0,
                supplementalOrigination: 0,
                discountPointsRehab: 0,
                releasedAtClosing: 0,
                paymentReserve: 0,
                energyImprovements: 0,
                finalRenovationAmount: 0,
                escrowHoldback: 0,
                softCosts: 0,
                suggestedDrawCount: suggested,
                drawCount: 0,
                expectedInspectionFees: 0,
                expectedTitleFees: 0,
                drawSchedule: [],
                initialMaterialRelease: 0,
            };
        }
        const contingencyReserve = (0, num_2.round)(baseCost * contingencyPct, 2);
        const paymentReserve = (0, num_2.nonNegative)(paymentReserveAmount);
        // B5
        const rehabEscrowSubtotal = (0, num_2.round)((0, num_2.sum)(baseCost, contingencyReserve, inspectionFees, titleUpdateFees, paymentReserve), 2);
        const architectural = (0, num_2.nonNegative)(r.architectural);
        const consultant = (0, num_2.nonNegative)(r.consultant);
        const permits = (0, num_2.nonNegative)(r.permits);
        const otherFees = (0, num_2.round)((0, num_2.nonNegative)(r.feasibilityOther) + (0, num_2.nonNegative)(r.otherFinanceable), 2);
        // B10
        const subtotalB10 = (0, num_2.round)(rehabEscrowSubtotal + architectural + consultant + permits + otherFees, 2);
        // B11 - auto unless overridden
        const supplementalOrigination = (0, num_2.nonNegative)(r.supplementalOriginationOverride) > 0
            ? (0, num_2.nonNegative)(r.supplementalOriginationOverride)
            : subtotalB10 <= 0
                ? 0 // no rehabilitation budget -> no supplemental origination fee
                : (0, num_2.round)(Math.max(350, subtotalB10 * 0.015), 2);
        // B12
        const discountPointsRehab = (0, num_2.round)(subtotalB10 * (0, num_2.nonNegative)(r.discountPointsRehabPct), 2);
        // B13
        const releasedAtClosing = (0, num_2.round)(architectural + consultant + permits + otherFees + supplementalOrigination + discountPointsRehab, 2);
        const energyImprovements = (0, num_2.nonNegative)(r.energyImprovements);
        // B14
        const finalRenovationAmount = Math.max(0, (0, num_2.round)(rehabEscrowSubtotal + releasedAtClosing - energyImprovements, 2));
        // ---- draw schedule ------------------------------------------------------
        const stages = stagesFor(drawCount);
        let cumulative = 0;
        const drawSchedule = stages.map((s, i) => {
            const releaseAmount = (0, num_2.round)(baseCost * s.share, 2);
            cumulative = (0, num_2.round)(cumulative + releaseAmount, 2);
            return {
                draw: i + 1,
                stage: s.stage,
                scopeShare: s.share,
                releaseAmount,
                inspectionFee: (0, num_2.nonNegative)(inputs.draws.inspectionFeePerDraw),
                titleFee: (0, num_2.nonNegative)(inputs.draws.titleFeePerDraw),
                cumulativeRelease: cumulative,
                remainingHoldback: Math.max(0, (0, num_2.round)(rehabEscrowSubtotal - cumulative, 2)),
            };
        });
        if (trace) {
            trace.record('contingencyReserve', 'Contingency reserve (B2)', 'Contingency = Base Renovation x Contingency %', [(0, trace_2.money)('Base renovation', baseCost), (0, trace_2.pct)('Contingency %', contingencyPct)], contingencyReserve, {
                resultFormat: 'currency',
                notes: [`Suggested contingency with utilities ${r.utilitiesOff ? 'off' : 'on'}: ${(suggestedContingencyPct * 100).toFixed(0)}%`],
            });
            trace.record('drawInspectionFees', 'Draw inspection fees (B3)', 'Inspection Fees = Number of Draws x Inspection Fee per Draw', [(0, trace_2.count)('Draws', drawCount), (0, trace_2.money)('Fee per draw', inputs.draws.inspectionFeePerDraw)], inspectionFees, {
                resultFormat: 'currency',
                overridesApplied: r.syncDrawFees ? [] : ['Manually entered total (not synced to the draw planner)'],
            });
            trace.record('drawTitleFees', 'Title update fees (B3)', 'Title Update Fees = Number of Draws x Title Update Fee per Draw', [(0, trace_2.count)('Draws', drawCount), (0, trace_2.money)('Fee per draw', inputs.draws.titleFeePerDraw)], titleUpdateFees, {
                resultFormat: 'currency',
                overridesApplied: r.syncDrawFees ? [] : ['Manually entered total (not synced to the draw planner)'],
            });
            trace.record('supplementalOrigination', 'Supplemental origination fee (B11)', 'B11 = MAX($350, 1.5% x B10 sub-total)', [(0, trace_2.money)('B10 sub-total', subtotalB10)], supplementalOrigination, {
                resultFormat: 'currency',
                overridesApplied: (0, num_2.nonNegative)(r.supplementalOriginationOverride) > 0 ? ['Manual override in use'] : [],
                notes: ['Recalculates automatically whenever any renovation cost changes.'],
            });
            trace.record('finalRenovationAmount', 'Total rehabilitation cost (B14)', 'B14 = B5 (rehab escrow) + B13 (released at closing) - A6 (energy improvements)', [
                (0, trace_2.money)('B1 base construction', baseCost),
                (0, trace_2.money)('B2 contingency reserve', contingencyReserve),
                (0, trace_2.money)('B3 inspections + title updates', (0, num_2.round)(inspectionFees + titleUpdateFees, 2)),
                (0, trace_2.money)('B4 mortgage payments escrowed', paymentReserve),
                (0, trace_2.money)('B5 rehabilitation escrow', rehabEscrowSubtotal),
                (0, trace_2.money)('B6 architectural / engineering', architectural),
                (0, trace_2.money)('B7 consultant', consultant),
                (0, trace_2.money)('B8 permits', permits),
                (0, trace_2.money)('B9 other fees', otherFees),
                (0, trace_2.money)('B11 supplemental origination', supplementalOrigination),
                (0, trace_2.money)('B12 discount points on rehab', discountPointsRehab),
                (0, trace_2.money)('A6 energy improvements', energyImprovements),
            ], finalRenovationAmount, {
                resultFormat: 'currency',
                notes: [
                    `B10 sub-total ${subtotalB10.toFixed(2)}; B13 released at closing ${releasedAtClosing.toFixed(2)}.`,
                    'Energy improvements are financed separately and added to the acquisition basis.',
                ],
            });
        }
        return {
            active: true,
            baseCost,
            contingencyReserve,
            suggestedContingencyPct,
            inspectionFees,
            titleUpdateFees,
            rehabEscrowSubtotal,
            subtotalB10,
            supplementalOrigination,
            discountPointsRehab,
            releasedAtClosing,
            paymentReserve,
            energyImprovements,
            finalRenovationAmount,
            escrowHoldback: rehabEscrowSubtotal,
            softCosts: (0, num_2.round)(architectural + consultant + permits + otherFees, 2),
            suggestedDrawCount: suggested,
            drawCount,
            expectedInspectionFees,
            expectedTitleFees,
            drawSchedule,
            initialMaterialRelease: inputs.loanProgram === 'Conventional' ? (0, num_2.nonNegative)(inputs.draws.initialMaterialRelease) : 0,
        };
    }
});
define("src/core/data/fhaLimits", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.HIGH_COST_AREAS = exports.FHA_LIMIT_TABLE = exports.FHA_NATIONAL_TIERS = void 0;
    exports.fhaStandardFloor = fhaStandardFloor;
    exports.lookupFhaLimit = lookupFhaLimit;
    exports.suggestFhaTier = suggestFhaTier;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: '2026 FHA loan limit reference (uploaded knowledge pack, FHA Limits 2026 tab)',
        sourceUrl: 'https://entp.hud.gov/idapp/html/hicostlook.cfm',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'National tier fallbacks. Production deployments should replace these rows with the exact HUD county table; the loader contract is unchanged.',
    };
    /** 2026 national tiers - the fallback when an exact county row is absent. */
    exports.FHA_NATIONAL_TIERS = {
        Standard: [541287, 693050, 837700, 1041125],
        'High-Cost': [1249125, 1599375, 1933200, 2402625],
        'Special Exception': [1873687, 2399050, 2899800, 3603925],
    };
    function tierRow(state, tier, area) {
        const t = exports.FHA_NATIONAL_TIERS[tier];
        return { state, area, tier, unit1: t[0], unit2: t[1], unit3: t[2], unit4: t[3] };
    }
    /** States whose 2026 reference table carries a high-cost row. */
    const HIGH_COST_STATES = [
        'Arizona', 'California', 'Colorado', 'Connecticut', 'District of Columbia',
        'Florida', 'Idaho', 'Illinois', 'Maryland', 'Massachusetts', 'Nevada',
        'New Hampshire', 'New Jersey', 'New York', 'North Carolina', 'Oregon',
        'Pennsylvania', 'Rhode Island', 'Tennessee', 'Texas', 'Utah', 'Virginia',
        'Washington', 'West Virginia', 'Wyoming',
    ];
    const SPECIAL_EXCEPTION_STATES = ['Alaska', 'Hawaii'];
    const ALL_STATES = [
        'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
        'Connecticut', 'Delaware', 'District of Columbia', 'Florida', 'Georgia',
        'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky',
        'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
        'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
        'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
        'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
        'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
        'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming',
    ];
    const rows = [];
    for (const state of ALL_STATES) {
        if (SPECIAL_EXCEPTION_STATES.includes(state)) {
            rows.push(tierRow(state, 'Special Exception', 'Special exception area limits (verify by county)'));
            rows.push(tierRow(state, 'Standard', 'All other counties'));
            continue;
        }
        rows.push(tierRow(state, 'Standard', 'All other counties'));
        if (HIGH_COST_STATES.includes(state)) {
            rows.push(tierRow(state, 'High-Cost', 'High-cost counties (varies by county)'));
        }
    }
    // Every state may in principle need a special-exception override row.
    for (const state of ALL_STATES) {
        if (!SPECIAL_EXCEPTION_STATES.includes(state)) {
            rows.push(tierRow(state, 'Special Exception', 'Special exception (manual selection only)'));
        }
    }
    exports.FHA_LIMIT_TABLE = {
        id: 'fha_loan_limits',
        title: 'FHA loan limits',
        description: 'State + area tier + unit count -> applicable FHA limit. Replace with the exact HUD county table in production.',
        columns: [
            { key: 'state', label: 'State', type: 'text' },
            { key: 'tier', label: 'Tier', type: 'text' },
            { key: 'area', label: 'Area', type: 'text' },
            { key: 'unit1', label: '1-Unit', type: 'currency' },
            { key: 'unit2', label: '2-Unit', type: 'currency' },
            { key: 'unit3', label: '3-Unit', type: 'currency' },
            { key: 'unit4', label: '4-Unit', type: 'currency' },
        ],
        rows,
        meta: META,
    };
    /** Counties/areas the reference pack flags as high-cost planning areas. */
    exports.HIGH_COST_AREAS = {
        'New York': [
            'Nassau', 'Suffolk', 'Westchester', 'Westchester - Yonkers', 'Rockland',
            'Putnam', 'Orange', 'Dutchess',
        ],
    };
    function fhaStandardFloor(units) {
        const idx = Math.min(4, Math.max(1, Math.round(units))) - 1;
        return exports.FHA_NATIONAL_TIERS.Standard[idx];
    }
    function lookupFhaLimit(state, tier, units, table = exports.FHA_LIMIT_TABLE) {
        var _a;
        const idx = Math.min(4, Math.max(1, Math.round(units)));
        const row = (_a = table.rows.find((r) => r.state === state && r.tier === tier)) !== null && _a !== void 0 ? _a : null;
        if (row) {
            const limit = [row.unit1, row.unit2, row.unit3, row.unit4][idx - 1];
            return { limit, row, usedFallback: false };
        }
        return { limit: exports.FHA_NATIONAL_TIERS[tier][idx - 1], row: null, usedFallback: true };
    }
    /**
     * Auto tier suggestion:
     *   Alaska / Hawaii            -> Special Exception
     *   Known high-cost county/NYC -> High-Cost
     *   otherwise                  -> Standard
     */
    function suggestFhaTier(state, county, isNYC) {
        if (SPECIAL_EXCEPTION_STATES.includes(state))
            return 'Special Exception';
        const areas = exports.HIGH_COST_AREAS[state];
        if (state === 'New York' && isNYC)
            return 'High-Cost';
        if (areas && areas.includes(county))
            return 'High-Cost';
        return 'Standard';
    }
});
define("src/core/calc/loan", ["require", "exports", "src/core/data/fhaLimits", "src/core/utils/num", "src/core/calc/trace", "src/core/data/renovationRules"], function (require, exports, fhaLimits_1, num_3, trace_3, renovationRules_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculateTotalAcquisition = calculateTotalAcquisition;
    exports.calculateValueBasis = calculateValueBasis;
    exports.calculateRequiredInvestment = calculateRequiredInvestment;
    exports.valueSupportedBaseLoan = valueSupportedBaseLoan;
    exports.calculateFhaLimit = calculateFhaLimit;
    exports.calculateLoan = calculateLoan;
    /** Total acquisition cost = final price + renovation + financed energy items. */
    function calculateTotalAcquisition(finalPurchasePrice, finalRenovationAmount, energyImprovements = 0) {
        return (0, num_3.round)((0, num_3.nonNegative)(finalPurchasePrice) + (0, num_3.nonNegative)(finalRenovationAmount) + (0, num_3.nonNegative)(energyImprovements), 2);
    }
    /**
     * HUD-92700 line C3 - the VALUE BASIS the FHA maximum mortgage is built on.
     *
     *   C1 = lesser of contract sales price or as-is value
     *   C2 = total rehabilitation cost (B14)
     *   C3 = lesser of (C1 + C2) or 110% of the after-improved value
     *
     * This is the number the statutory investment is taken against - NOT the total
     * acquisition cost. When no as-is value or ARV has been entered the caps that
     * depend on them are skipped rather than guessed.
     */
    const percentLabel = (v) => `${(v * 100).toFixed(0)}%`;
    function calculateValueBasis(contractPrice, asIsValue, rehabCost, arv) {
        const price = (0, num_3.nonNegative)(contractPrice);
        const asIs = (0, num_3.nonNegative)(asIsValue);
        const c1 = asIs > 0 ? Math.min(price, asIs) : price;
        const sumC1C2 = (0, num_3.round)(c1 + (0, num_3.nonNegative)(rehabCost), 2);
        const arv110 = (0, num_3.nonNegative)(arv) > 0 ? (0, num_3.round)((0, num_3.nonNegative)(arv) * 1.1, 2) : null;
        const valueBasis = arv110 !== null ? Math.min(sumC1C2, arv110) : sumC1C2;
        return { valueBasis: (0, num_3.round)(valueBasis, 2), c1, arv110, cappedByArv: arv110 !== null && arv110 < sumC1C2 };
    }
    /** Required investment = MAX(minimum statutory investment, selected down payment). */
    function calculateRequiredInvestment(minimumStatutoryInvestment, selectedDownPayment) {
        return Math.max((0, num_3.nonNegative)(minimumStatutoryInvestment), (0, num_3.nonNegative)(selectedDownPayment));
    }
    /**
     * The base loan the appraised value can support.
     *
     *   FHA 203(k)  110% of the after-repair value x (1 - down payment %)
     *   HomeStyle   the as-completed value x MIN(1 - down payment %, 95% LTV)
     *   Conventional, no renovation: the value x (1 - down payment %)
     *
     * HomeStyle's ceiling is a loan-to-value limit, so a smaller down payment
     * cannot push the loan past 95% of the as-completed value.
     */
    function valueSupportedBaseLoan(arv, downPaymentPct, isFha, conventionalMaxLtv = 1) {
        const value = (0, num_3.nonNegative)(arv);
        if (value <= 0)
            return null;
        const dpFactor = 1 - (0, num_3.nonNegative)(downPaymentPct);
        if (isFha)
            return (0, num_3.round)(value * renovationRules_2.FHA_203K_ARV_FACTOR * dpFactor, 2);
        return (0, num_3.round)(value * Math.min(dpFactor, (0, num_3.nonNegative)(conventionalMaxLtv)), 2);
    }
    /** FHA tier resolution + applicable limit. */
    function calculateFhaLimit(inputs, isFha) {
        var _a;
        const units = Math.min(4, Math.max(1, Math.round(inputs.units)));
        const suggestedTier = (0, fhaLimits_1.suggestFhaTier)(inputs.state, inputs.state === 'New York' ? inputs.nyCounty : '', inputs.state === 'New York' ? inputs.isNYC : false);
        const appliedTier = inputs.fhaAreaSelection === 'Auto' ? suggestedTier : inputs.fhaAreaSelection;
        if (!isFha) {
            return {
                units,
                suggestedTier,
                appliedTier: null,
                limit: 0,
                standardFloor: (0, fhaLimits_1.fhaStandardFloor)(units),
                usedFallback: false,
                areaDescription: 'N/A - Conventional financing',
            };
        }
        const { limit, row, usedFallback } = (0, fhaLimits_1.lookupFhaLimit)(inputs.state, appliedTier, units);
        return {
            units,
            suggestedTier,
            appliedTier,
            limit,
            standardFloor: (0, fhaLimits_1.fhaStandardFloor)(units),
            usedFallback,
            areaDescription: (_a = row === null || row === void 0 ? void 0 : row.area) !== null && _a !== void 0 ? _a : 'National tier fallback',
        };
    }
    /**
     * calculateBaseLoan() + calculateUfmip().
     *
     * FHA (HUD-92700 purchase method):
     *   value basis C3 = MIN( MIN(price, as-is) + rehab , 110% ARV )
     *   MSI            = C3 x down payment %
     *   base loan      = C3 x (1 - down payment %) + energy improvements
     *   max base loan  = MIN(base loan, county limit)
     *   UFMIP          = max base loan x UFMIP rate   (always on the CAPPED loan)
     *
     * Conventional:
     *   MSI            = total acquisition x down payment %
     *   base loan      = total acquisition - required investment
     *   max base loan  = MIN(base loan, value-supported loan)
     *   UFMIP          = $0, and no FHA limit is ever consulted.
     */
    function calculateLoan({ inputs, program, purchase, finalRenovationAmount, energyImprovements, trace, }) {
        var _a;
        const renovationAmount = program.renovationActive ? (0, num_3.nonNegative)(finalRenovationAmount) : 0;
        const energy = program.renovationActive ? (0, num_3.nonNegative)(energyImprovements) : 0;
        const totalAcquisitionCost = calculateTotalAcquisition(purchase.finalPurchasePrice, renovationAmount, energy);
        const dpPct = (0, num_3.nonNegative)(inputs.finalDownPaymentPct);
        const basis = calculateValueBasis(purchase.finalPurchasePrice, inputs.asIsValue, renovationAmount, inputs.afterRepairValue);
        let minimumStatutoryInvestment;
        let baseLoanBeforeLimits;
        let msiBasisLabel;
        if (program.isFha) {
            minimumStatutoryInvestment = (0, num_3.round)(basis.valueBasis * dpPct, 2);
            baseLoanBeforeLimits = Math.max(0, (0, num_3.round)(basis.valueBasis * (1 - dpPct) + energy, 2));
            msiBasisLabel = 'HUD-92700 line C3 value basis';
        }
        else {
            minimumStatutoryInvestment = (0, num_3.round)(totalAcquisitionCost * dpPct, 2);
            baseLoanBeforeLimits = Math.max(0, (0, num_3.round)(totalAcquisitionCost - Math.max(minimumStatutoryInvestment, purchase.finalDownPayment), 2));
            msiBasisLabel = 'Total acquisition cost';
        }
        const requiredInvestment = calculateRequiredInvestment(minimumStatutoryInvestment, purchase.finalDownPayment);
        const fha = calculateFhaLimit(inputs, program.isFha);
        // HomeStyle caps the loan at 95% LTV of the as-completed value; a Conventional
        // file with no renovation is limited only by the down payment.
        const conventionalMaxLtv = program.renovationActive ? renovationRules_2.HOMESTYLE_MAX_LTV : 1;
        const valueSupported = valueSupportedBaseLoan(inputs.afterRepairValue, dpPct, program.isFha, conventionalMaxLtv);
        let maximumBaseLoan = baseLoanBeforeLimits;
        const limitsApplied = [];
        const fhaBinds = program.fhaLimitsEnabled && fha.limit < baseLoanBeforeLimits;
        if (fhaBinds) {
            maximumBaseLoan = fha.limit;
            limitsApplied.push(`FHA limit ${fha.limit.toLocaleString()}`);
        }
        // The FHA value cap is already inside the C3 basis; for Conventional it is applied here.
        const valueBinds = !program.isFha && valueSupported !== null && valueSupported < maximumBaseLoan;
        if (valueBinds) {
            maximumBaseLoan = valueSupported;
            limitsApplied.push(program.renovationActive
                ? `HomeStyle ${percentLabel(renovationRules_2.HOMESTYLE_MAX_LTV)} LTV of the as-completed value`
                : `Value-supported loan ${valueSupported.toLocaleString()}`);
        }
        if (program.isFha && basis.cappedByArv) {
            limitsApplied.push('110% of after-repair value (inside the C3 basis)');
        }
        maximumBaseLoan = Math.max(0, (0, num_3.round)(maximumBaseLoan, 2));
        const limitBinding = fhaBinds && (valueBinds || basis.cappedByArv)
            ? 'both'
            : fhaBinds
                ? 'fha-limit'
                : valueBinds || (program.isFha && basis.cappedByArv)
                    ? 'value'
                    : 'none';
        const amountOverFhaLimit = program.fhaLimitsEnabled
            ? Math.max(0, (0, num_3.round)(baseLoanBeforeLimits - fha.limit, 2))
            : 0;
        const ufmip = program.ufmipEnabled ? (0, num_3.round)(maximumBaseLoan * (0, num_3.nonNegative)(inputs.ufmipRate), 2) : 0;
        const totalLoan = (0, num_3.round)(maximumBaseLoan + ufmip, 2);
        const fhaLimitStatus = !program.fhaLimitsEnabled
            ? 'N/A - Conventional financing'
            : amountOverFhaLimit > 0
                ? `LOAN EXCEEDS FHA LIMIT by ${amountOverFhaLimit.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })}`
                : 'Within selected FHA loan limit';
        const loanToCost = (0, num_3.safeDivide)(maximumBaseLoan, totalAcquisitionCost, 0);
        const propertyValueForLtv = program.renovationActive
            ? (0, num_3.nonNegative)(inputs.afterRepairValue) || totalAcquisitionCost
            : (0, num_3.nonNegative)(inputs.asIsValue) || purchase.finalPurchasePrice;
        const ltvOnFinalValue = (0, num_3.safeDivide)(maximumBaseLoan, propertyValueForLtv, 0);
        const arvLtv = (0, num_3.safeDivide)(totalLoan, (0, num_3.nonNegative)(inputs.afterRepairValue), 0);
        if (trace) {
            trace.record('totalAcquisitionCost', 'Total acquisition cost', program.renovationActive
                ? 'Total Acquisition = Final Purchase Price + Total Rehabilitation Cost + Energy Improvements'
                : 'Total Acquisition = Final Purchase Price (renovation excluded)', [
                (0, trace_3.money)('Final purchase price', purchase.finalPurchasePrice),
                (0, trace_3.money)('Total rehabilitation cost', renovationAmount),
                (0, trace_3.money)('Energy improvements', energy),
            ], totalAcquisitionCost, { resultFormat: 'currency' });
            trace.record('valueBasis', 'Value basis (HUD-92700 C3)', 'C3 = MIN( MIN(Sales Price, As-Is Value) + Rehabilitation Cost , 110% of ARV )', [
                (0, trace_3.money)('Contract sales price', purchase.finalPurchasePrice),
                (0, trace_3.money)('As-is value', inputs.asIsValue),
                (0, trace_3.money)('C1 lesser of price / as-is', basis.c1),
                (0, trace_3.money)('Total rehabilitation cost', renovationAmount),
                (0, trace_3.money)('110% of ARV', (_a = basis.arv110) !== null && _a !== void 0 ? _a : 0),
            ], basis.valueBasis, {
                resultFormat: 'currency',
                limitsApplied: basis.cappedByArv ? ['Capped by 110% of the after-repair value'] : [],
                notes: basis.arv110 === null
                    ? ['No ARV entered, so the 110% cap has not been applied.']
                    : [],
            });
            trace.record('minimumStatutoryInvestment', 'Minimum statutory investment', program.isFha
                ? 'MSI = C3 Value Basis x Down Payment %  (HUD-92700 line C5)'
                : 'MSI = Total Acquisition Cost x Down Payment %', [
                (0, trace_3.money)(program.isFha ? 'C3 value basis' : 'Total acquisition', program.isFha ? basis.valueBasis : totalAcquisitionCost),
                (0, trace_3.pct)('Down payment %', dpPct),
            ], minimumStatutoryInvestment, {
                resultFormat: 'currency',
                notes: [
                    program.isFha
                        ? 'FHA takes the statutory investment against the C3 value basis, not against total acquisition cost.'
                        : 'Conventional minimum investment is measured against total acquisition cost.',
                ],
            });
            trace.record('requiredInvestment', 'Required investment', 'Required Investment = MAX(Minimum Statutory Investment, Selected Down Payment)', [
                (0, trace_3.money)('Minimum statutory investment', minimumStatutoryInvestment),
                (0, trace_3.money)('Selected down payment', purchase.finalDownPayment),
            ], requiredInvestment, {
                resultFormat: 'currency',
                notes: [
                    minimumStatutoryInvestment > purchase.finalDownPayment
                        ? 'The statutory minimum is higher than the entered down payment, so the statutory minimum controls.'
                        : 'The entered down payment meets or exceeds the statutory minimum.',
                ],
            });
            trace.record('baseLoanBeforeLimits', 'Base loan before limits', program.isFha
                ? 'Base Loan = C3 Value Basis x (1 - Down Payment %) + Energy Improvements'
                : 'Base Loan = Total Acquisition Cost - Required Investment', program.isFha
                ? [(0, trace_3.money)('C3 value basis', basis.valueBasis), (0, trace_3.pct)('Down payment %', dpPct), (0, trace_3.money)('Energy improvements', energy)]
                : [(0, trace_3.money)('Total acquisition', totalAcquisitionCost), (0, trace_3.money)('Required investment', requiredInvestment)], baseLoanBeforeLimits, { resultFormat: 'currency' });
            trace.record('maximumBaseLoan', 'Maximum base loan', program.fhaLimitsEnabled
                ? 'Max Base Loan = MIN(Base Loan, FHA County Limit)'
                : 'Max Base Loan = MIN(Base Loan, Value-Supported Loan)', [
                (0, trace_3.money)('Base loan before limits', baseLoanBeforeLimits),
                ...(program.fhaLimitsEnabled ? [(0, trace_3.money)('Applied FHA limit', fha.limit)] : []),
                ...(valueSupported !== null ? [(0, trace_3.money)('Value-supported loan', valueSupported)] : []),
            ], maximumBaseLoan, { resultFormat: 'currency', limitsApplied });
            trace.record('ufmip', 'FHA upfront MIP', program.ufmipEnabled
                ? 'UFMIP = Maximum (capped) Base Loan x UFMIP Rate'
                : 'UFMIP = $0 (Conventional financing)', [(0, trace_3.money)('Maximum base loan', maximumBaseLoan), (0, trace_3.pct)('UFMIP rate', program.ufmipEnabled ? inputs.ufmipRate : 0)], ufmip, { resultFormat: 'currency' });
            trace.record('totalLoan', 'Total loan amount', program.ufmipEnabled ? 'Total Loan = Base Loan + UFMIP' : 'Total Loan = Base Loan', [(0, trace_3.money)('Maximum base loan', maximumBaseLoan), (0, trace_3.money)('UFMIP', ufmip)], totalLoan, { resultFormat: 'currency' });
            trace.record('fhaLimit', 'FHA loan limit check', 'Applied Limit = lookup(State, Area Tier, Units)', [
                (0, trace_3.text)('State', inputs.state),
                (0, trace_3.text)('Area tier', program.fhaLimitsEnabled ? String(fha.appliedTier) : 'N/A'),
                (0, trace_3.count)('Units', fha.units),
                (0, trace_3.money)('Standard floor', fha.standardFloor),
                (0, trace_3.money)('Base loan before limits', baseLoanBeforeLimits),
            ], program.fhaLimitsEnabled ? fha.limit : 0, {
                resultFormat: 'currency',
                notes: [
                    fhaLimitStatus,
                    fha.usedFallback ? 'No exact county row found - national tier fallback used.' : fha.areaDescription,
                ],
                overridesApplied: inputs.fhaAreaSelection !== 'Auto'
                    ? [`Area tier manually set to ${inputs.fhaAreaSelection} (auto suggestion: ${fha.suggestedTier})`]
                    : [],
            });
        }
        return {
            totalAcquisitionCost,
            valueBasis: basis.valueBasis,
            minimumStatutoryInvestment,
            msiBasisLabel,
            selectedDownPayment: purchase.finalDownPayment,
            requiredInvestment,
            baseLoanBeforeLimits,
            fhaLimitApplied: program.fhaLimitsEnabled ? fha.limit : 0,
            fhaStandardFloor: fha.standardFloor,
            fhaTier: program.fhaLimitsEnabled ? fha.appliedTier : null,
            valueSupportedBaseLoan: valueSupported,
            maximumBaseLoan,
            limitBinding,
            amountOverFhaLimit,
            fhaLimitStatus,
            ufmip,
            totalLoan,
            loanToCost,
            ltvOnFinalValue,
            arvLtv,
        };
    }
});
define("src/core/data/mortgageInsurance", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PMI_AUTO_TERMINATION_LTV = exports.PMI_CANCELLATION_LTV = exports.PMI_TABLE = exports.FHA_MIP_TABLE = exports.UFMIP_DEFAULT_RATE = void 0;
    exports.suggestFhaMipRate = suggestFhaMipRate;
    exports.suggestPmiRate = suggestPmiRate;
    const MIP_META = {
        effectiveDate: '2026-01-01',
        sourceName: 'FHA MIP planning table (uploaded knowledge pack, calculator tab I44)',
        sourceUrl: 'https://www.hud.gov/program_offices/housing/sfh/ins/premiums',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'Planning rates. Verify current mortgagee letter before disclosing.',
    };
    exports.UFMIP_DEFAULT_RATE = 0.0175;
    exports.FHA_MIP_TABLE = {
        id: 'fha_mip_rules',
        title: 'FHA annual MIP planning rates',
        description: 'Term + base loan band + LTV band -> suggested annual MIP rate.',
        columns: [
            { key: 'termYears', label: 'Term', type: 'number' },
            { key: 'loanBand', label: 'Loan band', type: 'text' },
            { key: 'ltvBand', label: 'LTV band', type: 'text' },
            { key: 'annualRate', label: 'Annual rate', type: 'percent' },
            { key: 'duration', label: 'Duration', type: 'text' },
        ],
        rows: [
            { termYears: 30, loanBand: '<= $726,200', loanBandMax: 726200, ltvBand: '<= 90%', ltvMax: 0.9, annualRate: 0.005, duration: '11 years' },
            { termYears: 30, loanBand: '> $726,200', loanBandMax: Infinity, ltvBand: '<= 90%', ltvMax: 0.9, annualRate: 0.007, duration: '11 years' },
            { termYears: 30, loanBand: '<= $726,200', loanBandMax: 726200, ltvBand: '90.01% - 95%', ltvMax: 0.95, annualRate: 0.005, duration: 'Life of loan' },
            { termYears: 30, loanBand: '> $726,200', loanBandMax: Infinity, ltvBand: '90.01% - 95%', ltvMax: 0.95, annualRate: 0.007, duration: 'Life of loan' },
            { termYears: 30, loanBand: '<= $726,200', loanBandMax: 726200, ltvBand: '> 95%', ltvMax: 1, annualRate: 0.0055, duration: 'Life of loan' },
            { termYears: 30, loanBand: '> $726,200', loanBandMax: Infinity, ltvBand: '> 95%', ltvMax: 1, annualRate: 0.0075, duration: 'Life of loan' },
        ],
        meta: MIP_META,
    };
    /** Suggested annual MIP from loan-to-cost and base loan size. */
    function suggestFhaMipRate(baseLoan, loanToCost, table = exports.FHA_MIP_TABLE) {
        const candidates = table.rows.filter((r) => loanToCost <= r.ltvMax && baseLoan <= r.loanBandMax);
        if (candidates.length === 0) {
            return { rate: 0.0075, row: null };
        }
        // Tightest LTV band first, then tightest loan band.
        candidates.sort((a, b) => a.ltvMax - b.ltvMax || a.loanBandMax - b.loanBandMax);
        const row = candidates[0];
        return { rate: row.annualRate, row };
    }
    const PMI_META = {
        effectiveDate: '2026-01-01',
        sourceName: 'PMI planning midpoints (uploaded knowledge pack, Tax Tables N2:Q5)',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'ESTIMATE ONLY. Actual PMI is insurer-quoted and depends on credit score, DTI, loan purpose, property type, coverage and MI type.',
    };
    exports.PMI_TABLE = {
        id: 'pmi_planning_rules',
        title: 'Conventional PMI planning rates',
        description: 'Credit tier + down payment band -> planning annual PMI rate (estimate only).',
        columns: [
            { key: 'creditTier', label: 'Credit tier', type: 'text' },
            { key: 'lowDown', label: '< 10% down', type: 'percent' },
            { key: 'down10to15', label: '10% - 15% down', type: 'percent' },
            { key: 'down15to20', label: '15% - 20% down', type: 'percent' },
        ],
        rows: [
            { creditTier: 'Excellent (760+)', lowDown: 0.0045, down10to15: 0.004, down15to20: 0.003 },
            { creditTier: 'Good (700-759)', lowDown: 0.0075, down10to15: 0.005, down15to20: 0.004 },
            { creditTier: 'Fair (640-699)', lowDown: 0.011, down10to15: 0.0075, down15to20: 0.006 },
            { creditTier: 'Below 640', lowDown: 0.0135, down10to15: 0.01, down15to20: 0.008 },
        ],
        meta: PMI_META,
    };
    exports.PMI_CANCELLATION_LTV = 0.8;
    exports.PMI_AUTO_TERMINATION_LTV = 0.78;
    function suggestPmiRate(creditTier, downPaymentPct, table = exports.PMI_TABLE) {
        var _a;
        if (downPaymentPct >= 0.2)
            return 0;
        const row = (_a = table.rows.find((r) => r.creditTier === creditTier)) !== null && _a !== void 0 ? _a : table.rows[2];
        if (downPaymentPct >= 0.15)
            return row.down15to20;
        if (downPaymentPct >= 0.1)
            return row.down10to15;
        return row.lowDown;
    }
});
define("src/core/data/qualificationRules", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SELF_SUFFICIENCY = exports.RESERVE_RULES = exports.DTI_LIMITS = void 0;
    exports.dtiLimits = dtiLimits;
    exports.requiredReserveMonths = requiredReserveMonths;
    exports.creditTierFromScore = creditTierFromScore;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'Qualification planning rules (uploaded AUS dashboard workbook)',
        lastReviewed: '2026-01-01',
        confidence: 'lender-guide',
        overrideAllowed: true,
        notes: 'Planning limits. Actual DTI, reserve and self-sufficiency requirements come from FHA TOTAL, DU/LPA findings and lender overlays.',
    };
    exports.DTI_LIMITS = {
        id: 'dti_limits',
        title: 'DTI planning limits',
        description: 'Front-end and back-end ratio limits used by the qualification screen.',
        columns: [
            { key: 'program', label: 'Program', type: 'text' },
            { key: 'frontEndLimit', label: 'Front-end limit', type: 'percent' },
            { key: 'backEndLimit', label: 'Back-end limit', type: 'percent' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: [
            { program: 'FHA', frontEndLimit: 0.47, backEndLimit: 0.57, note: 'Manual-underwrite style planning caps' },
            { program: 'Conventional', frontEndLimit: 0.5, backEndLimit: 0.5, note: 'DU/LPA planning cap' },
        ],
        meta: META,
    };
    function dtiLimits(program) {
        var _a;
        const row = (_a = exports.DTI_LIMITS.rows.find((r) => r.program === program)) !== null && _a !== void 0 ? _a : exports.DTI_LIMITS.rows[0];
        return { front: row.frontEndLimit, back: row.backEndLimit };
    }
    exports.RESERVE_RULES = {
        id: 'reserve_requirements',
        title: 'Post-closing reserve requirements',
        description: 'Required months of PITI in borrower-owned funds after closing.',
        columns: [
            { key: 'program', label: 'Program', type: 'text' },
            { key: 'propertyType', label: 'Property type', type: 'text' },
            { key: 'ltvCondition', label: 'LTV condition', type: 'text' },
            { key: 'months', label: 'Months', type: 'number' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: [
            { program: 'Both', propertyType: '1 Family', ltvCondition: 'Any', months: 0, note: 'No reserve requirement in the planning model' },
            { program: 'Both', propertyType: 'Single Family with ADU', ltvCondition: 'Any', months: 2, note: 'ADU income may qualify' },
            { program: 'Conventional', propertyType: 'Multi-unit', ltvCondition: 'LTC > 80%', months: 6, note: 'Conventional multi-unit above 80%' },
            { program: 'Conventional', propertyType: 'Multi-unit', ltvCondition: 'LTC <= 80%', months: 2, note: 'Conventional multi-unit at or below 80%' },
            { program: 'FHA', propertyType: '2 Family', ltvCondition: 'Any', months: 2, note: 'FHA 2-family' },
            { program: 'FHA', propertyType: '3 Family', ltvCondition: 'Any', months: 3, note: 'FHA 3-4 family' },
            { program: 'FHA', propertyType: '4 Family', ltvCondition: 'Any', months: 3, note: 'FHA 3-4 family' },
        ],
        meta: META,
    };
    function requiredReserveMonths(program, propertyType, loanToCost) {
        if (propertyType === '1 Family')
            return { months: 0, note: 'Self-sufficiency N/A.' };
        if (propertyType === 'Single Family with ADU') {
            return { months: 2, note: 'ADU income may qualify; self-sufficiency N/A; 2 months reserves.' };
        }
        if (program === 'Conventional') {
            return loanToCost > 0.8
                ? { months: 6, note: 'Conventional multi-unit above 80% LTV: 6 months reserves.' }
                : { months: 2, note: 'Conventional multi-unit at or below 80% LTV: 2 months reserves.' };
        }
        if (propertyType === '2 Family') {
            return { months: 2, note: 'FHA 2-family test uses 75% of main and second-unit rents; 2 months reserves.' };
        }
        return { months: 3, note: 'FHA 3-4 family self-sufficiency uses 75% of all legal unit rents; 3 months reserves.' };
    }
    // ---------------------------------------------------------------------------
    // Self-sufficiency
    // ---------------------------------------------------------------------------
    exports.SELF_SUFFICIENCY = {
        /** Rent factor applied to all legal unit rents. */
        rentFactor: 0.75,
        /**
         * Minimum unit count the test applies to in this planning model. The supplied
         * workbook applies it from 2 units; FHA policy applies it to 3-4 units.
         * Change to 3 to follow agency policy exactly.
         */
        minUnits: 2,
        meta: {
            effectiveDate: '2026-01-01',
            sourceName: 'FHA self-sufficiency planning test (uploaded workbook)',
            lastReviewed: '2026-01-01',
            confidence: 'lender-guide',
            overrideAllowed: true,
            notes: 'The supplied workbook runs the 75% test from 2 units. FHA policy applies self-sufficiency to 3-4 unit properties; set minUnits to 3 to match agency policy.',
        },
    };
    // ---------------------------------------------------------------------------
    // Credit tier
    // ---------------------------------------------------------------------------
    function creditTierFromScore(score) {
        if (score >= 760)
            return 'Excellent (760+)';
        if (score >= 700)
            return 'Good (700-759)';
        if (score >= 640)
            return 'Fair (640-699)';
        return 'Below 640';
    }
});
define("src/core/calc/payment", ["require", "exports", "src/core/data/mortgageInsurance", "src/core/data/qualificationRules", "src/core/utils/num", "src/core/calc/trace"], function (require, exports, mortgageInsurance_1, qualificationRules_1, num_4, trace_4) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.principalAndInterest = principalAndInterest;
    exports.paymentSpread = paymentSpread;
    exports.calculatePayment = calculatePayment;
    /**
     * calculatePayment() - standard fixed-rate amortisation.
     * P&I = L x [ r(1+r)^n / ((1+r)^n - 1) ], r = annual rate / 12, n = term x 12.
     * Interest rate 0 falls back to straight-line principal.
     */
    function principalAndInterest(loanAmount, annualRate, termYears) {
        const L = (0, num_4.nonNegative)(loanAmount);
        const n = Math.round((0, num_4.nonNegative)(termYears) * 12);
        if (L <= 0 || n <= 0)
            return 0;
        const r = (0, num_4.nonNegative)(annualRate) / 12;
        if (r === 0)
            return L / n;
        const factor = Math.pow(1 + r, n);
        return (L * r * factor) / (factor - 1);
    }
    /** Borrower-facing high-end spread rule. */
    function paymentSpread(exactPayment) {
        const p = (0, num_4.num)(exactPayment);
        if (p < 5000)
            return 200;
        if (p <= 7000)
            return 225;
        return 250;
    }
    function calculatePayment({ inputs, program, loan, finalPurchasePrice, renovationAmount, trace, }) {
        const pi = (0, num_4.round)(principalAndInterest(loan.totalLoan, inputs.interestRate, inputs.termYears), 2);
        // ---- FHA annual MIP (never runs for Conventional) ----------------------
        const mipSuggestion = (0, mortgageInsurance_1.suggestFhaMipRate)(loan.maximumBaseLoan, loan.loanToCost);
        const fhaMipSuggestedRate = program.fhaMipEnabled ? mipSuggestion.rate : 0;
        const fhaMipRateUsed = program.fhaMipEnabled
            ? (0, num_4.nonNegative)(inputs.fhaMipOverrideRate) > 0
                ? (0, num_4.nonNegative)(inputs.fhaMipOverrideRate)
                : (0, num_4.nonNegative)(inputs.fhaAnnualMipRate)
            : 0;
        const monthlyFhaMip = program.fhaMipEnabled
            ? (0, num_4.round)((loan.maximumBaseLoan * fhaMipRateUsed) / 12, 2)
            : 0;
        // ---- Conventional PMI (never runs for FHA) -----------------------------
        const creditTier = (0, qualificationRules_1.creditTierFromScore)((0, num_4.nonNegative)(inputs.creditScore));
        const pmiSuggestedRate = program.pmiEnabled
            ? (0, mortgageInsurance_1.suggestPmiRate)(creditTier, (0, num_4.nonNegative)(inputs.finalDownPaymentPct))
            : 0;
        const pmiRateUsed = program.pmiEnabled
            ? (0, num_4.nonNegative)(inputs.pmiOverrideRate) > 0
                ? (0, num_4.nonNegative)(inputs.pmiOverrideRate)
                : pmiSuggestedRate
            : 0;
        const monthlyPmi = program.pmiEnabled
            ? (0, num_4.round)((loan.maximumBaseLoan * pmiRateUsed) / 12, 2)
            : 0;
        // ---- Taxes and insurance ----------------------------------------------
        const monthlyTaxes = inputs.propertyTaxBasis === 'Annual'
            ? (0, num_4.round)((0, num_4.nonNegative)(inputs.propertyTaxAmount) / 12, 2)
            : (0, num_4.nonNegative)(inputs.propertyTaxAmount);
        const monthlyInsurance = inputs.insuranceBasis === 'Annual'
            ? (0, num_4.round)((0, num_4.nonNegative)(inputs.insuranceAmount) / 12, 2)
            : (0, num_4.nonNegative)(inputs.insuranceAmount);
        const override = (0, num_4.nonNegative)(inputs.taxInsuranceOverrideMonthly);
        const usingTiOverride = override > 0;
        const monthlyTaxesAndInsuranceUsed = usingTiOverride ? override : (0, num_4.round)(monthlyTaxes + monthlyInsurance, 2);
        const hoaMonthly = (0, num_4.nonNegative)(inputs.hoaMonthly);
        const totalMonthlyPayment = (0, num_4.round)(pi + monthlyFhaMip + monthlyPmi + monthlyTaxesAndInsuranceUsed + hoaMonthly, 2);
        const increment = (0, num_4.num)(inputs.paymentRoundingIncrement, 50) || 50;
        const paymentLow = (0, num_4.roundDownTo)(totalMonthlyPayment, increment);
        const spread = paymentSpread(totalMonthlyPayment);
        const paymentHigh = paymentLow + spread;
        const pmiCancelValue = program.pmiEnabled
            ? (0, num_4.round)((0, num_4.safeDivide)(loan.maximumBaseLoan, mortgageInsurance_1.PMI_CANCELLATION_LTV, 0), 2)
            : 0;
        const valueForLtv = program.renovationActive
            ? (0, num_4.nonNegative)(inputs.afterRepairValue) || finalPurchasePrice + renovationAmount
            : (0, num_4.nonNegative)(inputs.asIsValue) || finalPurchasePrice;
        const currentLtv = (0, num_4.safeDivide)(loan.maximumBaseLoan, valueForLtv, 0);
        if (trace) {
            trace.record('principalAndInterest', 'Principal & interest', 'P&I = L x [ r(1+r)^n / ((1+r)^n - 1) ]', [
                (0, trace_4.money)('Total loan (L)', loan.totalLoan),
                (0, trace_4.pct)('Annual rate', inputs.interestRate),
                (0, trace_4.count)('Term (years)', inputs.termYears),
            ], pi, { resultFormat: 'currency' });
            trace.record('monthlyFhaMip', 'Monthly FHA MIP', program.fhaMipEnabled
                ? 'Monthly MIP = FHA Base Loan x Annual MIP Rate / 12'
                : 'Monthly MIP = $0 (Conventional financing)', [(0, trace_4.money)('FHA base loan', program.fhaMipEnabled ? loan.maximumBaseLoan : 0), (0, trace_4.pct)('Annual MIP rate', fhaMipRateUsed)], monthlyFhaMip, {
                resultFormat: 'currency',
                overridesApplied: program.fhaMipEnabled && (0, num_4.nonNegative)(inputs.fhaMipOverrideRate) > 0
                    ? [`Manual MIP rate override ${(inputs.fhaMipOverrideRate * 100).toFixed(3)}%`]
                    : [],
                notes: program.fhaMipEnabled
                    ? [`Suggested planning rate from LTC ${(loan.loanToCost * 100).toFixed(2)}%: ${(fhaMipSuggestedRate * 100).toFixed(3)}%`]
                    : [],
            });
            trace.record('monthlyPmi', 'Monthly conventional PMI', program.pmiEnabled
                ? 'Monthly PMI = Conventional Base Loan x Annual PMI Rate / 12'
                : 'Monthly PMI = $0 (FHA financing)', [(0, trace_4.money)('Base loan', program.pmiEnabled ? loan.maximumBaseLoan : 0), (0, trace_4.pct)('Annual PMI rate', pmiRateUsed)], monthlyPmi, {
                resultFormat: 'currency',
                overridesApplied: program.pmiEnabled && (0, num_4.nonNegative)(inputs.pmiOverrideRate) > 0
                    ? [`Manual PMI rate override ${(inputs.pmiOverrideRate * 100).toFixed(3)}%`]
                    : [],
                notes: program.pmiEnabled
                    ? ['PMI is an ESTIMATE. The actual rate requires an insurer quote.']
                    : [],
            });
            trace.record('totalMonthlyPayment', 'Total monthly payment', 'Payment = P&I + MI + Taxes + Insurance + HOA', [
                (0, trace_4.money)('Principal & interest', pi),
                (0, trace_4.money)('FHA MIP', monthlyFhaMip),
                (0, trace_4.money)('Conventional PMI', monthlyPmi),
                (0, trace_4.money)('Taxes + insurance used', monthlyTaxesAndInsuranceUsed),
                (0, trace_4.money)('HOA / other monthly', hoaMonthly),
            ], totalMonthlyPayment, {
                resultFormat: 'currency',
                overridesApplied: usingTiOverride
                    ? [`Combined monthly taxes + insurance override of ${override.toFixed(2)} replaces the separate fields`]
                    : [],
            });
            trace.record('paymentRange', 'Borrower payment range', 'Low = ROUNDDOWN(Payment / Increment) x Increment; High = Low + $200 / $225 / $250', [
                (0, trace_4.money)('Exact payment', totalMonthlyPayment),
                (0, trace_4.count)('Rounding increment', increment),
                (0, trace_4.money)('Spread applied', spread),
            ], paymentHigh, {
                resultFormat: 'currency',
                notes: [`Low ${paymentLow.toFixed(0)} / High ${paymentHigh.toFixed(0)}`],
            });
        }
        return {
            principalAndInterest: pi,
            monthlyFhaMip,
            monthlyPmi,
            pmiRateUsed,
            pmiSuggestedRate,
            fhaMipRateUsed,
            fhaMipSuggestedRate,
            monthlyTaxes,
            monthlyInsurance,
            usingTiOverride,
            monthlyTaxesAndInsuranceUsed,
            hoaMonthly,
            totalMonthlyPayment,
            paymentLow,
            paymentHigh,
            paymentSpread: spread,
            pmiCancelValue,
            currentLtv,
            creditTier,
        };
    }
});
define("src/core/calc/value", ["require", "exports", "src/core/data/marketData", "src/core/utils/num", "src/core/calc/trace", "src/core/data/renovationRules"], function (require, exports, marketData_1, num_5, trace_5, renovationRules_3) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculateValue = calculateValue;
    /**
     * calculateArvSupport() + the equity and forward-value block.
     *
     *   110% ARV              = ARV x 1.10                    (FHA 203(k) only)
     *   Loan supported        = FHA:       110% ARV x (1 - down payment %)
     *                           HomeStyle: ARV x MIN(1 - down payment %, 95%)
     *                           otherwise: ARV x (1 - down payment %)
     *   Value cushion         = loan supported - current base loan
     *   Minimum as-is value   = (base loan / (1 - dp%)) - renovation
     *   Minimum ARV           = (base loan / (1 - dp%)) / (FHA ? 1.10 : 1)
     *   Equity after loan     = ARV - total loan
     *   Value gained          = ARV - final purchase price
     *   Value per $10k        = (ARV - price) / renovation x 10,000
     *   Projected value       = ARV x (1 + appreciation) ^ years
     */
    function calculateValue(inputs, program, loan, renovationAmount, finalPurchasePrice, trace) {
        const asIsValue = (0, num_5.nonNegative)(inputs.asIsValue);
        const afterRepairValue = (0, num_5.nonNegative)(inputs.afterRepairValue);
        const arv110 = (0, num_5.round)(afterRepairValue * renovationRules_3.FHA_203K_ARV_FACTOR, 2);
        const dpPct = (0, num_5.nonNegative)(inputs.finalDownPaymentPct);
        const ltvFactor = 1 - dpPct;
        // Each program tests value differently:
        //   FHA 203(k)  the C3 basis may not exceed 110% of the after-repair value
        //   HomeStyle   the LOAN may not exceed 95% LTV of the as-completed value
        const homestyle = !program.isFha && program.renovationActive;
        const arvLimitPct = program.isFha ? renovationRules_3.FHA_203K_ARV_FACTOR : homestyle ? renovationRules_3.HOMESTYLE_MAX_LTV : ltvFactor;
        const arvLimitValue = (0, num_5.round)(afterRepairValue * arvLimitPct, 2);
        const arvLimitLabel = program.isFha
            ? '110% of the after-repair value'
            : homestyle
                ? '95% LTV of the as-completed value'
                : `${(0, num_5.percent)(ltvFactor, 2)} of the appraised value`;
        /** The share of the ARV this program can lend against. */
        const supportFactor = program.isFha
            ? renovationRules_3.FHA_203K_ARV_FACTOR * ltvFactor
            : homestyle
                ? Math.min(ltvFactor, renovationRules_3.HOMESTYLE_MAX_LTV)
                : ltvFactor;
        const loanSupportedByValue = loan.valueSupportedBaseLoan;
        const valueCushion = loanSupportedByValue === null ? null : (0, num_5.round)(loanSupportedByValue - loan.maximumBaseLoan, 2);
        const requiredValueBasis = ltvFactor <= 0 ? 0 : (0, num_5.safeDivide)(loan.maximumBaseLoan, ltvFactor, 0);
        const minimumAsIsValueNeeded = Math.max(0, (0, num_5.round)(requiredValueBasis - (program.renovationActive ? (0, num_5.nonNegative)(renovationAmount) : 0), 2));
        // The ARV the file needs is the loan divided by whatever share of value the
        // program will lend - 110% x (1 - down payment) for FHA, 95% for HomeStyle.
        const minimumArvNeeded = supportFactor <= 0 ? 0 : (0, num_5.round)((0, num_5.safeDivide)(loan.maximumBaseLoan, supportFactor, 0), 2);
        // ---- equity -------------------------------------------------------------
        const valueGained = afterRepairValue > 0 ? (0, num_5.round)(afterRepairValue - finalPurchasePrice, 2) : 0;
        const equityAfterLoan = afterRepairValue > 0 ? (0, num_5.round)(afterRepairValue - loan.totalLoan, 2) : 0;
        const equityPct = afterRepairValue > 0 ? (0, num_5.safeDivide)(equityAfterLoan, afterRepairValue, 0) : 0;
        const equityAtDownPaymentOnly = (0, num_5.round)(finalPurchasePrice * 0.035, 2);
        const equityDifference = (0, num_5.round)(equityAfterLoan - equityAtDownPaymentOnly, 2);
        const valuePer10kRenovated = afterRepairValue > 0 && renovationAmount > 0
            ? (0, num_5.round)(((afterRepairValue - finalPurchasePrice) / renovationAmount) * 10000, 2)
            : 0;
        const equityNarrative = afterRepairValue <= 0
            ? 'Enter the after-repair value to calculate equity.'
            : `The property gains ${(0, num_5.currency)(valueGained)} in value. Estimated borrower equity after the renovation loan is ${(0, num_5.currency)(equityAfterLoan)} (${(0, num_5.percent)(equityPct, 2)}).`;
        const efficiencyNarrative = afterRepairValue <= 0 || renovationAmount <= 0
            ? 'N/A'
            : `Each $10,000 of renovation creates about ${(0, num_5.currency)(valuePer10kRenovated)} in value.`;
        // ---- forward projection -------------------------------------------------
        const market = (0, marketData_1.lookupMarket)(inputs.state);
        const override = (0, num_5.nonNegative)(inputs.projection.appreciationRateOverride);
        const appreciationRate = override > 0 ? override : market.appreciation;
        const appreciationSource = override > 0 ? 'Manual override' : `${inputs.state} state planning assumption`;
        const years = Math.max(0, Math.round(inputs.projection.years));
        const baseValue = afterRepairValue > 0 ? afterRepairValue : finalPurchasePrice;
        const projectedValue = (0, num_5.round)(baseValue * Math.pow(1 + appreciationRate, years), 2);
        const projectedEquity = (0, num_5.round)(projectedValue - loan.totalLoan, 2);
        if (trace) {
            trace.record('arv110', `Value ceiling - ${arvLimitLabel}`, program.isFha
                ? '110% ARV = After-Repair Value x 1.10'
                : homestyle
                    ? '95% LTV ceiling = As-Completed Value x 0.95'
                    : 'Value ceiling = Appraised Value x (1 - Down Payment %)', [(0, trace_5.money)('After-repair value', afterRepairValue), (0, trace_5.pct)('Ceiling', arvLimitPct)], arvLimitValue, {
                resultFormat: 'currency',
                notes: [
                    program.isFha
                        ? 'FHA 203(k) caps the HUD-92700 line C3 value basis at 110% of the after-repair value.'
                        : homestyle
                            ? 'HomeStyle is a loan-to-value limit: the loan itself may not exceed 95% of the as-completed value, whatever the down payment is.'
                            : 'With no renovation the value limit is simply the down payment against the appraised value.',
                ],
            });
            trace.record('loanSupportedByValue', 'Loan supported by value', program.isFha
                ? 'Supported Loan = 110% ARV x (1 - Down Payment %)'
                : homestyle
                    ? 'Supported Loan = As-Completed Value x MIN(1 - Down Payment %, 95%)'
                    : 'Supported Loan = ARV x (1 - Down Payment %)', [(0, trace_5.money)('After-repair value', afterRepairValue), (0, trace_5.pct)('Down payment %', dpPct)], loanSupportedByValue !== null && loanSupportedByValue !== void 0 ? loanSupportedByValue : 0, {
                resultFormat: 'currency',
                limitsApplied: homestyle && ltvFactor > renovationRules_3.HOMESTYLE_MAX_LTV ? ['HomeStyle 95% LTV'] : [],
                notes: loanSupportedByValue === null ? ['No after-repair value entered - value cap not applied.'] : [],
            });
            trace.record('valueCushion', 'Value cushion / shortfall', 'Cushion = Loan Supported by Value - Current Base Loan', [(0, trace_5.money)('Loan supported by value', loanSupportedByValue !== null && loanSupportedByValue !== void 0 ? loanSupportedByValue : 0), (0, trace_5.money)('Current base loan', loan.maximumBaseLoan)], valueCushion !== null && valueCushion !== void 0 ? valueCushion : 0, { resultFormat: 'currency' });
            trace.record('minimumAsIsValue', 'Minimum as-is value needed', 'Minimum As-Is = (Base Loan / (1 - Down Payment %)) - Renovation Amount', [
                (0, trace_5.money)('Base loan', loan.maximumBaseLoan),
                (0, trace_5.pct)('Down payment %', dpPct),
                (0, trace_5.money)('Renovation amount', program.renovationActive ? renovationAmount : 0),
            ], minimumAsIsValueNeeded, { resultFormat: 'currency' });
            trace.record('minimumArv', 'Minimum after-repair value needed', program.isFha
                ? 'Minimum ARV = (Base Loan / (1 - Down Payment %)) / 1.10'
                : 'Minimum ARV = Base Loan / (1 - Down Payment %)', [(0, trace_5.money)('Base loan', loan.maximumBaseLoan), (0, trace_5.pct)('Down payment %', dpPct)], minimumArvNeeded, { resultFormat: 'currency' });
            trace.record('borrowerEquity', 'Borrower equity after the renovation loan', 'Equity = After-Repair Value - Total Loan', [(0, trace_5.money)('After-repair value', afterRepairValue), (0, trace_5.money)('Total loan', loan.totalLoan)], equityAfterLoan, {
                resultFormat: 'currency',
                notes: [
                    equityNarrative,
                    `Equity from the down payment alone would be ${(0, num_5.currency)(equityAtDownPaymentOnly)}; the renovation adds ${(0, num_5.currency)(equityDifference)}.`,
                ],
            });
            trace.record('projectedValue', 'Projected value', 'Projected Value = Value x (1 + Annual Appreciation) ^ Years', [
                (0, trace_5.money)('Starting value', baseValue),
                (0, trace_5.pct)('Annual appreciation', appreciationRate),
                (0, trace_5.count)('Years', years),
            ], projectedValue, {
                resultFormat: 'currency',
                notes: [
                    `Appreciation source: ${appreciationSource}.`,
                    'Planning assumption only - not a forecast and not an appraisal.',
                ],
            });
        }
        return {
            asIsValue,
            afterRepairValue,
            arv110,
            arvLimitPct,
            arvLimitValue,
            arvLimitLabel,
            loanSupportedByValue,
            valueCushion,
            minimumAsIsValueNeeded,
            minimumArvNeeded,
            valueGained,
            equityAfterLoan,
            equityPct,
            equityAtDownPaymentOnly,
            equityDifference,
            valuePer10kRenovated,
            equityNarrative,
            efficiencyNarrative,
            appreciationRate,
            appreciationSource,
            projectedValue,
            projectedEquity,
            projectionYears: years,
        };
    }
});
define("src/core/calc/escrow", ["require", "exports", "src/core/data/escrowRules", "src/core/utils/dates", "src/core/utils/num", "src/core/calc/trace"], function (require, exports, escrowRules_1, dates_2, num_6, trace_6) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculateEscrow = calculateEscrow;
    function isoFor(year, month1to12, day = 1) {
        return (0, dates_2.toISO)(new Date(Date.UTC(year, month1to12 - 1, day)));
    }
    /**
     * calculateEscrow() - aggregate (12-month trial balance) escrow analysis.
     *
     *   Monthly deposit   = total annual escrowed disbursements / 12
     *   Trial balance     = prior balance + deposit - scheduled disbursements
     *   Required cushion  = monthly deposit x cushion months
     *   Initial deposit   = required cushion - lowest trial balance
     *
     * The schedule is anchored to the CLOSING DATE: the first payment date defaults
     * to the first of the second month after closing, and every disbursement is
     * dated against the state/jurisdiction due-date rule.
     *
     * Monthly FHA MIP and Conventional PMI are not escrowed items and get no cushion.
     */
    function calculateEscrow(inputs, payment, trace) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        // Derive the annual figures from the ENTERED amounts, not from the rounded
        // monthly values, so a $13,000 annual tax bill stays $13,000.
        const annualTaxes = inputs.propertyTaxBasis === 'Annual'
            ? (0, num_6.nonNegative)(inputs.propertyTaxAmount)
            : (0, num_6.round)((0, num_6.nonNegative)(inputs.propertyTaxAmount) * 12, 2);
        const annualInsurance = inputs.insuranceBasis === 'Annual'
            ? (0, num_6.nonNegative)(inputs.insuranceAmount)
            : (0, num_6.round)((0, num_6.nonNegative)(inputs.insuranceAmount) * 12, 2);
        const annualFlood = (0, num_6.nonNegative)(inputs.escrow.annualFlood);
        const totalAnnualEscrowed = (0, num_6.round)(annualTaxes + annualInsurance + annualFlood, 2);
        const monthlyDeposit = (0, num_6.round)(totalAnnualEscrowed / 12, 2);
        const jurisdiction = inputs.state === 'New York' ? (inputs.isNYC ? 'New York City' : inputs.nyCounty) : inputs.state;
        const rule = (0, escrowRules_1.lookupEscrowRule)(inputs.state, jurisdiction, inputs.state === 'New York' && inputs.isNYC);
        const cushionMonths = inputs.escrow.cushionMonthsOverride >= 0
            ? Math.round(inputs.escrow.cushionMonthsOverride)
            : rule.cushionMonths;
        const cushionMonthsSource = inputs.escrow.cushionMonthsOverride >= 0 ? 'Manual override' : rule.source;
        const taxMonths = (_b = (_a = rule.row) === null || _a === void 0 ? void 0 : _a.taxDisbursementMonths) !== null && _b !== void 0 ? _b : [1, 7];
        const closing = (0, dates_2.parseISO)(inputs.closingDate);
        const insuranceMonth = closing ? closing.getUTCMonth() + 1 : 1;
        const schedule = [];
        if (inputs.escrow.useCustomDisbursements && inputs.escrow.customDisbursements.length > 0) {
            for (const d of inputs.escrow.customDisbursements) {
                schedule.push({ month: Math.round(d.month), amount: (0, num_6.nonNegative)(d.amount), label: d.label });
            }
        }
        else {
            const perTaxInstallment = taxMonths.length > 0 ? annualTaxes / taxMonths.length : 0;
            taxMonths.forEach((m, i) => schedule.push({
                month: m,
                amount: (0, num_6.round)(perTaxInstallment, 2),
                label: taxMonths.length > 1 ? `Property tax installment ${i + 1}` : 'Property tax',
            }));
            if (annualInsurance > 0) {
                schedule.push({ month: insuranceMonth, amount: annualInsurance, label: 'Hazard insurance renewal' });
            }
            if (annualFlood > 0) {
                schedule.push({ month: insuranceMonth, amount: annualFlood, label: 'Flood insurance renewal' });
            }
        }
        // ---- anchor the schedule to the closing date ---------------------------
        const firstPaymentDate = inputs.escrow.autoFirstPaymentDate
            ? (0, dates_2.defaultFirstPaymentDate)(inputs.closingDate)
            : inputs.escrow.firstPaymentDate;
        const firstPayment = (_c = (0, dates_2.parseISO)(firstPaymentDate)) !== null && _c !== void 0 ? _c : closing;
        const startMonth = firstPayment ? firstPayment.getUTCMonth() + 1 : 1;
        const startYear = firstPayment ? firstPayment.getUTCFullYear() : new Date().getUTCFullYear();
        const rows = [];
        let balance = 0;
        for (let i = 0; i < 12; i += 1) {
            const calMonthIndex0 = (startMonth - 1 + i) % 12;
            const calMonth = calMonthIndex0 + 1;
            const year = startYear + Math.floor((startMonth - 1 + i) / 12);
            const due = schedule.filter((s) => s.month === calMonth);
            const disbursements = (0, num_6.round)(due.reduce((acc, s) => acc + s.amount, 0), 2);
            balance = (0, num_6.round)(balance + monthlyDeposit - disbursements, 2);
            rows.push({
                monthIndex: i + 1,
                monthLabel: (0, dates_2.monthLabel)(calMonth, year),
                dueDate: isoFor(year, calMonth, 1),
                deposit: monthlyDeposit,
                disbursements,
                disbursementLabels: due.map((d) => d.label),
                balance,
            });
        }
        const lowestTrialBalance = rows.length ? Math.min(...rows.map((r) => r.balance)) : 0;
        const requiredCushion = (0, num_6.round)(monthlyDeposit * cushionMonths, 2);
        const initialEscrowDeposit = Math.max(0, (0, num_6.round)(requiredCushion - lowestTrialBalance, 2));
        const firstTaxRow = rows.find((r) => r.disbursementLabels.some((l) => l.toLowerCase().includes('tax')));
        const firstInsuranceRow = rows.find((r) => r.disbursementLabels.some((l) => l.toLowerCase().includes('insurance')));
        if (trace) {
            trace.record('escrowMonthlyDeposit', 'Monthly escrow deposit', 'Monthly Deposit = Total Annual Escrowed Disbursements / 12', [
                (0, trace_6.money)('Annual taxes', annualTaxes),
                (0, trace_6.money)('Annual hazard insurance', annualInsurance),
                (0, trace_6.money)('Annual flood insurance', annualFlood),
            ], monthlyDeposit, { resultFormat: 'currency' });
            trace.record('escrowInitialDeposit', 'Initial escrow deposit', 'Initial Escrow = Required Cushion - Lowest Trial Balance', [
                (0, trace_6.money)('Monthly deposit', monthlyDeposit),
                (0, trace_6.count)('Cushion months', cushionMonths),
                (0, trace_6.money)('Required cushion', requiredCushion),
                (0, trace_6.money)('Lowest projected balance', lowestTrialBalance),
                (0, trace_6.text)('First payment date', firstPaymentDate),
            ], initialEscrowDeposit, {
                resultFormat: 'currency',
                notes: [
                    `Cushion source: ${cushionMonthsSource}`,
                    `Schedule anchored to the ${inputs.closingDate} closing date.`,
                    'Monthly FHA MIP / Conventional PMI carry no separate escrow cushion.',
                ],
            });
        }
        return {
            annualTaxes,
            annualInsurance,
            annualFlood,
            totalAnnualEscrowed,
            monthlyDeposit,
            cushionMonths,
            cushionMonthsSource,
            requiredCushion,
            lowestTrialBalance,
            initialEscrowDeposit,
            rows,
            taxSetupNote: (_e = (_d = rule.row) === null || _d === void 0 ? void 0 : _d.taxStructure) !== null && _e !== void 0 ? _e : 'Single annual tax line (default)',
            disbursementScheduleNote: (_g = (_f = rule.row) === null || _f === void 0 ? void 0 : _f.note) !== null && _g !== void 0 ? _g : 'No state-specific disbursement rule stored; defaults applied.',
            firstPaymentDate,
            firstTaxDueDate: (_h = firstTaxRow === null || firstTaxRow === void 0 ? void 0 : firstTaxRow.dueDate) !== null && _h !== void 0 ? _h : '',
            nextInsuranceDueDate: (_j = firstInsuranceRow === null || firstInsuranceRow === void 0 ? void 0 : firstInsuranceRow.dueDate) !== null && _j !== void 0 ? _j : '',
        };
    }
});
define("src/core/data/mortgageRecordingTax", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NYC_MORTGAGE_TAX = exports.NY_MORTGAGE_TAX_TABLE = void 0;
    exports.lookupNyMortgageTax = lookupNyMortgageTax;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'NY mortgage tax planning table (uploaded State Tax & Escrow Reference, section 2)',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'Buyer-paid portion for planning. Confirm the exact split, CEMA treatment and lender-paid 0.25% portion with the title company.',
    };
    exports.NY_MORTGAGE_TAX_TABLE = {
        id: 'mortgage_recording_taxes',
        title: 'New York mortgage recording tax',
        description: 'NY county/area -> mortgage recording tax rate and residential exemption.',
        columns: [
            { key: 'area', label: 'NY county / area', type: 'text' },
            { key: 'rate', label: 'Rate', type: 'percent' },
            { key: 'exemption', label: 'Residential exemption', type: 'currency' },
        ],
        rows: [
            { area: 'Albany', rate: 0.0125, exemption: 25 },
            { area: 'Allegany', rate: 0.01, exemption: 25 },
            { area: 'Broome', rate: 0.01, exemption: 25 },
            { area: 'Cattaraugus', rate: 0.0125, exemption: 25 },
            { area: 'Cayuga', rate: 0.01, exemption: 25 },
            { area: 'Chautauqua', rate: 0.0125, exemption: 25 },
            { area: 'Chemung', rate: 0.0075, exemption: 25 },
            { area: 'Chenango', rate: 0.01, exemption: 25 },
            { area: 'Clinton', rate: 0.01, exemption: 25 },
            { area: 'Columbia', rate: 0.0125, exemption: 25 },
            { area: 'Cortland', rate: 0.0125, exemption: 25 },
            { area: 'Delaware', rate: 0.01, exemption: 25 },
            { area: 'Dutchess', rate: 0.0105, exemption: 30 },
            { area: 'Erie', rate: 0.01, exemption: 25 },
            { area: 'Essex', rate: 0.0125, exemption: 25 },
            { area: 'Franklin', rate: 0.01, exemption: 25 },
            { area: 'Fulton', rate: 0.01, exemption: 25 },
            { area: 'Genesee', rate: 0.0125, exemption: 25 },
            { area: 'Greene', rate: 0.0125, exemption: 25 },
            { area: 'Hamilton', rate: 0.01, exemption: 25 },
            { area: 'Herkimer', rate: 0.01, exemption: 25 },
            { area: 'Jefferson', rate: 0.0075, exemption: 25 },
            { area: 'Lewis', rate: 0.01, exemption: 25 },
            { area: 'Livingston', rate: 0.0125, exemption: 25 },
            { area: 'Madison', rate: 0.01, exemption: 25 },
            { area: 'Monroe', rate: 0.01, exemption: 25 },
            { area: 'Montgomery', rate: 0.0075, exemption: 25 },
            { area: 'Nassau', rate: 0.0105, exemption: 30 },
            { area: 'Niagara', rate: 0.01, exemption: 25 },
            { area: 'Oneida', rate: 0.01, exemption: 25 },
            { area: 'Onondaga', rate: 0.01, exemption: 25 },
            { area: 'Ontario', rate: 0.01, exemption: 25 },
            { area: 'Orange', rate: 0.0105, exemption: 30 },
            { area: 'Orleans', rate: 0.01, exemption: 25 },
            { area: 'Oswego', rate: 0.01, exemption: 25 },
            { area: 'Otsego', rate: 0.01, exemption: 25 },
            { area: 'Putnam', rate: 0.0105, exemption: 30 },
            { area: 'Rensselaer', rate: 0.0125, exemption: 25 },
            { area: 'Rockland', rate: 0.013, exemption: 30 },
            { area: 'Saratoga', rate: 0.01, exemption: 25 },
            { area: 'Schenectady', rate: 0.0125, exemption: 25 },
            { area: 'Schoharie', rate: 0.01, exemption: 25 },
            { area: 'Schuyler', rate: 0.01, exemption: 25 },
            { area: 'Seneca', rate: 0.01, exemption: 25 },
            { area: 'St. Lawrence', rate: 0.0075, exemption: 25 },
            { area: 'Steuben', rate: 0.0125, exemption: 25 },
            { area: 'Suffolk', rate: 0.0105, exemption: 30 },
            { area: 'Sullivan', rate: 0.01, exemption: 25 },
            { area: 'Tioga', rate: 0.0075, exemption: 25 },
            { area: 'Tompkins', rate: 0.01, exemption: 25 },
            { area: 'Ulster', rate: 0.0075, exemption: 25 },
            { area: 'Warren', rate: 0.0125, exemption: 25 },
            { area: 'Washington', rate: 0.0125, exemption: 25 },
            { area: 'Wayne', rate: 0.0125, exemption: 25 },
            { area: 'Westchester', rate: 0.013, exemption: 30 },
            { area: 'Westchester - Yonkers', rate: 0.018, exemption: 30 },
            { area: 'Wyoming', rate: 0.0125, exemption: 25 },
            { area: 'Yates', rate: 0.01, exemption: 25 },
        ],
        meta: META,
    };
    /** NYC residential mortgage recording tax reference. */
    exports.NYC_MORTGAGE_TAX = {
        rateUnder500k: 0.0205,
        rate500kPlus: 0.02175,
        threshold: 500000,
        oneToTwoFamilyReduction: 30,
        meta: {
            effectiveDate: '2026-01-01',
            sourceName: 'NYC mortgage tax reference (uploaded knowledge pack, Tax Tables J7)',
            lastReviewed: '2026-01-01',
            confidence: 'planning-table',
            overrideAllowed: true,
        },
    };
    function lookupNyMortgageTax(area, table = exports.NY_MORTGAGE_TAX_TABLE) {
        var _a;
        return (_a = table.rows.find((r) => r.area === area)) !== null && _a !== void 0 ? _a : null;
    }
});
define("src/core/data/luxuryTaxes", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LUXURY_TAX_TABLE = void 0;
    exports.lookupLuxuryTaxRow = lookupLuxuryTaxRow;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'Mansion / luxury tax tiers (uploaded knowledge pack, Luxury Tax Tables)',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'New York tiers are a CLIFF structure: the tier rate applies to the entire purchase price. Seller-paid rows are shown for information and excluded from buyer cash to close.',
    };
    exports.LUXURY_TAX_TABLE = {
        id: 'luxury_mansion_taxes',
        title: 'Mansion / luxury taxes',
        description: 'Jurisdiction + price band -> rate, payer and buyer share.',
        columns: [
            { key: 'jurisdiction', label: 'Jurisdiction', type: 'text' },
            { key: 'minPrice', label: 'Min price', type: 'currency' },
            { key: 'maxPrice', label: 'Max price', type: 'currency' },
            { key: 'rate', label: 'Rate', type: 'percent' },
            { key: 'payer', label: 'Who pays', type: 'text' },
            { key: 'buyerShare', label: 'Buyer share', type: 'percent' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: [
            { jurisdiction: 'New York', state: 'New York', minPrice: 0, maxPrice: 999999.99, rate: 0, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'No mansion tax below $1M' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 1000000, maxPrice: 1999999.99, rate: 0.01, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 2000000, maxPrice: 2999999.99, rate: 0.0125, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 3000000, maxPrice: 4999999.99, rate: 0.015, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 5000000, maxPrice: 9999999.99, rate: 0.0225, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 10000000, maxPrice: 14999999.99, rate: 0.0325, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 15000000, maxPrice: 19999999.99, rate: 0.035, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 20000000, maxPrice: 24999999.99, rate: 0.0375, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New York', state: 'New York', minPrice: 25000000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.039, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'NY State mansion tax' },
            { jurisdiction: 'New Jersey', state: 'New Jersey', minPrice: 1000000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.01, payer: 'Buyer', buyerShare: 1, method: 'Full sale price', note: 'Approximate planning rate' },
            { jurisdiction: 'District of Columbia', state: 'District of Columbia', minPrice: 400000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.0145, payer: 'Split', buyerShare: 0.5, method: 'Full sale price x buyer share', note: 'Planning estimate' },
            { jurisdiction: 'Vermont', state: 'Vermont', minPrice: 5000000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.0125, payer: 'Split', buyerShare: 0.5, method: 'Full sale price x buyer share', note: 'Planning estimate; local rates vary' },
            { jurisdiction: 'California (LA City)', state: 'California', minPrice: 5300000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.04, payer: 'Seller', buyerShare: 0, method: 'Seller side only', note: 'LA "ULA" measure - excluded from buyer costs' },
            { jurisdiction: 'Connecticut', state: 'Connecticut', minPrice: 2500000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.0225, payer: 'Seller', buyerShare: 0, method: 'Seller side only', note: 'Excluded from buyer costs' },
            { jurisdiction: 'Washington', state: 'Washington', minPrice: 3000000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.03, payer: 'Seller', buyerShare: 0, method: 'Seller side only', note: 'Excluded from buyer costs' },
            { jurisdiction: 'Hawaii', state: 'Hawaii', minPrice: 600000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0.0125, payer: 'Seller', buyerShare: 0, method: 'Seller side only', note: 'Excluded from buyer costs' },
            { jurisdiction: 'Rhode Island', state: 'Rhode Island', minPrice: 800000, maxPrice: Number.MAX_SAFE_INTEGER, rate: 0, payer: 'Seller', buyerShare: 0, method: 'Seller side only', note: 'Rate not specified in source table' },
        ],
        meta: META,
    };
    function lookupLuxuryTaxRow(state, price, table = exports.LUXURY_TAX_TABLE) {
        const candidates = table.rows.filter((r) => r.state === state && price >= r.minPrice && price <= r.maxPrice);
        if (candidates.length === 0)
            return null;
        // Prefer a buyer-paid row when both a buyer and seller row match.
        candidates.sort((a, b) => b.buyerShare - a.buyerShare);
        return candidates[0];
    }
});
define("src/core/data/closingCostProfiles", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.STANDARD_THIRD_PARTY = exports.CLOSING_COST_PROFILES = exports.DEFAULT_CLOSING_PROFILE = void 0;
    exports.lookupClosingProfile = lookupClosingProfile;
    const META = {
        effectiveDate: '2026-01-01',
        sourceName: 'Generic state closing-cost planning model (title/settlement customs by state)',
        lastReviewed: '2026-01-01',
        confidence: 'planning-table',
        overrideAllowed: true,
        notes: 'Estimates scale with purchase price and loan amount. The title/escrow fee sheet is the final authority - every line can be overridden on the scenario.',
    };
    const P = (state, titlePer1000, settlementFee, attorneyFee, recordingFlat, survey, note = '') => ({
        state,
        titlePer1000,
        titleMin: 500,
        lenderTitlePer1000: 0.6,
        settlementFee,
        attorneyFee,
        recordingFlat,
        recordingPer1000: 0.15,
        survey,
        appraisalBase: 650,
        note,
    });
    /** Fallback used for any state without an explicit row. */
    exports.DEFAULT_CLOSING_PROFILE = P('Default', 4.0, 750, 0, 225, 0, 'National planning average');
    exports.CLOSING_COST_PROFILES = {
        id: 'state_closing_cost_profiles',
        title: 'State closing-cost profiles',
        description: 'Per-state title, settlement, attorney, recording and survey assumptions. Amounts are derived from purchase price and loan amount.',
        columns: [
            { key: 'state', label: 'State', type: 'text' },
            { key: 'titlePer1000', label: 'Title / $1,000 price', type: 'number' },
            { key: 'lenderTitlePer1000', label: "Lender's title / $1,000 loan", type: 'number' },
            { key: 'settlementFee', label: 'Settlement fee', type: 'currency' },
            { key: 'attorneyFee', label: 'Attorney fee', type: 'currency' },
            { key: 'recordingFlat', label: 'Recording', type: 'currency' },
            { key: 'survey', label: 'Survey', type: 'currency' },
            { key: 'appraisalBase', label: 'Appraisal', type: 'currency' },
            { key: 'note', label: 'Note', type: 'text' },
        ],
        rows: [
            P('Alabama', 3.4, 500, 500, 200, 400, 'Attorney customary for document preparation'),
            P('Alaska', 4.2, 800, 0, 250, 0),
            P('Arizona', 3.6, 750, 0, 200, 0, 'Escrow state'),
            P('Arkansas', 3.5, 600, 400, 175, 350),
            P('California', 3.2, 900, 0, 250, 0, 'Escrow state; city transfer taxes may add'),
            P('Colorado', 3.4, 700, 0, 200, 0),
            P('Connecticut', 4.4, 800, 1200, 275, 500, 'Attorney required'),
            P('Delaware', 4.6, 850, 1200, 300, 450, 'Attorney required'),
            P('District of Columbia', 4.8, 900, 1000, 350, 0),
            P('Florida', 5.75, 700, 0, 250, 400, 'Promulgated title rate; doc stamps on the note'),
            P('Georgia', 3.8, 700, 1000, 200, 0, 'Attorney closing state'),
            P('Hawaii', 3.9, 900, 0, 300, 600),
            P('Idaho', 3.6, 700, 0, 200, 0),
            P('Illinois', 4.1, 800, 900, 250, 500, 'Attorney customary in the Chicago area'),
            P('Indiana', 3.5, 650, 0, 200, 0),
            P('Iowa', 2.2, 650, 500, 175, 400, 'Title guaranty state'),
            P('Kansas', 3.4, 650, 0, 175, 400),
            P('Kentucky', 3.6, 700, 900, 200, 350, 'Attorney required'),
            P('Louisiana', 4.0, 800, 900, 250, 400, 'Notary/attorney closing'),
            P('Maine', 4.2, 800, 700, 250, 450),
            P('Maryland', 4.5, 850, 900, 300, 400),
            P('Massachusetts', 4.3, 900, 1300, 275, 500, 'Attorney required'),
            P('Michigan', 3.7, 700, 0, 200, 0),
            P('Minnesota', 3.5, 700, 0, 225, 400),
            P('Mississippi', 3.6, 650, 700, 175, 400),
            P('Missouri', 3.4, 650, 0, 175, 0),
            P('Montana', 3.6, 700, 0, 200, 0),
            P('Nebraska', 3.3, 650, 0, 175, 0),
            P('Nevada', 3.8, 800, 0, 225, 0, 'Escrow state'),
            P('New Hampshire', 4.2, 800, 900, 250, 450, 'Attorney required'),
            P('New Jersey', 4.4, 850, 1400, 300, 500, 'Attorney customary in North Jersey'),
            P('New Mexico', 3.7, 750, 0, 200, 0),
            P('New York', 4.6, 950, 2000, 350, 500, 'Attorney customary statewide; NYC adds fees'),
            P('North Carolina', 3.4, 700, 900, 200, 450, 'Attorney closing state'),
            P('North Dakota', 3.3, 650, 500, 175, 400),
            P('Ohio', 3.6, 700, 0, 200, 0),
            P('Oklahoma', 3.5, 650, 500, 175, 400),
            P('Oregon', 3.6, 750, 0, 225, 0),
            P('Pennsylvania', 5.2, 800, 0, 275, 450, 'Promulgated title rate'),
            P('Rhode Island', 4.3, 850, 900, 275, 450),
            P('South Carolina', 3.6, 750, 1100, 200, 450, 'Attorney required'),
            P('South Dakota', 3.3, 650, 500, 175, 400),
            P('Tennessee', 3.5, 700, 0, 200, 400),
            P('Texas', 5.4, 700, 0, 200, 550, 'Promulgated title rate; survey customary'),
            P('Utah', 3.5, 700, 0, 200, 0),
            P('Vermont', 4.2, 800, 1000, 250, 450, 'Attorney required'),
            P('Virginia', 3.7, 750, 600, 225, 400),
            P('Washington', 3.6, 800, 0, 250, 0, 'Escrow state'),
            P('West Virginia', 3.8, 700, 800, 200, 400),
            P('Wisconsin', 3.4, 700, 0, 200, 400),
            P('Wyoming', 3.4, 650, 0, 175, 0),
        ],
        meta: META,
    };
    function lookupClosingProfile(state, table = exports.CLOSING_COST_PROFILES) {
        var _a;
        return (_a = table.rows.find((r) => r.state === state)) !== null && _a !== void 0 ? _a : exports.DEFAULT_CLOSING_PROFILE;
    }
    /** Third-party fees that do not vary much by state. */
    exports.STANDARD_THIRD_PARTY = {
        creditReport: 85,
        floodCertificate: 20,
        taxService: 85,
        lenderProcessing: 995,
        homeInspection: 600,
        /** Extra appraisal cost for a renovation (as-is + as-completed) assignment. */
        renovationAppraisalAdder: 350,
        /** Additional 203(k)/HomeStyle lender fee. */
        renovationLenderFee: 350,
        meta: {
            effectiveDate: '2026-01-01',
            sourceName: 'Third-party fee planning averages',
            lastReviewed: '2026-01-01',
            confidence: 'planning-table',
            overrideAllowed: true,
        },
    };
});
define("src/core/calc/closing", ["require", "exports", "src/core/data/transferTaxes", "src/core/data/mortgageRecordingTax", "src/core/data/luxuryTaxes", "src/core/data/closingCostProfiles", "src/core/utils/dates", "src/core/utils/num", "src/core/calc/trace"], function (require, exports, transferTaxes_1, mortgageRecordingTax_1, luxuryTaxes_1, closingCostProfiles_1, dates_3, num_7, trace_7) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.estimateStateClosingCosts = estimateStateClosingCosts;
    exports.calculateMortgageTax = calculateMortgageTax;
    exports.calculateTransferTax = calculateTransferTax;
    exports.calculateLuxuryTax = calculateLuxuryTax;
    exports.calculatePerDiem = calculatePerDiem;
    exports.calculateClosingCosts = calculateClosingCosts;
    /**
     * estimateStateClosingCosts()
     *
     * Produces the itemised buyer fee estimate for ANY state from three inputs:
     * the state profile, the purchase price and the loan amount. Nothing here is
     * hard-coded to one market, and every line can be overridden per scenario.
     */
    function estimateStateClosingCosts(state, purchasePrice, loanAmount, renovationActive) {
        const p = (0, closingCostProfiles_1.lookupClosingProfile)(state);
        const price = (0, num_7.nonNegative)(purchasePrice);
        const loan = (0, num_7.nonNegative)(loanAmount);
        const t = closingCostProfiles_1.STANDARD_THIRD_PARTY;
        // Nothing has been entered yet - there is no transaction to price.
        if (price <= 0 && loan <= 0) {
            return estimateStateClosingCosts(state, 1, 0, renovationActive).map((f) => ({ ...f, amount: 0 }));
        }
        const titleOwner = Math.max(p.titleMin, (0, num_7.round)((price / 1000) * p.titlePer1000, 2));
        const titleLender = (0, num_7.round)((loan / 1000) * p.lenderTitlePer1000, 2);
        return [
            {
                key: 'lenderOrigination',
                label: 'Lender origination / underwriting',
                amount: renovationActive ? (0, num_7.round)(t.lenderProcessing + t.renovationLenderFee, 2) : t.lenderProcessing,
                category: 'lender',
                basis: renovationActive
                    ? `Flat underwriting fee + $${t.renovationLenderFee} renovation administration`
                    : 'Flat underwriting fee',
            },
            {
                key: 'lenderProcessing',
                label: 'Processing / document preparation',
                amount: 450,
                category: 'lender',
                basis: 'Flat',
            },
            {
                key: 'appraisal',
                label: 'Appraisal',
                amount: renovationActive ? (0, num_7.round)(p.appraisalBase + t.renovationAppraisalAdder, 2) : p.appraisalBase,
                category: 'other',
                basis: renovationActive
                    ? `${state} base appraisal + as-completed adder`
                    : `${state} base appraisal`,
            },
            { key: 'creditReport', label: 'Credit report', amount: t.creditReport, category: 'other', basis: 'Flat' },
            {
                key: 'floodTaxService',
                label: 'Flood certificate + tax service',
                amount: (0, num_7.round)(t.floodCertificate + t.taxService, 2),
                category: 'other',
                basis: 'Flat',
            },
            {
                key: 'titleInsurance',
                label: "Title insurance (owner's + lender's)",
                amount: (0, num_7.round)(titleOwner + titleLender, 2),
                category: 'title',
                basis: `${p.titlePer1000.toFixed(2)} per $1,000 of price + ${p.lenderTitlePer1000.toFixed(2)} per $1,000 of loan`,
            },
            {
                key: 'titleSearchSettlement',
                label: 'Title search + settlement / closing fee',
                amount: p.settlementFee,
                category: 'title',
                basis: `${state} settlement custom`,
            },
            {
                key: 'attorney',
                label: 'Attorney',
                amount: p.attorneyFee,
                category: 'title',
                basis: p.attorneyFee > 0 ? `${state} attorney closing custom` : 'Not customary in this state',
            },
            {
                key: 'survey',
                label: 'Survey',
                amount: p.survey,
                category: 'other',
                basis: p.survey > 0 ? `${state} survey custom` : 'Not customary in this state',
            },
            {
                key: 'recording',
                label: 'Recording fees',
                amount: (0, num_7.round)(p.recordingFlat + (loan / 1000) * p.recordingPer1000, 2),
                category: 'government',
                basis: `${state} recording schedule`,
            },
            {
                key: 'inspections',
                label: 'Home / pest inspections',
                amount: t.homeInspection,
                category: 'other',
                basis: 'Flat',
            },
            { key: 'other', label: 'Other buyer costs', amount: 0, category: 'other', basis: 'Manual' },
        ];
    }
    // ---------------------------------------------------------------------------
    // Government taxes
    // ---------------------------------------------------------------------------
    function calculateMortgageTax(inputs, totalLoan) {
        var _a, _b;
        const loan = (0, num_7.nonNegative)(totalLoan);
        if (inputs.state !== 'New York') {
            const rate = (0, num_7.nonNegative)(inputs.closing.otherStateMortgageTaxRate);
            return { amount: (0, num_7.round)(loan * rate, 2), rate, exemption: 0, basis: 'Non-NY state rate' };
        }
        if (inputs.isNYC) {
            const rate = loan < mortgageRecordingTax_1.NYC_MORTGAGE_TAX.threshold ? mortgageRecordingTax_1.NYC_MORTGAGE_TAX.rateUnder500k : mortgageRecordingTax_1.NYC_MORTGAGE_TAX.rate500kPlus;
            const exemption = mortgageRecordingTax_1.NYC_MORTGAGE_TAX.oneToTwoFamilyReduction;
            return {
                amount: Math.max(0, (0, num_7.round)(loan * rate - exemption, 2)),
                rate,
                exemption,
                basis: 'NYC residential mortgage recording tax',
            };
        }
        const row = (0, mortgageRecordingTax_1.lookupNyMortgageTax)(inputs.nyCounty);
        const rate = (_a = row === null || row === void 0 ? void 0 : row.rate) !== null && _a !== void 0 ? _a : 0;
        const exemption = (_b = row === null || row === void 0 ? void 0 : row.exemption) !== null && _b !== void 0 ? _b : 0;
        return {
            amount: Math.max(0, (0, num_7.round)(loan * rate - exemption, 2)),
            rate,
            exemption,
            basis: `${inputs.nyCounty} county mortgage recording tax`,
        };
    }
    function calculateTransferTax(inputs, price) {
        var _a, _b, _c;
        const p = (0, num_7.nonNegative)(price);
        if (inputs.state === 'New York') {
            const rate = (0, transferTaxes_1.nyTransferTaxRate)(p, inputs.isNYC);
            const total = (0, num_7.round)(p * rate, 2);
            return { total, buyerShare: 0, buyerAmount: 0, rate, payer: 'Seller' };
        }
        const row = (0, transferTaxes_1.lookupTransferTax)(inputs.state);
        const rate = (_a = row === null || row === void 0 ? void 0 : row.rate) !== null && _a !== void 0 ? _a : 0;
        const total = (0, num_7.round)(p * rate, 2);
        const buyerShare = (_b = row === null || row === void 0 ? void 0 : row.buyerShare) !== null && _b !== void 0 ? _b : 0;
        return {
            total,
            buyerShare,
            buyerAmount: (0, num_7.round)(total * buyerShare, 2),
            rate,
            payer: (_c = row === null || row === void 0 ? void 0 : row.payer) !== null && _c !== void 0 ? _c : 'None',
        };
    }
    function calculateLuxuryTax(state, finalPurchasePrice) {
        var _a;
        const price = (0, num_7.nonNegative)(finalPurchasePrice);
        const row = (0, luxuryTaxes_1.lookupLuxuryTaxRow)(state, price);
        if (!row || row.rate === 0) {
            return { buyer: 0, sellerInfo: 0, rate: 0, jurisdiction: (_a = row === null || row === void 0 ? void 0 : row.jurisdiction) !== null && _a !== void 0 ? _a : state };
        }
        const total = (0, num_7.round)(price * row.rate, 2);
        return {
            buyer: (0, num_7.round)(total * row.buyerShare, 2),
            sellerInfo: (0, num_7.round)(total * (1 - row.buyerShare), 2),
            rate: row.rate,
            jurisdiction: row.jurisdiction,
        };
    }
    function calculatePerDiem(totalLoan, annualRate, closingDate) {
        const days = (0, dates_3.perDiemDays)(closingDate);
        const daily = (0, num_7.round)(((0, num_7.nonNegative)(totalLoan) * (0, num_7.nonNegative)(annualRate)) / 365, 4);
        return { days, daily, total: (0, num_7.round)(daily * days, 2) };
    }
    /**
     * calculateClosingCosts()
     *
     * Buyer lines = state-driven fee estimate (or per-line override) + origination
     * points + government taxes + prepaids + per-diem interest. Every line appears
     * exactly once, and prepaids are EITHER the pickup months OR the aggregate
     * escrow deposit - never both.
     */
    function calculateClosingCosts({ inputs, purchase, loan, payment, escrow, renovationActive, trace, }) {
        const c = inputs.closing;
        const estimates = estimateStateClosingCosts(inputs.state, purchase.finalPurchasePrice, loan.totalLoan, renovationActive);
        const feeLines = estimates.map((e) => {
            const override = c.overrides[e.key];
            const overridden = override !== null && override !== undefined;
            return {
                key: e.key,
                label: e.label,
                amount: overridden ? (0, num_7.nonNegative)(override) : e.amount,
                category: e.category,
                payer: 'buyer',
                basis: e.basis,
                overridden,
            };
        });
        const originationPoints = (0, num_7.round)(loan.totalLoan * (0, num_7.nonNegative)(c.originationPointsPct), 2);
        const mortgageTax = calculateMortgageTax(inputs, loan.totalLoan);
        const baseTransfer = calculateTransferTax(inputs, purchase.basePurchasePrice);
        const finalTransfer = calculateTransferTax(inputs, purchase.finalPurchasePrice);
        const sellerTransferTaxDifference = (0, num_7.round)(finalTransfer.total - baseTransfer.total, 2);
        const luxury = calculateLuxuryTax(inputs.state, purchase.finalPurchasePrice);
        const useAggregate = c.useAggregateEscrowForPrepaids;
        const taxPickup = useAggregate ? 0 : (0, num_7.round)(payment.monthlyTaxes * (0, num_7.nonNegative)(c.taxPickupMonths), 2);
        const insurancePickup = useAggregate
            ? 0
            : (0, num_7.round)(payment.monthlyInsurance * (0, num_7.nonNegative)(c.insurancePickupMonths), 2);
        const initialEscrowSetup = useAggregate ? escrow.initialEscrowDeposit : 0;
        const perDiem = calculatePerDiem(loan.totalLoan, inputs.interestRate, inputs.closingDate);
        const lines = [
            ...feeLines,
            {
                key: 'points',
                label: 'Origination points',
                amount: originationPoints,
                category: 'lender',
                payer: 'buyer',
                basis: `${((0, num_7.nonNegative)(c.originationPointsPct) * 100).toFixed(3)}% of the total loan`,
            },
            {
                key: 'mortgageTax',
                label: 'Mortgage recording tax',
                amount: mortgageTax.amount,
                category: 'government',
                payer: 'buyer',
                basis: mortgageTax.basis,
            },
            {
                key: 'transferBuyer',
                label: 'Transfer tax (buyer share)',
                amount: finalTransfer.buyerAmount,
                category: 'government',
                payer: 'buyer',
                basis: `Typical payer: ${finalTransfer.payer}`,
            },
            {
                key: 'luxuryBuyer',
                label: 'Mansion / luxury tax (buyer)',
                amount: luxury.buyer,
                category: 'government',
                payer: 'buyer',
                basis: luxury.rate > 0 ? `${(luxury.rate * 100).toFixed(3)}% of the full purchase price` : 'No tier applies',
            },
            {
                key: 'prepaidTaxes',
                label: 'Prepaid / escrow property taxes',
                amount: taxPickup,
                category: 'prepaid',
                payer: 'buyer',
                basis: `${(0, num_7.nonNegative)(c.taxPickupMonths)} months`,
            },
            {
                key: 'prepaidInsurance',
                label: 'Prepaid / escrow insurance',
                amount: insurancePickup,
                category: 'prepaid',
                payer: 'buyer',
                basis: `${(0, num_7.nonNegative)(c.insurancePickupMonths)} months`,
            },
            {
                key: 'initialEscrow',
                label: 'Initial escrow deposit (aggregate analysis)',
                amount: initialEscrowSetup,
                category: 'prepaid',
                payer: 'buyer',
                basis: useAggregate ? 'Replaces the pickup-month estimate' : 'Not used - pickup months in effect',
            },
            {
                key: 'perDiem',
                label: 'Per-diem interest',
                amount: perDiem.total,
                category: 'prepaid',
                payer: 'buyer',
                basis: `${perDiem.days} days x ${perDiem.daily.toFixed(2)}`,
            },
            {
                key: 'transferSeller',
                label: 'Transfer tax (seller side - information only)',
                amount: (0, num_7.round)(finalTransfer.total - finalTransfer.buyerAmount, 2),
                category: 'government',
                payer: 'seller',
            },
            {
                key: 'luxurySeller',
                label: 'Mansion / luxury tax (seller side - information only)',
                amount: luxury.sellerInfo,
                category: 'government',
                payer: 'seller',
            },
        ];
        const buyerClosingCosts = (0, num_7.round)(lines.filter((l) => l.payer === 'buyer').reduce((acc, l) => acc + l.amount, 0), 2);
        const increment = c.roundingIncrement || 100;
        const buyerClosingCostsLow = (0, num_7.roundDownTo)(buyerClosingCosts, increment);
        const buyerClosingCostsHigh = (0, num_7.roundDownTo)(buyerClosingCosts * (1 + (0, num_7.nonNegative)(c.cushionPct)), increment);
        const nyOnlyBuyerItems = inputs.state === 'New York' ? mortgageTax.amount + luxury.buyer : 0;
        const estimateOutsideNewYork = (0, num_7.round)(buyerClosingCosts - nyOnlyBuyerItems, 2);
        const estimateNewYork = inputs.state === 'New York'
            ? buyerClosingCosts
            : (0, num_7.round)(buyerClosingCosts
                - mortgageTax.amount
                - luxury.buyer
                + calculateMortgageTax({ ...inputs, state: 'New York', nyCounty: inputs.nyCounty || 'Nassau', isNYC: false }, loan.totalLoan).amount
                + calculateLuxuryTax('New York', purchase.finalPurchasePrice).buyer, 2);
        const profile = (0, closingCostProfiles_1.lookupClosingProfile)(inputs.state);
        if (trace) {
            trace.record('stateFeeEstimate', 'State fee estimate', 'Each fee is derived from the state profile, the purchase price and the loan amount', [
                (0, trace_7.text)('State', inputs.state),
                (0, trace_7.money)('Purchase price', purchase.finalPurchasePrice),
                (0, trace_7.money)('Total loan', loan.totalLoan),
                ...feeLines.map((l) => (0, trace_7.money)(l.label, l.amount)),
            ], (0, num_7.round)(feeLines.reduce((a, l) => a + l.amount, 0), 2), {
                resultFormat: 'currency',
                overridesApplied: feeLines.filter((l) => l.overridden).map((l) => `${l.label} overridden`),
                notes: [profile.note || `${inputs.state} planning profile`],
            });
            trace.record('originationPoints', 'Origination points', 'Origination Points $ = Total Loan x Points %', [(0, trace_7.money)('Total loan', loan.totalLoan), (0, trace_7.pct)('Points %', c.originationPointsPct)], originationPoints, { resultFormat: 'currency' });
            trace.record('mortgageRecordingTax', 'Mortgage recording tax', inputs.state === 'New York'
                ? 'NY Mortgage Tax = MAX(0, Total Loan x County/NYC Rate - Residential Exemption)'
                : 'Mortgage Tax = Total Loan x State Rate', [
                (0, trace_7.money)('Total loan', loan.totalLoan),
                (0, trace_7.pct)('Rate', mortgageTax.rate),
                (0, trace_7.money)('Exemption', mortgageTax.exemption),
                (0, trace_7.text)('Basis', mortgageTax.basis),
            ], mortgageTax.amount, { resultFormat: 'currency' });
            trace.record('sellerTransferTax', 'Seller transfer tax', 'Base = Base Price x Rate; Final = Final Price x Rate; Difference = Final - Base', [
                (0, trace_7.money)('Base purchase price', purchase.basePurchasePrice),
                (0, trace_7.money)('Final purchase price', purchase.finalPurchasePrice),
                (0, trace_7.pct)('Rate', finalTransfer.rate),
                (0, trace_7.money)('Base transfer tax', baseTransfer.total),
                (0, trace_7.money)('Final transfer tax', finalTransfer.total),
            ], sellerTransferTaxDifference, {
                resultFormat: 'currency',
                notes: [`Typical payer: ${finalTransfer.payer}. Buyer planning share: ${(finalTransfer.buyerShare * 100).toFixed(0)}%.`],
            });
            trace.record('luxuryTax', 'Mansion / luxury tax', 'Luxury Tax = Final Purchase Price x Tier Rate x Buyer Share (cliff structure)', [(0, trace_7.money)('Final purchase price', purchase.finalPurchasePrice), (0, trace_7.pct)('Tier rate', luxury.rate), (0, trace_7.text)('Jurisdiction', luxury.jurisdiction)], luxury.buyer, { resultFormat: 'currency' });
            trace.record('perDiemInterest', 'Per-diem interest', 'Daily Interest = Total Loan x Rate / 365; Per-Diem = Daily x days to month end (inclusive)', [
                (0, trace_7.money)('Total loan', loan.totalLoan),
                (0, trace_7.pct)('Interest rate', inputs.interestRate),
                (0, trace_7.count)('Per-diem days', perDiem.days),
                (0, trace_7.money)('Daily interest', perDiem.daily),
            ], perDiem.total, { resultFormat: 'currency' });
            trace.record('buyerClosingCosts', 'Buyer closing costs', 'Sum of every buyer-paid line (lender + title + government + prepaid + other)', lines.filter((l) => l.payer === 'buyer').map((l) => (0, trace_7.money)(l.label, l.amount)), buyerClosingCosts, {
                resultFormat: 'currency',
                notes: [
                    useAggregate
                        ? 'Prepaids come from the aggregate escrow analysis; pickup months are excluded to avoid a double count.'
                        : 'Prepaids come from the tax/insurance pickup months; the aggregate escrow deposit is excluded to avoid a double count.',
                    `Low ${buyerClosingCostsLow.toFixed(0)} / High (with ${((0, num_7.nonNegative)(c.cushionPct) * 100).toFixed(0)}% cushion) ${buyerClosingCostsHigh.toFixed(0)}`,
                ],
            });
        }
        return {
            lines,
            buyerClosingCosts,
            buyerClosingCostsLow,
            buyerClosingCostsHigh,
            originationPoints,
            mortgageRecordingTax: mortgageTax.amount,
            baseSellerTransferTax: baseTransfer.total,
            finalSellerTransferTax: finalTransfer.total,
            sellerTransferTaxDifference,
            buyerLuxuryTax: luxury.buyer,
            sellerLuxuryTaxInfo: luxury.sellerInfo,
            taxPickup,
            insurancePickup,
            initialEscrowSetup,
            perDiemDays: perDiem.days,
            dailyInterest: perDiem.daily,
            perDiemInterest: perDiem.total,
            estimateSelectedState: buyerClosingCosts,
            estimateOutsideNewYork,
            estimateNewYork,
            estimateSelectedStateWithCushion: buyerClosingCostsHigh,
            stateCostProfile: profile.note || `${inputs.state} planning profile`,
        };
    }
});
define("src/core/calc/cashToClose", ["require", "exports", "src/core/utils/num", "src/core/calc/trace"], function (require, exports, num_8, trace_8) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculateCashToClose = calculateCashToClose;
    /**
     * calculateCashToClose()
     *
     *   Before EMD = MAX(0, Required Investment + Buyer Closing Costs - Seller Concession)
     *   After EMD  = MAX(0, Before EMD - Earnest Money Deposit)
     *
     * The seller concession is subtracted EXACTLY ONCE, here. The earnest money is
     * a credit toward the funds needed at the table; it does not reduce the
     * statutory minimum investment requirement, only the cash still to be brought.
     */
    function calculateCashToClose(inputs, purchase, loan, closing, trace) {
        const requiredInvestment = (0, num_8.nonNegative)(loan.requiredInvestment);
        // Only the part of the credit inside the interested-party-contribution limit
        // can reduce what the borrower brings; the excess is not usable.
        const concession = (0, num_8.nonNegative)(purchase.sellerConcessionAllowed);
        const emd = (0, num_8.nonNegative)(inputs.closing.earnestMoneyDeposit);
        const raw = (0, num_8.round)(requiredInvestment + closing.buyerClosingCosts - concession, 2);
        const cashToCloseBeforeEmd = Math.max(0, raw);
        const cashToClose = Math.max(0, (0, num_8.round)(cashToCloseBeforeEmd - emd, 2));
        const deficit = raw < 0 ? (0, num_8.round)(Math.abs(raw), 2) : 0;
        const cashToCloseLow = Math.max(0, (0, num_8.round)(requiredInvestment + closing.buyerClosingCostsLow - concession - emd, 2));
        const cashToCloseHigh = Math.max(0, (0, num_8.round)(requiredInvestment + closing.buyerClosingCostsHigh - concession - emd, 2));
        const cashToCloseOutsideNy = Math.max(0, (0, num_8.round)(requiredInvestment + closing.estimateOutsideNewYork - concession - emd, 2));
        const minimumInvestmentAfterEmd = Math.max(0, (0, num_8.round)(requiredInvestment - emd, 2));
        const emdCreditApplied = Math.min(emd, cashToCloseBeforeEmd);
        if (trace) {
            trace.record('cashToClose', 'Cash to close', 'Cash to Close = MAX(0, Required Investment + Buyer Closing Costs - Seller Concession - Earnest Money)', [
                (0, trace_8.money)('Required investment', requiredInvestment),
                (0, trace_8.money)('Buyer closing costs', closing.buyerClosingCosts),
                (0, trace_8.money)('Seller concession applied', concession),
                (0, trace_8.money)('Earnest money deposit', emd),
            ], cashToClose, {
                resultFormat: 'currency',
                limitsApplied: [
                    ...(raw < 0 ? ['Result floored at $0 - the credits exceed the required funds'] : []),
                    ...(purchase.sellerConcessionOverLimit > 0
                        ? [
                            `Seller credit capped at ${(purchase.sellerConcessionLimitPct * 100).toFixed(0)}% of the price (${purchase.concessionLimitNote})`,
                        ]
                        : []),
                ],
                notes: [
                    ...(purchase.sellerConcessionOverLimit > 0
                        ? [
                            `The seller credit entered is ${purchase.sellerConcessionAmount.toFixed(2)}; only ${concession.toFixed(2)} is inside the limit, so ${purchase.sellerConcessionOverLimit.toFixed(2)} is not applied.`,
                        ]
                        : []),
                    `Before the earnest money credit: ${cashToCloseBeforeEmd.toFixed(2)}`,
                    `Range: ${cashToCloseLow.toFixed(0)} (low closing costs) to ${cashToCloseHigh.toFixed(0)} (with cushion)`,
                    `Minimum investment after the EMD credit: ${minimumInvestmentAfterEmd.toFixed(2)}`,
                ],
            });
        }
        return {
            requiredInvestment,
            buyerClosingCosts: closing.buyerClosingCosts,
            sellerConcessionApplied: concession,
            earnestMoneyDeposit: emd,
            cashToCloseBeforeEmd,
            cashToClose,
            cashToCloseLow,
            cashToCloseHigh,
            cashToCloseOutsideNy,
            minimumInvestmentAfterEmd,
            emdCreditApplied,
            deficit,
        };
    }
});
define("src/core/calc/aus", ["require", "exports", "src/core/data/qualificationRules", "src/core/utils/num", "src/core/calc/trace"], function (require, exports, qualificationRules_2, num_9, trace_9) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.resolvePropertyType = resolvePropertyType;
    exports.unitsForPropertyType = unitsForPropertyType;
    exports.calculateAus = calculateAus;
    /** Property type from the entered unit rents, unless the user overrides it. */
    function resolvePropertyType(inputs) {
        if (inputs.rental.propertyTypeOverride !== 'Auto') {
            return { type: inputs.rental.propertyTypeOverride, source: 'Override' };
        }
        const r = inputs.rental;
        if ((0, num_9.nonNegative)(r.unit4.gross) > 0)
            return { type: '4 Family', source: 'Auto' };
        if ((0, num_9.nonNegative)(r.unit3.gross) > 0)
            return { type: '3 Family', source: 'Auto' };
        if ((0, num_9.nonNegative)(r.unit2.gross) > 0)
            return { type: '2 Family', source: 'Auto' };
        if ((0, num_9.nonNegative)(r.adu.gross) > 0)
            return { type: 'Single Family with ADU', source: 'Auto' };
        return { type: '1 Family', source: 'Auto' };
    }
    function unitsForPropertyType(type) {
        switch (type) {
            case '4 Family':
                return 4;
            case '3 Family':
                return 3;
            case '2 Family':
                return 2;
            default:
                return 1;
        }
    }
    /**
     * calculateAus() - borrower qualification, rental income, self-sufficiency,
     * reserves, DTI and the AUS risk scorecard.
     *
     * Key treatments:
     *  - MAIN unit rent is EXCLUDED from DTI income but INCLUDED in the FHA
     *    self-sufficiency test.
     *  - Reserves are measured on post-closing borrower-owned funds only; gift
     *    funds are tracked separately and never increase own-fund reserves.
     *  - A vacating-property rental shortfall becomes a monthly liability rather
     *    than negative income.
     */
    function calculateAus({ inputs, program, loan, payment, cashToCloseHigh, trace, }) {
        // ---- income & debts -----------------------------------------------------
        const totalGrossIncome = (0, num_9.round)((0, num_9.sum)(...inputs.borrowers.map((b) => (0, num_9.nonNegative)(b.grossMonthlyIncome))), 2);
        const totalOtherIncome = (0, num_9.round)((0, num_9.sum)(...inputs.borrowers.map((b) => (0, num_9.nonNegative)(b.otherMonthlyIncome))), 2);
        const totalBorrowerIncome = (0, num_9.round)(totalGrossIncome + totalOtherIncome, 2);
        const totalBorrowerDebts = (0, num_9.round)((0, num_9.sum)(...inputs.borrowers.map((b) => (0, num_9.nonNegative)(b.monthlyDebts))), 2);
        // ---- property type & rental income --------------------------------------
        const { type: propertyType, source: propertyTypeSource } = resolvePropertyType(inputs);
        const r = inputs.rental;
        const net = (unit, include) => include ? (0, num_9.round)((0, num_9.nonNegative)(unit.gross) * (0, num_9.nonNegative)(unit.qualifyingPct), 2) : 0;
        const isMulti = propertyType === '2 Family' || propertyType === '3 Family' || propertyType === '4 Family';
        const netQualifyingRent = {
            // The subject's main/owner unit never counts as qualifying income.
            main: 0,
            adu: net(r.adu, propertyType === 'Single Family with ADU'),
            unit2: net(r.unit2, isMulti),
            unit3: net(r.unit3, propertyType === '3 Family' || propertyType === '4 Family'),
            unit4: net(r.unit4, propertyType === '4 Family'),
        };
        const totalSubjectQualifyingRent = (0, num_9.round)(netQualifyingRent.adu + netQualifyingRent.unit2 + netQualifyingRent.unit3 + netQualifyingRent.unit4, 2);
        // Vacating departure residence (Conventional only in this planning model).
        const vacatingApplies = !program.isFha && r.includeVacatingRental;
        const vacatingNetAdjustment = vacatingApplies
            ? (0, num_9.round)((0, num_9.nonNegative)(r.vacatingGrossRent) * (0, num_9.nonNegative)(r.vacatingQualifyingPct) -
                (0, num_9.nonNegative)(r.vacatingHousingExpense), 2)
            : 0;
        const vacatingStatus = !vacatingApplies
            ? 'N/A'
            : vacatingNetAdjustment > 0
                ? `Income +${(0, num_9.currency)(vacatingNetAdjustment)}`
                : vacatingNetAdjustment < 0
                    ? `Debt +${(0, num_9.currency)(Math.abs(vacatingNetAdjustment))}`
                    : 'No adjustment';
        const rentalIncomeUsedForDti = (0, num_9.round)(totalSubjectQualifyingRent + Math.max(0, vacatingNetAdjustment), 2);
        // ---- FHA self-sufficiency ----------------------------------------------
        const unitCount = unitsForPropertyType(propertyType);
        const selfSufficiencyApplies = program.isFha && unitCount >= qualificationRules_2.SELF_SUFFICIENCY.minUnits;
        const grossUnitRents = [
            (0, num_9.nonNegative)(r.mainUnit.gross),
            (0, num_9.nonNegative)(r.unit2.gross),
            (0, num_9.nonNegative)(r.unit3.gross),
            (0, num_9.nonNegative)(r.unit4.gross),
        ].slice(0, Math.max(1, unitCount));
        const fhaSelfSufficiencyRent = selfSufficiencyApplies
            ? (0, num_9.round)(qualificationRules_2.SELF_SUFFICIENCY.rentFactor * (0, num_9.sum)(...grossUnitRents), 2)
            : 0;
        const housingPayment = payment.totalMonthlyPayment;
        const selfSufficiencyCushion = (0, num_9.round)(fhaSelfSufficiencyRent - housingPayment, 2);
        const selfSufficiencyStatus = !selfSufficiencyApplies
            ? 'N/A'
            : selfSufficiencyCushion >= 0
                ? `PASS by ${(0, num_9.currency)(selfSufficiencyCushion)}`
                : `FAIL by ${(0, num_9.currency)(Math.abs(selfSufficiencyCushion))}`;
        // ---- DTI ----------------------------------------------------------------
        const totalQualifyingIncome = (0, num_9.round)(totalBorrowerIncome + rentalIncomeUsedForDti, 2);
        const totalMonthlyLiabilities = (0, num_9.round)(totalBorrowerDebts + Math.max(0, -vacatingNetAdjustment), 2);
        const limits = (0, qualificationRules_2.dtiLimits)(program.isFha ? 'FHA' : 'Conventional');
        const frontEndDti = (0, num_9.safeDivide)(housingPayment, totalQualifyingIncome, 0);
        const backEndDti = (0, num_9.safeDivide)(housingPayment + totalMonthlyLiabilities, totalQualifyingIncome, 0);
        const frontEndResult = totalQualifyingIncome === 0 ? 'ENTER INCOME' : frontEndDti < limits.front ? 'PASS' : 'FAIL';
        const backEndResult = totalQualifyingIncome === 0 ? 'ENTER INCOME' : backEndDti < limits.back ? 'PASS' : 'FAIL';
        const overallDti = frontEndResult === 'ENTER INCOME' || backEndResult === 'ENTER INCOME'
            ? 'ENTER INCOME'
            : frontEndResult === 'PASS' && backEndResult === 'PASS'
                ? 'PASS'
                : 'FAIL';
        const maxSupportedHousingPayment = Math.max(0, (0, num_9.round)(Math.min(totalQualifyingIncome * limits.front, totalQualifyingIncome * limits.back - totalMonthlyLiabilities), 2));
        const paymentCushion = (0, num_9.round)(maxSupportedHousingPayment - housingPayment, 2);
        // ---- assets & reserves --------------------------------------------------
        const liquid = (0, num_9.nonNegative)(inputs.assets.liquidAssets);
        const retirement = (0, num_9.nonNegative)(inputs.assets.retirementOtherAssets);
        const gift = (0, num_9.nonNegative)(inputs.assets.giftFunds);
        const totalAssetsIncludingGift = (0, num_9.round)(liquid + retirement + gift, 2);
        const giftPctOfAssets = (0, num_9.safeDivide)(gift, totalAssetsIncludingGift, 0);
        const giftUtilization = gift <= 0 ? 'None' : giftPctOfAssets >= 0.5 ? '100%' : 'Partial';
        const assetsRemainingAfterClosing = Math.max(0, (0, num_9.round)(totalAssetsIncludingGift - cashToCloseHigh, 2));
        const ownFundReservesAfterClosing = Math.max(0, (0, num_9.round)(liquid + retirement - cashToCloseHigh, 2));
        const reserveMonthsAvailable = (0, num_9.safeDivide)(ownFundReservesAfterClosing, housingPayment, 0);
        const reserveRule = (0, qualificationRules_2.requiredReserveMonths)(program.isFha ? 'FHA' : 'Conventional', propertyType, loan.loanToCost);
        const requiredReserveDollars = (0, num_9.round)(housingPayment * reserveRule.months, 2);
        const reserveCushion = (0, num_9.round)(ownFundReservesAfterClosing - requiredReserveDollars, 2);
        const reserveStatus = reserveCushion >= 0 ? `PASS by ${(0, num_9.currency)(reserveCushion)}` : `FAIL by ${(0, num_9.currency)(Math.abs(reserveCushion))}`;
        const reservePass = reserveCushion >= 0;
        const overallRentalReserve = selfSufficiencyApplies
            ? reservePass && selfSufficiencyCushion >= 0
                ? 'PASS'
                : 'AT RISK'
            : reservePass
                ? 'PASS'
                : 'AT RISK';
        // ---- risk scorecard -----------------------------------------------------
        const creditScore = (0, num_9.nonNegative)(inputs.creditScore);
        const creditTier = (0, qualificationRules_2.creditTierFromScore)(creditScore);
        const creditRisk = creditScore > 640 ? 'PASS' : 'AT RISK';
        const dtiRisk = overallDti === 'PASS' ? 'PASS' : 'AT RISK';
        const assetRisk = assetsRemainingAfterClosing >= housingPayment * 3
            ? 'PASS'
            : assetsRemainingAfterClosing >= housingPayment
                ? 'HIGH RISK'
                : 'AT RISK';
        const reserveRisk = reserveMonthsAvailable >= reserveRule.months
            ? 'PASS'
            : reserveMonthsAvailable >= Math.max(1, reserveRule.months - 1)
                ? 'HIGH RISK'
                : 'AT RISK';
        const rentalRisk = overallRentalReserve === 'PASS' ? 'PASS' : 'AT RISK';
        const giftRisk = giftUtilization === 'None' ? 'PASS' : 'HIGH RISK';
        let score = 100;
        if (totalQualifyingIncome === 0)
            score -= 35;
        score -= creditScore < 640 ? 30 : creditScore < 680 ? 18 : creditScore < 700 ? 10 : 0;
        score -= backEndDti > limits.back ? 25 : backEndDti > 0.45 ? 10 : 0;
        score -= frontEndDti > limits.front ? 15 : 0;
        score -=
            reserveMonthsAvailable === 0
                ? 20
                : reserveMonthsAvailable < 2
                    ? 12
                    : reserveMonthsAvailable < reserveRule.months
                        ? 5
                        : 0;
        score -=
            assetsRemainingAfterClosing < housingPayment
                ? 15
                : assetsRemainingAfterClosing < housingPayment * 3
                    ? 7
                    : 0;
        score -= reserveCushion < 0 ? 20 : 0;
        score -= giftUtilization === '100%' ? 10 : giftUtilization === 'Partial' ? 4 : 0;
        score -= overallRentalReserve === 'AT RISK' ? 25 : 0;
        const ausPlanningScore = Math.max(0, Math.round(score));
        const overallRiskLevel = totalQualifyingIncome === 0 ||
            (creditScore > 0 && creditScore <= 640 && reserveMonthsAvailable === 0) ||
            reserveCushion < 0 ||
            overallRentalReserve === 'AT RISK'
            ? 'AT RISK'
            : ausPlanningScore >= 80
                ? 'PASS'
                : ausPlanningScore >= 60
                    ? 'HIGH RISK'
                    : 'AT RISK';
        if (trace) {
            trace.record('totalQualifyingIncome', 'Total qualifying income', 'Qualifying Income = Borrower Income + Subject Rental Income + MAX(0, Vacating Net Adjustment)', [
                (0, trace_9.money)('Borrower gross income', totalGrossIncome),
                (0, trace_9.money)('Borrower other income', totalOtherIncome),
                (0, trace_9.money)('Subject qualifying rent', totalSubjectQualifyingRent),
                (0, trace_9.money)('Vacating net adjustment', Math.max(0, vacatingNetAdjustment)),
            ], totalQualifyingIncome, {
                resultFormat: 'currency',
                notes: ['The subject main/owner unit rent is excluded from qualifying income.'],
            });
            trace.record('frontEndDti', 'Front-end DTI', 'Front-End DTI = Housing Payment / Total Qualifying Income', [(0, trace_9.money)('Housing payment', housingPayment), (0, trace_9.money)('Qualifying income', totalQualifyingIncome), (0, trace_9.pct)('Limit', limits.front)], frontEndDti, { resultFormat: 'percent', notes: [`Result: ${frontEndResult}`] });
            trace.record('backEndDti', 'Back-end DTI', 'Back-End DTI = (Housing Payment + Monthly Liabilities) / Total Qualifying Income', [
                (0, trace_9.money)('Housing payment', housingPayment),
                (0, trace_9.money)('Monthly liabilities', totalMonthlyLiabilities),
                (0, trace_9.money)('Qualifying income', totalQualifyingIncome),
                (0, trace_9.pct)('Limit', limits.back),
            ], backEndDti, { resultFormat: 'percent', notes: [`Result: ${backEndResult}`] });
            trace.record('selfSufficiency', 'FHA self-sufficiency test', 'Test Rent = 75% x gross rents of all legal units; Cushion = Test Rent - Housing Payment', [
                (0, trace_9.text)('Property type', propertyType),
                (0, trace_9.money)('75% test rent', fhaSelfSufficiencyRent),
                (0, trace_9.money)('Housing payment', housingPayment),
            ], selfSufficiencyCushion, {
                resultFormat: 'currency',
                notes: [
                    selfSufficiencyStatus,
                    `This planning model runs the test from ${qualificationRules_2.SELF_SUFFICIENCY.minUnits} units; FHA policy applies it to 3-4 unit properties.`,
                ],
            });
            trace.record('reserveCushion', 'Reserve cushion', 'Own-Fund Reserves After Closing - (Housing Payment x Required Months)', [
                (0, trace_9.money)('Liquid + retirement assets', (0, num_9.round)(liquid + retirement, 2)),
                (0, trace_9.money)('Cash to close (high)', cashToCloseHigh),
                (0, trace_9.money)('Own-fund reserves after closing', ownFundReservesAfterClosing),
                (0, trace_9.count)('Required reserve months', reserveRule.months),
                (0, trace_9.money)('Required reserve dollars', requiredReserveDollars),
            ], reserveCushion, {
                resultFormat: 'currency',
                notes: [reserveStatus, reserveRule.note, 'Gift funds do not count toward own-fund reserves.'],
            });
            trace.record('ausPlanningScore', 'AUS planning score', 'Starts at 100 and deducts for credit, DTI, reserves, assets, gift reliance and rental/self-sufficiency risk', [
                (0, trace_9.count)('Credit score', creditScore),
                (0, trace_9.pct)('Front-end DTI', frontEndDti),
                (0, trace_9.pct)('Back-end DTI', backEndDti),
                (0, trace_9.count)('Reserve months available', (0, num_9.round)(reserveMonthsAvailable, 2)),
                (0, trace_9.money)('Assets remaining after closing', assetsRemainingAfterClosing),
                (0, trace_9.text)('Gift utilisation', giftUtilization),
                (0, trace_9.text)('Rental / reserve', overallRentalReserve),
            ], ausPlanningScore, { resultFormat: 'number', notes: [`Overall risk level: ${overallRiskLevel}`] });
        }
        return {
            totalGrossIncome,
            totalOtherIncome,
            totalBorrowerIncome,
            totalBorrowerDebts,
            propertyType,
            propertyTypeSource,
            netQualifyingRent,
            totalSubjectQualifyingRent,
            vacatingNetAdjustment,
            vacatingStatus,
            rentalIncomeUsedForDti,
            fhaSelfSufficiencyRent,
            selfSufficiencyCushion,
            selfSufficiencyStatus,
            selfSufficiencyApplies,
            totalQualifyingIncome,
            totalMonthlyLiabilities,
            housingPayment,
            frontEndDti,
            backEndDti,
            frontEndLimit: limits.front,
            backEndLimit: limits.back,
            frontEndResult,
            backEndResult,
            overallDti,
            maxSupportedHousingPayment,
            paymentCushion,
            totalAssetsIncludingGift,
            giftPctOfAssets,
            giftUtilization,
            assetsRemainingAfterClosing,
            ownFundReservesAfterClosing,
            reserveMonthsAvailable,
            requiredReserveMonths: reserveRule.months,
            requiredReserveDollars,
            reserveCushion,
            reserveStatus,
            overallRentalReserve,
            creditTier,
            riskFactors: [
                { factor: 'Credit', result: creditRisk },
                { factor: 'DTI', result: dtiRisk },
                { factor: 'Assets', result: assetRisk },
                { factor: 'Reserves', result: reserveRisk },
                { factor: 'Rental / self-sufficiency', result: rentalRisk },
                { factor: 'Gift funds', result: giftRisk },
                { factor: 'Overall profile', result: overallRiskLevel },
            ],
            ausPlanningScore,
            overallRiskLevel,
            notes: reserveRule.note,
        };
    }
});
define("src/core/calc/mmw", ["require", "exports", "src/core/calc/loan", "src/core/utils/num"], function (require, exports, loan_1, num_10) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.buildMaximumMortgageWorksheet = buildMaximumMortgageWorksheet;
    /**
     * buildMaximumMortgageWorksheet()
     *
     * A modern rendering of HUD-92700 (203(k) and Streamlined(k) Maximum Mortgage
     * Worksheet), sections A, B, C plus the final loan / EMD block. Every line is
     * READ from the live engine - there is no second calculation and nothing to
     * keep in sync by hand. The verification block proves the worksheet and the
     * calculator agree.
     */
    function buildMaximumMortgageWorksheet(inputs, program, renovation, loan, closing, cash) {
        const price = (0, num_10.nonNegative)(inputs.basePurchasePrice);
        const finalPrice = loan.totalAcquisitionCost - renovation.finalRenovationAmount - renovation.energyImprovements;
        const asIs = (0, num_10.nonNegative)(inputs.asIsValue);
        const arv = (0, num_10.nonNegative)(inputs.afterRepairValue);
        const dpPct = (0, num_10.nonNegative)(inputs.finalDownPaymentPct);
        const basis = (0, loan_1.calculateValueBasis)(finalPrice, asIs, renovation.finalRenovationAmount, arv);
        const sectionA = [
            { ref: 'A1', label: 'Contract sales price', amount: (0, num_10.round)(finalPrice, 2), note: price !== finalPrice ? 'Includes the seller credit gross-up' : undefined },
            { ref: 'A2', label: 'As-is value', amount: asIs, note: asIs === 0 ? 'Not entered - the sales price is used' : undefined },
            { ref: 'A3', label: 'After-improved value (ARV)', amount: arv, note: arv === 0 ? 'Not entered - no 110% cap applied' : undefined },
            { ref: 'A4', label: '110% of after-improved value', amount: (0, num_10.round)(arv * 1.1, 2) },
            { ref: 'A5', label: 'Borrower-paid closing costs', amount: closing.buyerClosingCosts },
            { ref: 'A6', label: 'Allowable energy improvements', amount: renovation.energyImprovements },
        ];
        const sectionB = [
            { ref: 'B1', label: 'Total cost of repairs / construction', amount: renovation.baseCost },
            { ref: 'B2', label: 'Contingency reserve', amount: renovation.contingencyReserve, note: `${(inputs.reno.contingencyPct * 100).toFixed(0)}% of B1` },
            {
                ref: 'B3',
                label: 'Inspection fees + title update fees',
                amount: (0, num_10.round)(renovation.inspectionFees + renovation.titleUpdateFees, 2),
                note: `${renovation.drawCount} draw(s)`,
            },
            { ref: 'B4', label: 'Mortgage payments escrowed', amount: renovation.paymentReserve, note: `${inputs.reno.paymentReserveMonths} month(s) of PITI` },
            { ref: 'B5', label: 'Sub-total - rehabilitation escrow account', amount: renovation.rehabEscrowSubtotal },
            { ref: 'B6', label: 'Architectural / engineering fees', amount: (0, num_10.nonNegative)(inputs.reno.architectural) },
            { ref: 'B7', label: 'Consultant fees', amount: (0, num_10.nonNegative)(inputs.reno.consultant) },
            { ref: 'B8', label: 'Permits', amount: (0, num_10.nonNegative)(inputs.reno.permits) },
            {
                ref: 'B9',
                label: 'Other fees',
                amount: (0, num_10.round)((0, num_10.nonNegative)(inputs.reno.feasibilityOther) + (0, num_10.nonNegative)(inputs.reno.otherFinanceable), 2),
            },
            { ref: 'B10', label: 'Sub-total (B5 through B9)', amount: renovation.subtotalB10 },
            {
                ref: 'B11',
                label: 'Supplemental origination fee',
                amount: renovation.supplementalOrigination,
                note: 'Greater of $350 or 1.5% of B10',
            },
            {
                ref: 'B12',
                label: 'Discount points on repair costs and fees',
                amount: renovation.discountPointsRehab,
                note: `${(inputs.reno.discountPointsRehabPct * 100).toFixed(3)}% of B10`,
            },
            { ref: 'B13', label: 'Sub-total for release at closing', amount: renovation.releasedAtClosing },
            { ref: 'B14', label: 'Total rehabilitation cost', amount: renovation.finalRenovationAmount },
        ];
        const c1 = basis.c1;
        const c3 = basis.valueBasis;
        const c4 = (0, num_10.round)(c3 * (1 - dpPct) + renovation.energyImprovements, 2);
        const c5 = (0, num_10.round)(c3 * dpPct, 2);
        const c6 = (0, num_10.round)(c3 + closing.buyerClosingCosts - c4, 2);
        const c7 = loan.maximumBaseLoan;
        const sectionC = [
            { ref: 'C1', label: 'Lesser of sales price (A1) or as-is value (A2)', amount: (0, num_10.round)(c1, 2) },
            { ref: 'C2', label: 'Total rehabilitation cost (B14)', amount: renovation.finalRenovationAmount },
            {
                ref: 'C3',
                label: 'Lesser of C1 + C2 or 110% of after-improved value (A4)',
                amount: c3,
                note: basis.cappedByArv ? 'Capped by 110% of ARV' : 'Cost basis controls',
            },
            { ref: 'C4', label: 'Maximum base mortgage before the county limit', amount: c4 },
            { ref: 'C5', label: 'Statutory investment required (C3 x down payment %)', amount: c5 },
            { ref: 'C6', label: 'Actual cash investment requirement', amount: Math.max(0, c6) },
            { ref: 'C7', label: 'Adjusted maximum base mortgage (county limit applied)', amount: c7 },
        ];
        const finalBlock = [
            { ref: '', label: 'Adjusted maximum base mortgage', amount: loan.maximumBaseLoan },
            { ref: '', label: 'Estimated UFMIP', amount: loan.ufmip, note: `${(inputs.ufmipRate * 100).toFixed(3)}% of the capped base loan` },
            { ref: '', label: 'Total mortgage including UFMIP', amount: loan.totalLoan },
            { ref: '', label: 'Minimum investment total', amount: loan.requiredInvestment },
            { ref: '', label: 'Earnest money deposit', amount: cash.earnestMoneyDeposit },
            { ref: '', label: 'Minimum investment after EMD', amount: cash.minimumInvestmentAfterEmd },
            { ref: '', label: 'Cash to close before EMD', amount: cash.cashToCloseBeforeEmd },
            { ref: '', label: 'Cash to close after EMD', amount: cash.cashToClose },
        ];
        const near = (a, b) => Math.abs(a - b) < 0.01;
        const verification = [
            { label: 'Value basis (C3)', worksheet: c3, calculator: loan.valueBasis, match: near(c3, loan.valueBasis) },
            {
                label: 'Maximum base mortgage',
                worksheet: c7,
                calculator: loan.maximumBaseLoan,
                match: near(c7, loan.maximumBaseLoan),
            },
            {
                label: 'Minimum investment',
                worksheet: program.isFha ? c5 : loan.minimumStatutoryInvestment,
                calculator: loan.minimumStatutoryInvestment,
                match: near(program.isFha ? c5 : loan.minimumStatutoryInvestment, loan.minimumStatutoryInvestment),
            },
            {
                label: 'Total loan with UFMIP',
                worksheet: (0, num_10.round)(loan.maximumBaseLoan + loan.ufmip, 2),
                calculator: loan.totalLoan,
                match: near((0, num_10.round)(loan.maximumBaseLoan + loan.ufmip, 2), loan.totalLoan),
            },
            {
                label: 'Total rehabilitation cost',
                worksheet: renovation.finalRenovationAmount,
                calculator: renovation.finalRenovationAmount,
                match: true,
            },
        ];
        return {
            sectionA,
            sectionB,
            sectionC,
            finalBlock,
            verification,
            overallCheck: verification.every((v) => v.match) ? 'PASS - SYNCED' : 'REVIEW DIFFERENCES',
            countyLimitStatus: !program.fhaLimitsEnabled
                ? 'N/A'
                : loan.baseLoanBeforeLimits <= loan.fhaLimitApplied
                    ? 'WITHIN LIMIT'
                    : 'OVER LIMIT',
        };
    }
});
define("src/core/calc/bps", ["require", "exports", "src/core/utils/num"], function (require, exports, num_11) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LEAD_SOURCE_BPS = void 0;
    exports.calculateBps = calculateBps;
    exports.LEAD_SOURCE_BPS = {
        'Self Generated': 200,
        Corporate: 75,
        Manual: 0,
    };
    /**
     * calculateBps() - enter ONE of BPS / percentage / dollars and the others follow.
     *   BPS -> %    : bps / 10,000
     *   % -> BPS    : percentage x 10,000
     *   BPS -> $    : loan x bps / 10,000
     *   $ -> BPS    : dollars / loan x 10,000
     *   Capped $    : MIN(calculated, cap)
     */
    function calculateBps(bps, scenarioTotalLoan) {
        var _a;
        const suggestedBps = (_a = exports.LEAD_SOURCE_BPS[bps.leadSource]) !== null && _a !== void 0 ? _a : 0;
        const loanAmountUsed = (0, num_11.nonNegative)(bps.loanAmountOverride) > 0
            ? (0, num_11.nonNegative)(bps.loanAmountOverride)
            : (0, num_11.nonNegative)(scenarioTotalLoan);
        let effectiveBps = 0;
        let inputUsed = 'Enter one input';
        if (bps.bps !== null && bps.bps !== undefined && !Number.isNaN(bps.bps)) {
            effectiveBps = (0, num_11.nonNegative)(bps.bps);
            inputUsed = 'Manual BPS';
        }
        else if (bps.percent !== null && bps.percent !== undefined && !Number.isNaN(bps.percent)) {
            effectiveBps = (0, num_11.nonNegative)(bps.percent) * 10000;
            inputUsed = 'Manual percentage';
        }
        else if (bps.dollars !== null && bps.dollars !== undefined && !Number.isNaN(bps.dollars)) {
            effectiveBps = (0, num_11.safeDivide)((0, num_11.nonNegative)(bps.dollars), loanAmountUsed, 0) * 10000;
            inputUsed = 'Manual dollar amount';
        }
        else if (suggestedBps > 0) {
            effectiveBps = suggestedBps;
            inputUsed = `Lead source suggested BPS (${bps.leadSource})`;
        }
        const percent = effectiveBps / 10000;
        const dollars = (0, num_11.round)(loanAmountUsed * percent, 2);
        const cap = (0, num_11.nonNegative)(bps.cap);
        const cappedDollars = cap > 0 ? Math.min(dollars, cap) : dollars;
        return {
            suggestedBps,
            loanAmountUsed,
            effectiveBps: (0, num_11.round)(effectiveBps, 4),
            percent,
            dollars,
            cappedDollars,
            inputUsed,
            capApplied: cap > 0 && dollars > cap,
        };
    }
});
define("src/core/calc/warnings", ["require", "exports", "src/core/data/transferTaxes", "src/core/utils/num", "src/core/calc/purchase", "src/core/data/renovationRules"], function (require, exports, transferTaxes_2, num_12, purchase_1, renovationRules_4) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.buildWarnings = buildWarnings;
    /** buildWarnings() - the single source for the Warning Centre. */
    function buildWarnings(args) {
        var _a;
        const { inputs, program, renovationOut, loan, payment, value, closing, escrow, aus, mmw } = args;
        const w = [];
        const add = (code, severity, title, detail, module) => w.push({ code, severity, title, detail, module });
        // ---- FHA limits --------------------------------------------------------
        if (program.fhaLimitsEnabled) {
            if (loan.amountOverFhaLimit > 0) {
                add('FHA_OVER_LIMIT', 'error', 'LOAN EXCEEDS FHA LIMIT', `The base loan before limits (${(0, num_12.currency)(loan.baseLoanBeforeLimits)}) exceeds the applied ${loan.fhaTier} limit (${(0, num_12.currency)(loan.fhaLimitApplied)}) by ${(0, num_12.currency)(loan.amountOverFhaLimit)}. The loan has been capped; the borrower must bring the difference or restructure.`, 'loan');
            }
            if (loan.baseLoanBeforeLimits > loan.fhaStandardFloor) {
                add('FHA_CHECK_HIGH_COST', 'warning', 'CHECK HIGH-COST AREA', `The base loan (${(0, num_12.currency)(loan.baseLoanBeforeLimits)}) is above the standard FHA floor for ${inputs.units} unit(s) (${(0, num_12.currency)(loan.fhaStandardFloor)}). Confirm the exact county limit on the HUD lookup before quoting.`, 'loan');
            }
        }
        // ---- seller concession -------------------------------------------------
        const purchase = args.purchase;
        if (purchase.sellerConcessionOverLimit > 0) {
            add('CONCESSION_OVER_LIMIT', 'error', 'SELLER CREDIT OVER THE LIMIT', `The seller credit entered (${(0, num_12.currency)(purchase.sellerConcessionAmount)}) exceeds the ${(0, num_12.percent)(purchase.sellerConcessionLimitPct, 0)} interested-party limit for this file (${(0, num_12.currency)(purchase.sellerConcessionLimit)}) - ${purchase.concessionLimitNote}. Only ${(0, num_12.currency)(purchase.sellerConcessionAllowed)} has been applied to cash to close; the remaining ${(0, num_12.currency)(purchase.sellerConcessionOverLimit)} is not a usable credit.`, 'purchase');
        }
        else if (purchase.sellerConcessionAmount > 0 &&
            purchase.sellerConcessionAmount > purchase.sellerConcessionLimit * 0.9) {
            add('CONCESSION_OVER_LIMIT', 'info', 'Seller credit close to the limit', `The credit is ${(0, num_12.currency)(purchase.sellerConcessionAmount)} against a ${(0, num_12.percent)(purchase.sellerConcessionLimitPct, 0)} ceiling of ${(0, num_12.currency)(purchase.sellerConcessionLimit)} - ${purchase.concessionLimitNote}.`, 'purchase');
        }
        // ---- HomeStyle value ceiling -------------------------------------------
        if (!program.isFha && program.renovationActive && value.afterRepairValue > 0) {
            if (1 - inputs.finalDownPaymentPct > renovationRules_4.HOMESTYLE_MAX_LTV + 1e-9) {
                add('HOMESTYLE_LTV_CAP', 'warning', 'HOMESTYLE IS CAPPED AT 95% LTV', `A ${(0, num_12.percent)(inputs.finalDownPaymentPct, 2)} down payment implies ${(0, num_12.percent)(1 - inputs.finalDownPaymentPct, 2)} LTV, but HomeStyle is limited to ${(0, num_12.percent)(renovationRules_4.HOMESTYLE_MAX_LTV, 0)} of the as-completed value (${(0, num_12.currency)(value.arvLimitValue)}). The loan has been capped and the borrower must bring the difference.`, 'value');
            }
        }
        // ---- down payment ------------------------------------------------------
        const minDp = (0, purchase_1.minimumDownPaymentPct)(program.isFha, program.renovationActive, inputs.units);
        if (inputs.finalDownPaymentPct > 0 && inputs.finalDownPaymentPct < minDp) {
            add('INSUFFICIENT_DOWN_PAYMENT', 'error', 'Down payment below program minimum', `${program.label} planning minimum is ${(0, num_12.percent)(minDp, 2)}; the scenario uses ${(0, num_12.percent)(inputs.finalDownPaymentPct, 2)}.`, 'purchase');
        }
        if (inputs.finalDownPaymentPct === 0 && inputs.basePurchasePrice > 0) {
            add('INSUFFICIENT_DOWN_PAYMENT', 'warning', 'No down payment entered', 'A 0% down payment is not valid for FHA or Conventional purchase financing.', 'purchase');
        }
        // ---- value / appraisal -------------------------------------------------
        if (program.renovationActive && inputs.afterRepairValue <= 0 && loan.maximumBaseLoan > 0) {
            add('MISSING_APPRAISAL_VALUE', 'warning', 'No after-repair value entered', `No value cap has been applied. The transaction needs an ARV of at least ${(0, num_12.currency)(value.minimumArvNeeded)} to support the current loan.`, 'value');
        }
        else if (value.valueCushion !== null && value.valueCushion < 0) {
            add('ARV_SHORTFALL', 'error', 'ARV shortfall', `The appraised value supports only ${(0, num_12.currency)((_a = value.loanSupportedByValue) !== null && _a !== void 0 ? _a : 0)}. The loan is short by ${(0, num_12.currency)(Math.abs(value.valueCushion))}. Minimum ARV needed: ${(0, num_12.currency)(value.minimumArvNeeded)}.`, 'value');
        }
        if (program.renovationActive && inputs.asIsValue > 0 && inputs.asIsValue < value.minimumAsIsValueNeeded) {
            add('AS_IS_SHORTFALL', 'warning', 'As-is value shortfall', `The entered as-is value (${(0, num_12.currency)(inputs.asIsValue)}) is below the ${(0, num_12.currency)(value.minimumAsIsValueNeeded)} the structure needs.`, 'value');
        }
        // ---- mortgage insurance ------------------------------------------------
        if (program.pmiEnabled && payment.monthlyPmi > 0) {
            add('PMI_ESTIMATE_ONLY', 'info', 'Conventional PMI is an estimate', `Planning rate ${(0, num_12.percent)(payment.pmiRateUsed)} (${inputs.pmiOverrideRate > 0 ? 'manual override' : 'suggested from credit tier + down payment'}). The actual premium requires an MI insurer quote.`, 'payment');
        }
        if (program.fhaMipEnabled && Math.abs(payment.fhaMipRateUsed - payment.fhaMipSuggestedRate) > 1e-9) {
            add('PROGRAM_NOTE', 'info', 'FHA MIP rate differs from the suggested rate', `Using ${(0, num_12.percent)(payment.fhaMipRateUsed)}; the table suggests ${(0, num_12.percent)(payment.fhaMipSuggestedRate)} at ${(0, num_12.percent)(loan.loanToCost, 2)} loan-to-cost.`, 'payment');
        }
        // ---- state rules -------------------------------------------------------
        if (inputs.state !== 'New York') {
            add('NY_FIELDS_IGNORED', 'info', 'New York fields ignored', `State is ${inputs.state}. NY county, NYC toggle, NY mortgage tax and NY mansion tax are disabled and excluded from all calculations.`, 'closing');
            if (!(0, transferTaxes_2.lookupTransferTax)(inputs.state)) {
                add('MISSING_STATE_TAX_DATA', 'warning', 'No transfer-tax row for this state', `${inputs.state} is not in the transfer-tax reference table. $0 was used - verify with the title company.`, 'data');
            }
            if (inputs.closing.otherStateMortgageTaxRate === 0 &&
                ['Minnesota', 'Tennessee', 'Alabama', 'Florida', 'Kansas', 'Oklahoma', 'Virginia'].includes(inputs.state)) {
                add('MISSING_STATE_TAX_DATA', 'warning', 'Mortgage / recording tax rate may be missing', `${inputs.state} commonly charges a mortgage registration or documentary tax on the loan amount, but the non-NY mortgage tax rate is set to 0%.`, 'closing');
            }
        }
        // ---- tax data quality --------------------------------------------------
        if (inputs.taxSourceType === 'Manual' && inputs.propertyTaxAmount > 0) {
            add('MISSING_TAX_SOURCE', 'warning', 'Tax source not documented', 'Select the actual tax source (title certificate, assessor, or tax card) before disclosure.', 'escrow');
        }
        if (inputs.taxHasExemption) {
            add('TAX_EXEMPTION', 'warning', 'Current taxes include an exemption', `The current bill reflects a ${inputs.exemptionType || 'homestead/senior/veteran'} exemption that may not transfer. The borrower's actual taxes may be materially higher.`, 'escrow');
        }
        // ---- renovation --------------------------------------------------------
        if (program.renovationActive) {
            if (renovationOut.baseCost <= 0) {
                add('MISSING_RENOVATION_FEE', 'error', 'No renovation cost entered', 'The renovation program is selected but the base construction cost is $0.', 'renovation');
            }
            if (program.isFha && renovationOut.baseCost > 0 && (0, num_12.nonNegative)(inputs.reno.consultant) === 0) {
                add('MISSING_RENOVATION_FEE', 'warning', 'No 203(k) consultant fee', 'A standard 203(k) normally carries a consultant fee. Confirm the program type (limited vs standard).', 'renovation');
            }
            const inspectionMismatch = Math.abs(renovationOut.inspectionFees - renovationOut.expectedInspectionFees) > 0.5;
            const titleMismatch = Math.abs(renovationOut.titleUpdateFees - renovationOut.expectedTitleFees) > 0.5;
            if (inspectionMismatch || titleMismatch) {
                add('DRAW_FEE_MISMATCH', 'warning', 'Draw fees do not match the draw plan', `${renovationOut.drawCount} draw(s) implies ${(0, num_12.currency)(renovationOut.expectedInspectionFees)} inspections and ${(0, num_12.currency)(renovationOut.expectedTitleFees)} title updates; the budget carries ${(0, num_12.currency)(renovationOut.inspectionFees)} and ${(0, num_12.currency)(renovationOut.titleUpdateFees)}.`, 'renovation');
            }
            if (inputs.reno.contingencyPct < renovationOut.suggestedContingencyPct) {
                add('MISSING_RENOVATION_FEE', 'warning', 'Contingency below the suggested level', `With utilities ${inputs.reno.utilitiesOff ? 'off' : 'on'} the guide suggests ${(0, num_12.percent)(renovationOut.suggestedContingencyPct, 0)}; the budget uses ${(0, num_12.percent)(inputs.reno.contingencyPct, 0)}.`, 'renovation');
            }
        }
        // ---- worksheet sync -----------------------------------------------------
        if (mmw.overallCheck !== 'PASS - SYNCED') {
            add('MMW_SYNC', 'error', 'Maximum mortgage worksheet out of sync', 'A worksheet line does not match the calculator. Open the WORKSHEET tab and review the verification block.', 'loan');
        }
        // ---- closing costs / escrow -------------------------------------------
        if (closing.buyerClosingCosts <= 0 && loan.totalLoan > 0) {
            add('CLOSING_COST_ISSUE', 'warning', 'No buyer closing costs', 'Closing costs total $0. Check the state profile and the fee overrides.', 'closing');
        }
        if (closing.perDiemDays === 0 && loan.totalLoan > 0) {
            add('CLOSING_COST_ISSUE', 'info', 'No per-diem days', 'The estimated closing date falls at month end, so no prepaid interest is collected.', 'closing');
        }
        if (escrow.monthlyDeposit <= 0 && loan.totalLoan > 0) {
            add('ESCROW_SETUP', 'warning', 'No escrowed items', 'Annual taxes and insurance are $0, so the aggregate escrow analysis cannot produce a deposit.', 'escrow');
        }
        if (escrow.lowestTrialBalance < 0) {
            add('ESCROW_SETUP', 'warning', 'Projected escrow shortage', `The 12-month projection dips to ${(0, num_12.currency)(escrow.lowestTrialBalance)}. The initial deposit of ${(0, num_12.currency)(escrow.initialEscrowDeposit)} covers the shortage plus the ${escrow.cushionMonths}-month cushion.`, 'escrow');
        }
        if (inputs.taxInsuranceOverrideMonthly > 0) {
            add('PROGRAM_NOTE', 'info', 'Combined tax + insurance override active', `${(0, num_12.currency)(inputs.taxInsuranceOverrideMonthly)}/mo is replacing the separate tax and insurance figures in the payment. The escrow analysis still uses the itemised annual amounts.`, 'payment');
        }
        // ---- qualification ------------------------------------------------------
        if (aus.totalQualifyingIncome === 0) {
            add('MISSING_INCOME', 'warning', 'No borrower income entered', 'Enter income on the QUALIFY tab to run the DTI, reserve and AUS risk tests.', 'qualify');
        }
        else {
            if (aus.frontEndResult === 'FAIL') {
                add('DTI_FAIL', 'error', 'Front-end DTI over the limit', `Front-end ratio ${(0, num_12.percent)(aus.frontEndDti, 2)} exceeds the ${(0, num_12.percent)(aus.frontEndLimit, 0)} planning limit. Maximum supported housing payment: ${(0, num_12.currency)(aus.maxSupportedHousingPayment)}.`, 'qualify');
            }
            if (aus.backEndResult === 'FAIL') {
                add('DTI_FAIL', 'error', 'Back-end DTI over the limit', `Back-end ratio ${(0, num_12.percent)(aus.backEndDti, 2)} exceeds the ${(0, num_12.percent)(aus.backEndLimit, 0)} planning limit with ${(0, num_12.currency)(aus.totalMonthlyLiabilities)} of monthly liabilities.`, 'qualify');
            }
        }
        if (aus.reserveCushion < 0) {
            add('RESERVE_SHORTFALL', 'error', 'Post-closing reserve shortfall', `${aus.requiredReserveMonths} month(s) of reserves are required (${(0, num_12.currency)(aus.requiredReserveDollars)}); own funds after closing are ${(0, num_12.currency)(aus.ownFundReservesAfterClosing)}, short by ${(0, num_12.currency)(Math.abs(aus.reserveCushion))}.`, 'qualify');
        }
        if (aus.selfSufficiencyApplies && aus.selfSufficiencyCushion < 0) {
            add('SELF_SUFFICIENCY', 'error', 'FHA self-sufficiency shortfall', `75% of the unit rents (${(0, num_12.currency)(aus.fhaSelfSufficiencyRent)}) is below the housing payment (${(0, num_12.currency)(aus.housingPayment)}) by ${(0, num_12.currency)(Math.abs(aus.selfSufficiencyCushion))}.`, 'qualify');
        }
        if (aus.giftUtilization !== 'None') {
            add('GIFT_FUNDS', 'info', 'Gift funds in use', `Gift funds are ${(0, num_12.percent)(aus.giftPctOfAssets, 1)} of total assets. Gift money does not count toward post-closing own-fund reserves.`, 'qualify');
        }
        if (aus.totalQualifyingIncome > 0 && aus.assetsRemainingAfterClosing < aus.housingPayment) {
            add('ASSET_SHORTFALL', 'warning', 'Thin assets after closing', `Only ${(0, num_12.currency)(aus.assetsRemainingAfterClosing)} remains after closing - less than one monthly payment.`, 'qualify');
        }
        // ---- renovation off ----------------------------------------------------
        if (!program.renovationActive && inputs.reno.baseCost > 0) {
            add('PROGRAM_NOTE', 'info', 'Renovation values saved but excluded', `Renovation is set to No. ${(0, num_12.currency)(inputs.reno.baseCost)} of renovation input is retained and greyed out, and $0 is used in every calculation.`, 'renovation');
        }
        return w;
    }
});
define("src/core/data/states", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NY_AREAS = exports.US_STATES = void 0;
    exports.isValidState = isValidState;
    exports.US_STATES = [
        'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
        'Connecticut', 'Delaware', 'District of Columbia', 'Florida', 'Georgia',
        'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky',
        'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
        'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
        'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
        'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
        'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
        'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming',
    ];
    function isValidState(state) {
        return exports.US_STATES.includes(state);
    }
    /** NY counties / areas carried by the mortgage-recording-tax table. */
    exports.NY_AREAS = [
        'Albany', 'Allegany', 'Broome', 'Cattaraugus', 'Cayuga', 'Chautauqua',
        'Chemung', 'Chenango', 'Clinton', 'Columbia', 'Cortland', 'Delaware',
        'Dutchess', 'Erie', 'Essex', 'Franklin', 'Fulton', 'Genesee', 'Greene',
        'Hamilton', 'Herkimer', 'Jefferson', 'Lewis', 'Livingston', 'Madison',
        'Monroe', 'Montgomery', 'Nassau', 'Niagara', 'Oneida', 'Onondaga',
        'Ontario', 'Orange', 'Orleans', 'Oswego', 'Otsego', 'Putnam', 'Rensselaer',
        'Rockland', 'Saratoga', 'Schenectady', 'Schoharie', 'Schuyler', 'Seneca',
        'St. Lawrence', 'Steuben', 'Suffolk', 'Sullivan', 'Tioga', 'Tompkins',
        'Ulster', 'Warren', 'Washington', 'Wayne', 'Westchester',
        'Westchester - Yonkers', 'Wyoming', 'Yates',
    ];
});
define("src/core/calc/validate", ["require", "exports", "src/core/data/states", "src/core/utils/dates", "src/core/utils/num", "src/core/calc/aus"], function (require, exports, states_1, dates_4, num_13, aus_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.sanitizeInputs = sanitizeInputs;
    exports.validationWarnings = validationWarnings;
    /**
     * sanitizeInputs() - the single gate every scenario passes through before any
     * math runs. Impossible values are corrected here so no downstream function can
     * produce NaN, Infinity or a negative amount. It also performs the deterministic
     * auto-syncs (property type -> unit count, closing date -> first payment date).
     */
    function sanitizeInputs(raw) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
        const s = JSON.parse(JSON.stringify(raw));
        s.basePurchasePrice = (0, num_13.nonNegative)((0, num_13.num)(s.basePurchasePrice));
        s.sellerConcessionPct = (0, num_13.clamp)((0, num_13.num)(s.sellerConcessionPct), 0, 1);
        s.sellerConcessionAmount = (0, num_13.nonNegative)((0, num_13.num)(s.sellerConcessionAmount));
        s.baseDownPaymentPct = (0, num_13.clamp)((0, num_13.num)(s.baseDownPaymentPct), 0, 1);
        s.finalDownPaymentPct = (0, num_13.clamp)((0, num_13.num)(s.finalDownPaymentPct), 0, 1);
        s.creditScore = Math.round((0, num_13.clamp)((0, num_13.num)(s.creditScore), 0, 850));
        s.termYears = Math.round((0, num_13.clamp)((0, num_13.num)(s.termYears, 30), 1, 50));
        s.interestRate = (0, num_13.clamp)((0, num_13.num)(s.interestRate), 0, 0.5);
        s.ufmipRate = (0, num_13.clamp)((0, num_13.num)(s.ufmipRate), 0, 0.1);
        s.fhaAnnualMipRate = (0, num_13.clamp)((0, num_13.num)(s.fhaAnnualMipRate), 0, 0.05);
        s.fhaMipOverrideRate = (0, num_13.clamp)((0, num_13.num)(s.fhaMipOverrideRate), 0, 0.05);
        s.pmiOverrideRate = (0, num_13.clamp)((0, num_13.num)(s.pmiOverrideRate), 0, 0.05);
        s.conventionalRatePremiumApplied = (0, num_13.clamp)((0, num_13.num)(s.conventionalRatePremiumApplied), 0, 0.05);
        s.asIsValue = (0, num_13.nonNegative)((0, num_13.num)(s.asIsValue));
        s.afterRepairValue = (0, num_13.nonNegative)((0, num_13.num)(s.afterRepairValue));
        s.projection = {
            years: Math.round((0, num_13.clamp)((0, num_13.num)((_a = s.projection) === null || _a === void 0 ? void 0 : _a.years, 5), 0, 30)),
            appreciationRateOverride: (0, num_13.clamp)((0, num_13.num)((_b = s.projection) === null || _b === void 0 ? void 0 : _b.appreciationRateOverride), 0, 0.25),
        };
        s.propertyTaxAmount = (0, num_13.nonNegative)((0, num_13.num)(s.propertyTaxAmount));
        s.insuranceAmount = (0, num_13.nonNegative)((0, num_13.num)(s.insuranceAmount));
        s.taxInsuranceOverrideMonthly = (0, num_13.nonNegative)((0, num_13.num)(s.taxInsuranceOverrideMonthly));
        s.hoaMonthly = (0, num_13.nonNegative)((0, num_13.num)(s.hoaMonthly));
        // renovation
        s.reno.baseCost = (0, num_13.nonNegative)((0, num_13.num)(s.reno.baseCost));
        s.reno.architectural = (0, num_13.nonNegative)((0, num_13.num)(s.reno.architectural));
        s.reno.consultant = (0, num_13.nonNegative)((0, num_13.num)(s.reno.consultant));
        s.reno.inspectionFees = (0, num_13.nonNegative)((0, num_13.num)(s.reno.inspectionFees));
        s.reno.titleUpdateFees = (0, num_13.nonNegative)((0, num_13.num)(s.reno.titleUpdateFees));
        s.reno.permits = (0, num_13.nonNegative)((0, num_13.num)(s.reno.permits));
        s.reno.feasibilityOther = (0, num_13.nonNegative)((0, num_13.num)(s.reno.feasibilityOther));
        s.reno.otherFinanceable = (0, num_13.nonNegative)((0, num_13.num)(s.reno.otherFinanceable));
        s.reno.contingencyPct = (0, num_13.clamp)((0, num_13.num)(s.reno.contingencyPct), 0, 1);
        s.reno.supplementalOriginationOverride = (0, num_13.nonNegative)((0, num_13.num)(s.reno.supplementalOriginationOverride));
        s.reno.discountPointsRehabPct = (0, num_13.clamp)((0, num_13.num)(s.reno.discountPointsRehabPct), 0, 0.1);
        s.reno.paymentReserveMonths = Math.round((0, num_13.clamp)((0, num_13.num)(s.reno.paymentReserveMonths), 0, 6));
        s.reno.energyImprovements = (0, num_13.nonNegative)((0, num_13.num)(s.reno.energyImprovements));
        s.reno.utilitiesOff = Boolean(s.reno.utilitiesOff);
        s.reno.syncDrawFees = Boolean(s.reno.syncDrawFees);
        s.draws.manualDrawCount = Math.round((0, num_13.clamp)((0, num_13.num)(s.draws.manualDrawCount, 1), 0, 12));
        s.draws.inspectionFeePerDraw = (0, num_13.nonNegative)((0, num_13.num)(s.draws.inspectionFeePerDraw));
        s.draws.titleFeePerDraw = (0, num_13.nonNegative)((0, num_13.num)(s.draws.titleFeePerDraw));
        s.draws.initialMaterialRelease = (0, num_13.nonNegative)((0, num_13.num)(s.draws.initialMaterialRelease));
        // closing
        const ov = s.closing.overrides;
        Object.keys(ov).forEach((k) => {
            ov[k] = ov[k] === null || ov[k] === undefined ? null : (0, num_13.nonNegative)((0, num_13.num)(ov[k]));
        });
        s.closing.originationPointsPct = (0, num_13.clamp)((0, num_13.num)(s.closing.originationPointsPct), 0, 0.1);
        s.closing.otherStateMortgageTaxRate = (0, num_13.clamp)((0, num_13.num)(s.closing.otherStateMortgageTaxRate), 0, 0.1);
        s.closing.taxPickupMonths = Math.round((0, num_13.clamp)((0, num_13.num)(s.closing.taxPickupMonths), 0, 24));
        s.closing.insurancePickupMonths = Math.round((0, num_13.clamp)((0, num_13.num)(s.closing.insurancePickupMonths), 0, 24));
        s.closing.cushionPct = (0, num_13.clamp)((0, num_13.num)(s.closing.cushionPct), 0, 1);
        s.closing.roundingIncrement = (0, num_13.num)(s.closing.roundingIncrement, 100) || 100;
        s.closing.earnestMoneyDeposit = (0, num_13.nonNegative)((0, num_13.num)(s.closing.earnestMoneyDeposit));
        // escrow
        s.escrow.annualFlood = (0, num_13.nonNegative)((0, num_13.num)(s.escrow.annualFlood));
        s.escrow.cushionMonthsOverride = Math.round((0, num_13.clamp)((0, num_13.num)(s.escrow.cushionMonthsOverride, -1), -1, 12));
        s.paymentRoundingIncrement = (0, num_13.num)(s.paymentRoundingIncrement, 50) || 50;
        s.bps.cap = (0, num_13.nonNegative)((0, num_13.num)(s.bps.cap));
        s.bps.loanAmountOverride = (0, num_13.nonNegative)((0, num_13.num)(s.bps.loanAmountOverride));
        // borrowers, assets, rental
        s.borrowers = (Array.isArray(s.borrowers) ? s.borrowers : []).slice(0, 4);
        while (s.borrowers.length < 4) {
            s.borrowers.push({ name: `Borrower ${s.borrowers.length + 1}`, grossMonthlyIncome: 0, otherMonthlyIncome: 0, monthlyDebts: 0 });
        }
        s.borrowers = s.borrowers.map((b, i) => ({
            name: (b === null || b === void 0 ? void 0 : b.name) || `Borrower ${i + 1}`,
            grossMonthlyIncome: (0, num_13.nonNegative)((0, num_13.num)(b === null || b === void 0 ? void 0 : b.grossMonthlyIncome)),
            otherMonthlyIncome: (0, num_13.nonNegative)((0, num_13.num)(b === null || b === void 0 ? void 0 : b.otherMonthlyIncome)),
            monthlyDebts: (0, num_13.nonNegative)((0, num_13.num)(b === null || b === void 0 ? void 0 : b.monthlyDebts)),
        }));
        s.assets = {
            liquidAssets: (0, num_13.nonNegative)((0, num_13.num)((_c = s.assets) === null || _c === void 0 ? void 0 : _c.liquidAssets)),
            retirementOtherAssets: (0, num_13.nonNegative)((0, num_13.num)((_d = s.assets) === null || _d === void 0 ? void 0 : _d.retirementOtherAssets)),
            giftFunds: (0, num_13.nonNegative)((0, num_13.num)((_e = s.assets) === null || _e === void 0 ? void 0 : _e.giftFunds)),
        };
        const unit = (u) => ({
            gross: (0, num_13.nonNegative)((0, num_13.num)(u === null || u === void 0 ? void 0 : u.gross)),
            qualifyingPct: (0, num_13.clamp)((0, num_13.num)(u === null || u === void 0 ? void 0 : u.qualifyingPct, 0.75), 0, 1),
        });
        s.rental = {
            mainUnit: unit((_f = s.rental) === null || _f === void 0 ? void 0 : _f.mainUnit),
            adu: unit((_g = s.rental) === null || _g === void 0 ? void 0 : _g.adu),
            unit2: unit((_h = s.rental) === null || _h === void 0 ? void 0 : _h.unit2),
            unit3: unit((_j = s.rental) === null || _j === void 0 ? void 0 : _j.unit3),
            unit4: unit((_k = s.rental) === null || _k === void 0 ? void 0 : _k.unit4),
            propertyTypeOverride: (_m = (_l = s.rental) === null || _l === void 0 ? void 0 : _l.propertyTypeOverride) !== null && _m !== void 0 ? _m : 'Auto',
            includeVacatingRental: Boolean((_o = s.rental) === null || _o === void 0 ? void 0 : _o.includeVacatingRental),
            vacatingGrossRent: (0, num_13.nonNegative)((0, num_13.num)((_p = s.rental) === null || _p === void 0 ? void 0 : _p.vacatingGrossRent)),
            vacatingQualifyingPct: (0, num_13.clamp)((0, num_13.num)((_q = s.rental) === null || _q === void 0 ? void 0 : _q.vacatingQualifyingPct, 0.75), 0, 1),
            vacatingHousingExpense: (0, num_13.nonNegative)((0, num_13.num)((_r = s.rental) === null || _r === void 0 ? void 0 : _r.vacatingHousingExpense)),
        };
        // ---- deterministic auto-syncs ------------------------------------------
        const propertyType = (0, aus_1.resolvePropertyType)(s).type;
        s.units = Math.round((0, num_13.clamp)((0, num_13.num)(s.units, 1), 1, 4));
        const impliedUnits = (0, aus_1.unitsForPropertyType)(propertyType);
        if (impliedUnits > 1)
            s.units = impliedUnits;
        if (!(0, states_1.isValidState)(s.state))
            s.state = 'New York';
        if (s.state !== 'New York')
            s.isNYC = false;
        if (!(0, dates_4.isValidISO)(s.asOfDate))
            s.asOfDate = new Date().toISOString().slice(0, 10);
        if (!(0, dates_4.isValidISO)(s.closingDate))
            s.closingDate = s.asOfDate;
        if (s.escrow.autoFirstPaymentDate || !(0, dates_4.isValidISO)(s.escrow.firstPaymentDate)) {
            s.escrow.firstPaymentDate = (0, dates_4.defaultFirstPaymentDate)(s.closingDate);
        }
        if (s.loanProgram !== 'FHA' && s.loanProgram !== 'Conventional')
            s.loanProgram = 'FHA';
        s.renovation = Boolean(s.renovation);
        s.zipCode = String((_s = s.zipCode) !== null && _s !== void 0 ? _s : '').replace(/\D/g, '').slice(0, 5);
        return s;
    }
    /** Hard validation errors surfaced in the warning centre. */
    function validationWarnings(raw) {
        var _a, _b;
        const w = [];
        const push = (title, detail, module) => w.push({ code: 'VALIDATION', severity: 'error', title, detail, module });
        if ((0, num_13.num)(raw.basePurchasePrice) < 0)
            push('Negative purchase price', 'Purchase price cannot be negative; $0 was used.', 'purchase');
        if ((0, num_13.num)((_a = raw.reno) === null || _a === void 0 ? void 0 : _a.baseCost) < 0)
            push('Negative renovation cost', 'Renovation cost cannot be negative; $0 was used.', 'renovation');
        if ((0, num_13.num)(raw.finalDownPaymentPct) < 0 || (0, num_13.num)(raw.finalDownPaymentPct) > 1)
            push('Invalid down payment percentage', 'Down payment must be between 0% and 100%.', 'purchase');
        if ((0, num_13.num)(raw.units) < 1 || (0, num_13.num)(raw.units) > 4)
            push('Invalid unit count', 'Unit count must be 1 to 4; the value was clamped.', 'loan');
        if ((0, num_13.num)(raw.termYears) < 1 || (0, num_13.num)(raw.termYears) > 50)
            push('Invalid loan term', 'Loan term must be between 1 and 50 years.', 'payment');
        if (!(0, states_1.isValidState)(raw.state))
            push('Invalid state', 'The selected state is not recognised; New York was used.', 'data');
        if (!(0, dates_4.isValidISO)(raw.closingDate))
            push('Invalid closing date', 'The estimated closing date is not a real calendar date.', 'closing');
        if (raw.loanProgram !== 'FHA' && raw.loanProgram !== 'Conventional')
            push('Invalid loan program', 'Loan program must be FHA or Conventional.', 'program');
        if ((0, num_13.num)((_b = raw.reno) === null || _b === void 0 ? void 0 : _b.paymentReserveMonths) > 6)
            push('Payment reserve above 6 months', 'Mortgage payment reserves are limited to 0-6 months in this planning model.', 'renovation');
        return w;
    }
});
define("src/core/calc/engine", ["require", "exports", "src/core/data/stateClosingRules", "src/core/data/transferTaxes", "src/core/data/escrowRules", "src/core/data/marketData", "src/core/utils/num", "src/core/calc/trace", "src/core/calc/program", "src/core/calc/purchase", "src/core/calc/renovation", "src/core/calc/loan", "src/core/calc/payment", "src/core/calc/value", "src/core/calc/escrow", "src/core/calc/closing", "src/core/calc/cashToClose", "src/core/calc/aus", "src/core/calc/mmw", "src/core/calc/bps", "src/core/calc/warnings", "src/core/calc/validate"], function (require, exports, stateClosingRules_1, transferTaxes_3, escrowRules_2, marketData_2, num_14, trace_10, program_1, purchase_2, renovation_1, loan_2, payment_1, value_1, escrow_1, closing_1, cashToClose_1, aus_2, mmw_1, bps_1, warnings_1, validate_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.runScenario = runScenario;
    /**
     * runScenario() - the ONE entry point. Pure function: same inputs, same outputs,
     * no hidden state, no mutation of the caller's object.
     *
     * DEPENDENCY CHAIN (strictly one direction, no cycles):
     *
     *   sanitise
     *     -> program switches
     *     -> purchase / seller concession / down payment
     *     -> renovation  (pass 1: WITHOUT the mortgage payment reserve)
     *     -> value basis -> statutory investment -> base loan -> limits -> UFMIP
     *     -> payment  (pass 1)
     *     -> [ payment reserve = pass-1 payment x reserve months ]
     *     -> renovation  (pass 2: WITH the reserve)
     *     -> value basis -> statutory investment -> base loan -> limits -> UFMIP
     *     -> payment  (final)
     *     -> value / equity / projection
     *     -> escrow -> closing costs -> cash to close
     *     -> qualification (AUS) -> maximum mortgage worksheet -> BPS -> warnings
     *
     * WHY TWO PASSES: the mortgage payment reserve is "total monthly payment x
     * reserve months" and it is financed inside the renovation budget, so a naive
     * implementation is circular. The reserve is calculated from the PRELIMINARY
     * payment and then held fixed. Deterministic, no iteration. With reserve months
     * = 0 (the default) the two passes are identical.
     */
    function runScenario(rawInputs) {
        const inputs = (0, validate_1.sanitizeInputs)(rawInputs);
        const trace = new trace_10.TraceCollector();
        const program = (0, program_1.calculateProgram)(inputs.loanProgram, inputs.renovation);
        const purchase = (0, purchase_2.calculatePurchase)(inputs, trace);
        // ---- PASS 1 (preliminary - no financed payment reserve) ----------------
        const prelimReno = (0, renovation_1.calculateRenovation)(inputs, program.renovationActive, 0);
        const prelimLoan = (0, loan_2.calculateLoan)({
            inputs,
            program,
            purchase,
            finalRenovationAmount: prelimReno.finalRenovationAmount,
            energyImprovements: prelimReno.energyImprovements,
        });
        const prelimPayment = (0, payment_1.calculatePayment)({
            inputs,
            program,
            loan: prelimLoan,
            finalPurchasePrice: purchase.finalPurchasePrice,
            renovationAmount: prelimReno.finalRenovationAmount,
        });
        const reserveMonths = program.renovationActive ? inputs.reno.paymentReserveMonths : 0;
        const paymentReserve = (0, num_14.round)(prelimPayment.totalMonthlyPayment * reserveMonths, 2);
        // ---- PASS 2 (final) ----------------------------------------------------
        const renovationOut = (0, renovation_1.calculateRenovation)(inputs, program.renovationActive, paymentReserve, trace);
        const loan = (0, loan_2.calculateLoan)({
            inputs,
            program,
            purchase,
            finalRenovationAmount: renovationOut.finalRenovationAmount,
            energyImprovements: renovationOut.energyImprovements,
            trace,
        });
        const payment = (0, payment_1.calculatePayment)({
            inputs,
            program,
            loan,
            finalPurchasePrice: purchase.finalPurchasePrice,
            renovationAmount: renovationOut.finalRenovationAmount,
            trace,
        });
        const value = (0, value_1.calculateValue)(inputs, program, loan, renovationOut.finalRenovationAmount, purchase.finalPurchasePrice, trace);
        const escrowOut = (0, escrow_1.calculateEscrow)(inputs, payment, trace);
        const closing = (0, closing_1.calculateClosingCosts)({
            inputs,
            purchase,
            loan,
            payment,
            escrow: escrowOut,
            renovationActive: program.renovationActive,
            trace,
        });
        const cash = (0, cashToClose_1.calculateCashToClose)(inputs, purchase, loan, closing, trace);
        const aus = (0, aus_2.calculateAus)({
            inputs,
            program,
            loan,
            payment,
            cashToCloseHigh: cash.cashToCloseHigh,
            trace,
        });
        const mmw = (0, mmw_1.buildMaximumMortgageWorksheet)(inputs, program, renovationOut, loan, closing, cash);
        const bpsOut = (0, bps_1.calculateBps)(inputs.bps, loan.totalLoan);
        const stateRules = buildStateRules(inputs);
        const warnings = [
            ...(0, validate_1.validationWarnings)(rawInputs),
            ...(0, warnings_1.buildWarnings)({
                inputs,
                program,
                purchase,
                renovationOut,
                loan,
                payment,
                value,
                closing,
                escrow: escrowOut,
                aus,
                mmw,
            }),
        ];
        return {
            programCode: program.code,
            programLabel: program.label,
            isFha: program.isFha,
            renovationActive: program.renovationActive,
            purchase,
            renovationOut,
            loan,
            payment,
            value,
            closing,
            escrowOut,
            cash,
            bpsOut,
            stateRules,
            mmw,
            aus,
            warnings,
            traces: trace.get(),
            preliminary: {
                renovationWithoutReserve: prelimReno.finalRenovationAmount,
                baseLoan: prelimLoan.maximumBaseLoan,
                totalLoan: prelimLoan.totalLoan,
                monthlyPayment: prelimPayment.totalMonthlyPayment,
            },
        };
    }
    function buildStateRules(inputs) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const closingRule = (0, stateClosingRules_1.lookupClosingRule)(inputs.state);
        const transfer = (0, transferTaxes_3.lookupTransferTax)(inputs.state);
        const jurisdiction = inputs.state === 'New York' ? (inputs.isNYC ? 'New York City' : inputs.nyCounty) : inputs.state;
        const escrowRule = (0, escrowRules_2.lookupEscrowRule)(inputs.state, jurisdiction, inputs.state === 'New York' && inputs.isNYC);
        const market = (0, marketData_2.lookupMarket)(inputs.state);
        return {
            state: inputs.state,
            closingMethod: (_a = closingRule === null || closingRule === void 0 ? void 0 : closingRule.closingMethod) !== null && _a !== void 0 ? _a : 'Not stored',
            earnestHolder: (_b = closingRule === null || closingRule === void 0 ? void 0 : closingRule.earnestHolder) !== null && _b !== void 0 ? _b : 'Not stored',
            closingNote: (_c = closingRule === null || closingRule === void 0 ? void 0 : closingRule.note) !== null && _c !== void 0 ? _c : '',
            maritalClassification: (_d = closingRule === null || closingRule === void 0 ? void 0 : closingRule.marital) !== null && _d !== void 0 ? _d : '',
            transferTaxRate: (_e = transfer === null || transfer === void 0 ? void 0 : transfer.rate) !== null && _e !== void 0 ? _e : null,
            transferTaxPayer: (_f = transfer === null || transfer === void 0 ? void 0 : transfer.payer) !== null && _f !== void 0 ? _f : 'None',
            escrowCushionMonths: escrowRule.cushionMonths,
            taxSetupNote: (_h = (_g = escrowRule.row) === null || _g === void 0 ? void 0 : _g.taxStructure) !== null && _h !== void 0 ? _h : 'Single annual tax line (default)',
            nyFieldsActive: inputs.state === 'New York',
            appreciationRate: market.appreciation,
        };
    }
});
/**
 * Import from the Mortgage Income Calculator.
 *
 * The calculator can hand over its work in several shapes, and this module
 * reads all of them. Nothing here touches the DOM or the store: it takes text
 * in and returns a plain description of what was found, so it can be unit
 * tested and so the caller decides what to apply.
 *
 *   RenovationSuite_Income_*.json  the purpose-built handoff - per-borrower
 *                                  qualifying income and monthly debts. Best
 *                                  fidelity, because the calculator has already
 *                                  run its own averaging and method selection.
 *   IncomeFile_*.json              a full save of the calculator. Raw entries
 *                                  only: names, liabilities, the subject PITIA
 *                                  and the loan setup. Qualifying income is a
 *                                  derived figure that lives in the
 *                                  calculator's own engine, so it is only read
 *                                  when the file carries a totals block.
 *   IncomeWorksheet_*.csv          the exported worksheet. Its Income Summary
 *                                  block carries the computed totals.
 *   IncomeSummary_*.html           the standalone summary page, same figures.
 *
 * A borrower-attributed figure is preferred everywhere; when only a household
 * total is available it is placed on borrower 1 and flagged in the notes.
 */
define("src/core/importers/incomeCalculator", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.splitCsvLine = splitCsvLine;
    exports.parseIncomeCalculatorFile = parseIncomeCalculatorFile;
    exports.describeImport = describeImport;
    const EMPTY = (source) => ({
        source,
        borrowerName: '',
        borrowers: [],
        totalQualifyingIncome: null,
        totalMonthlyDebts: null,
        housing: {
            propertyTaxMonthly: null,
            insuranceMonthly: null,
            hoaMonthly: null,
            mortgageInsuranceMonthly: null,
        },
        loan: {
            propertyAddress: null,
            purchasePrice: null,
            interestRate: null,
            termYears: null,
            loanProgram: null,
        },
        notes: [],
        warnings: [],
    });
    /** Reads a number out of anything the calculator might have written. */
    function num(v) {
        if (typeof v === 'number')
            return Number.isFinite(v) ? v : 0;
        if (typeof v !== 'string')
            return 0;
        const cleaned = v.replace(/[$,\s]/g, '').replace(/[()]/g, (m) => (m === '(' ? '-' : ''));
        const n = Number(cleaned);
        return Number.isFinite(n) ? n : 0;
    }
    function money(v) {
        return Math.round(num(v) * 100) / 100;
    }
    /** A rate may arrive as 6.875 or as 0.06875. */
    function rate(v) {
        const n = num(v);
        if (n <= 0)
            return null;
        return n > 1 ? n / 100 : n;
    }
    // ---------------------------------------------------------------------------
    // 1. the purpose-built handoff patch
    // ---------------------------------------------------------------------------
    function fromSuitePatch(j) {
        var _a;
        const out = EMPTY('suite-patch');
        out.borrowerName = typeof j.borrowerName === 'string' ? j.borrowerName : '';
        const rows = Array.isArray(j.borrowers) ? j.borrowers : [];
        out.borrowers = rows.map((b, idx) => ({
            name: typeof b.name === 'string' && b.name.trim() ? b.name : `Borrower ${idx + 1}`,
            grossMonthlyIncome: money(b.grossMonthlyIncome),
            otherMonthlyIncome: money(b.otherMonthlyIncome),
            monthlyDebts: money(b.monthlyDebts),
        }));
        out.totalQualifyingIncome = money(out.borrowers.reduce((n, b) => n + b.grossMonthlyIncome + b.otherMonthlyIncome, 0));
        out.totalMonthlyDebts = money(out.borrowers.reduce((n, b) => n + b.monthlyDebts, 0));
        const named = out.borrowers.filter((b) => b.grossMonthlyIncome > 0 || b.otherMonthlyIncome > 0);
        out.notes.push(named.length
            ? `Qualifying income for ${named.length} borrower(s), already averaged by the calculator.`
            : 'No qualifying income in this file - check that an income source is switched on in the calculator.');
        if (((_a = out.totalMonthlyDebts) !== null && _a !== void 0 ? _a : 0) > 0)
            out.notes.push('Monthly liabilities.');
        return out;
    }
    // ---------------------------------------------------------------------------
    // 2. a full save of the calculator
    // ---------------------------------------------------------------------------
    function fromIncomeFile(j) {
        var _a, _b, _c, _d;
        const out = EMPTY('income-file');
        const b1 = typeof j.b1 === 'string' ? j.b1 : '';
        const b2 = typeof j.b2 === 'string' ? j.b2 : '';
        out.borrowerName = [b1, b2].filter(Boolean).join(' & ') || (typeof j.borrower === 'string' ? j.borrower : '');
        const dti = ((_a = j.dti) !== null && _a !== void 0 ? _a : {});
        const debtRows = Array.isArray(dti.debts) ? dti.debts : [];
        const debts = money(debtRows.reduce((n, d) => n + num(d.amt), 0));
        out.totalMonthlyDebts = debts;
        out.housing = {
            propertyTaxMonthly: num(dti.taxes) > 0 ? money(dti.taxes) : null,
            insuranceMonthly: num(dti.ins) > 0 ? money(dti.ins) : null,
            hoaMonthly: num(dti.hoa) > 0 ? money(dti.hoa) : null,
            mortgageInsuranceMonthly: num(dti.mi) > 0 ? money(dti.mi) : null,
        };
        const loan = ((_b = j.loan) !== null && _b !== void 0 ? _b : {});
        out.loan = {
            propertyAddress: typeof loan.address === 'string' && loan.address.trim() ? loan.address : null,
            purchasePrice: num(loan.price) > 0 ? money(loan.price) : null,
            interestRate: rate(loan.rate),
            termYears: num(loan.term) > 0 ? Math.round(num(loan.term)) : null,
            loanProgram: loan.program === 'FHA' ? 'FHA' : loan.program === 'Conventional' ? 'Conventional' : null,
        };
        // A full save carries raw worksheet entries, not the averaged result - the
        // calculator computes that when it renders. Read a totals block if one was
        // written; otherwise say plainly that the income has to come across through
        // the calculator's own "Send to the Renovation Suite" export.
        const totals = ((_d = (_c = j.totals) !== null && _c !== void 0 ? _c : j.summary) !== null && _d !== void 0 ? _d : null);
        if (totals && num(totals.income) > 0) {
            out.totalQualifyingIncome = money(totals.income);
            out.borrowers = [
                {
                    name: b1 || 'Borrower 1',
                    grossMonthlyIncome: money(num(totals.b1) || num(totals.income)),
                    otherMonthlyIncome: 0,
                    monthlyDebts: debts,
                },
                ...(num(totals.b2) > 0
                    ? [{ name: b2 || 'Borrower 2', grossMonthlyIncome: money(totals.b2), otherMonthlyIncome: 0, monthlyDebts: 0 }]
                    : []),
            ];
            out.notes.push('Qualifying income from the saved totals.');
        }
        else {
            out.warnings.push('This is a full save of the calculator, which stores the worksheet entries rather than the averaged result. Borrower names, liabilities, the subject housing figures and the loan setup have been read; for qualifying income use the calculator’s "Send to the Renovation Suite" export instead.');
        }
        if (out.borrowerName)
            out.notes.push(`Borrower name: ${out.borrowerName}.`);
        if (debts > 0)
            out.notes.push(`Monthly liabilities: ${debtRows.length} entr${debtRows.length === 1 ? 'y' : 'ies'}.`);
        if (out.loan.purchasePrice)
            out.notes.push('Loan setup (price, rate, term).');
        return out;
    }
    // ---------------------------------------------------------------------------
    // 3. the exported worksheet CSV and 4. the summary page
    // ---------------------------------------------------------------------------
    /** Splits a CSV line, honouring the calculator's doubled-quote escaping. */
    function splitCsvLine(line) {
        const cells = [];
        let cur = '';
        let quoted = false;
        for (let i = 0; i < line.length; i += 1) {
            const ch = line[i];
            if (quoted) {
                if (ch === '"' && line[i + 1] === '"') {
                    cur += '"';
                    i += 1;
                }
                else if (ch === '"')
                    quoted = false;
                else
                    cur += ch;
            }
            else if (ch === '"')
                quoted = true;
            else if (ch === ',') {
                cells.push(cur);
                cur = '';
            }
            else
                cur += ch;
        }
        cells.push(cur);
        return cells;
    }
    /** Pulls "label ... amount" pairs out of the flat text of a CSV or HTML export. */
    function readLabelledTotals(rows) {
        var _a, _b, _c, _d;
        let income = null;
        let pitia = null;
        let debts = null;
        let borrower = '';
        const perBorrower = new Map();
        for (const cells of rows) {
            const label = ((_a = cells[0]) !== null && _a !== void 0 ? _a : '').trim().toLowerCase();
            const last = (_b = cells.filter((c) => c.trim() !== '').pop()) !== null && _b !== void 0 ? _b : '';
            if (label === 'borrower' && cells[1])
                borrower = cells[1].trim();
            if (label.startsWith('total qualifying monthly income'))
                income = money(last);
            else if (label.startsWith('total subject pitia'))
                pitia = money(last);
            else if (label.startsWith('total monthly liabilities'))
                debts = money(last);
            // Detail rows look like: Category | "Employer (Borrower Name)" | Method | Amount
            const entity = ((_c = cells[1]) !== null && _c !== void 0 ? _c : '').trim();
            const m = entity.match(/\(([^)]+)\)\s*$/);
            if (m && cells.length >= 4) {
                const who = m[1].trim();
                const amount = money(cells[cells.length - 1]);
                if (who && amount > 0 && !/^borrower\s*\d$/i.test(who)) {
                    perBorrower.set(who, money(((_d = perBorrower.get(who)) !== null && _d !== void 0 ? _d : 0) + amount));
                }
            }
        }
        return { income, pitia, debts, borrower, perBorrower };
    }
    function fromRows(rows, source) {
        var _a;
        const out = EMPTY(source);
        const t = readLabelledTotals(rows);
        out.borrowerName = t.borrower;
        out.totalQualifyingIncome = t.income;
        out.totalMonthlyDebts = t.debts;
        if (t.perBorrower.size > 0) {
            out.borrowers = [...t.perBorrower.entries()].map(([name, amount], idx) => {
                var _a;
                return ({
                    name,
                    grossMonthlyIncome: amount,
                    otherMonthlyIncome: 0,
                    monthlyDebts: idx === 0 ? ((_a = t.debts) !== null && _a !== void 0 ? _a : 0) : 0,
                });
            });
            out.notes.push(`Qualifying income split across ${out.borrowers.length} borrower(s).`);
        }
        else if (t.income !== null && t.income > 0) {
            out.borrowers = [
                {
                    name: t.borrower || 'Borrower 1',
                    grossMonthlyIncome: t.income,
                    otherMonthlyIncome: 0,
                    monthlyDebts: (_a = t.debts) !== null && _a !== void 0 ? _a : 0,
                },
            ];
            out.notes.push('The export gives one household total, so it has been placed on borrower 1.');
        }
        else {
            out.warnings.push('No qualifying income total was found in this export.');
        }
        if (t.pitia !== null && t.pitia > 0) {
            out.notes.push(`The calculator was testing a subject payment of ${t.pitia.toFixed(2)} - the Suite calculates its own, so this is shown for comparison only.`);
        }
        if (t.debts !== null && t.debts > 0)
            out.notes.push('Monthly liabilities.');
        return out;
    }
    function fromCsv(text) {
        const rows = text
            .split(/\r?\n/)
            .filter((l) => l.trim() !== '')
            .map(splitCsvLine);
        return fromRows(rows, 'csv-worksheet');
    }
    function fromSummaryHtml(html) {
        const CELL = '\u0001';
        const ROW = '\u0002';
        // Turn the page into label/value rows without needing a DOM: a cell boundary
        // becomes a column break and a block boundary becomes a row break.
        const flat = html
            .replace(/<\s*(script|style)[\s\S]*?<\/\s*\1\s*>/gi, ' ')
            .replace(/<\/\s*(td|th)\s*>/gi, CELL)
            .replace(/<\/\s*(tr|div|p|li|h\d|section)\s*>/gi, ROW)
            .replace(/<\s*br\s*\/?>/gi, ROW)
            .replace(/<[^>]+>/g, ' ')
            .replace(/&nbsp;/g, ' ')
            .replace(/&amp;/g, '&');
        const rows = flat
            .split(ROW)
            .map((line) => line
            .split(CELL)
            .map((c) => c.replace(/\s+/g, ' ').trim())
            .filter((c) => c !== ''))
            .filter((cells) => cells.length > 0);
        return fromRows(rows, 'summary-html');
    }
    // ---------------------------------------------------------------------------
    // entry point
    // ---------------------------------------------------------------------------
    /**
     * Reads any of the calculator's exports. Throws only when the text is not one
     * of them at all - a file that is recognised but thin comes back with
     * warnings rather than an exception.
     */
    function parseIncomeCalculatorFile(text, fileName = '') {
        var _a, _b;
        const trimmed = text.trim();
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
            let parsed;
            try {
                parsed = JSON.parse(trimmed);
            }
            catch {
                throw new Error('That file looks like JSON but could not be parsed.');
            }
            const j = (_a = (Array.isArray(parsed) ? {} : parsed)) !== null && _a !== void 0 ? _a : {};
            // An autosave wraps the state as { at, data }.
            const body = (_b = (j.data && typeof j.data === 'object' ? j.data : j)) !== null && _b !== void 0 ? _b : {};
            if (Array.isArray(body.borrowers) && !('w2' in body) && !('schc' in body))
                return fromSuitePatch(body);
            if ('w2' in body || 'schc' in body || 'sche' in body || 'dti' in body)
                return fromIncomeFile(body);
            if (Array.isArray(body.borrowers))
                return fromSuitePatch(body);
            throw new Error('That JSON is not a Mortgage Income Calculator file.');
        }
        if (/^\s*</.test(trimmed) || /\.html?$/i.test(fileName)) {
            const out = fromSummaryHtml(trimmed);
            if (out.totalQualifyingIncome === null && out.borrowers.length === 0) {
                throw new Error('No income summary was found in that page. Export the summary from the calculator, or use its JSON handoff.');
            }
            return out;
        }
        if (trimmed.includes(',')) {
            const out = fromCsv(trimmed);
            if (out.totalQualifyingIncome === null && out.borrowers.length === 0) {
                throw new Error('No "Total Qualifying Monthly Income" row was found in that CSV.');
            }
            return out;
        }
        throw new Error('Unrecognised file. Use the calculator’s JSON, CSV or summary export.');
    }
    /** A one-line description for the audit trail and the toast. */
    function describeImport(result) {
        var _a;
        const names = {
            'suite-patch': 'income handoff',
            'income-file': 'full calculator save',
            'csv-worksheet': 'worksheet CSV',
            'summary-html': 'summary page',
        };
        const income = (_a = result.totalQualifyingIncome) !== null && _a !== void 0 ? _a : 0;
        return income > 0
            ? `${names[result.source]} - ${income.toLocaleString(undefined, { style: 'currency', currency: 'USD' })}/mo qualifying income`
            : `${names[result.source]} - no qualifying income found`;
    }
});
define("src/state/store", ["require", "exports", "src/core/defaults", "src/core/calc/engine", "src/core/utils/dates", "src/core/data/marketData", "src/core/utils/num", "src/core/importers/incomeCalculator"], function (require, exports, defaults_1, engine_1, dates_5, marketData_3, num_15, incomeCalculator_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ScenarioStore = void 0;
    exports.newSavedScenario = newSavedScenario;
    const STORAGE_KEY = 'mortgage-suite-state-v2';
    function nowISO() {
        return new Date().toISOString();
    }
    function newSavedScenario(inputs) {
        return {
            inputs,
            borrowerId: null,
            propertyId: null,
            createdAt: nowISO(),
            updatedAt: nowISO(),
            audit: [{ id: `a-${Date.now()}`, timestamp: nowISO(), user: 'local', action: 'Scenario created' }],
            versions: [],
        };
    }
    function initialState() {
        const first = (0, defaults_1.defaultScenario)((0, dates_5.today)(), 'scenario-1');
        return {
            activeScenarioId: first.id,
            scenarios: { [first.id]: newSavedScenario(first) },
            borrowers: [],
            properties: [],
            compareIds: [],
            mode: 'quote',
            theme: 'light',
            user: 'local',
            lookupMessage: '',
            sections: { collapsed: {}, pinned: {} },
        };
    }
    function loadState() {
        var _a, _b, _c, _d;
        try {
            const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
            if (!raw)
                return initialState();
            const parsed = JSON.parse(raw);
            if (!parsed || !parsed.scenarios || !parsed.scenarios[parsed.activeScenarioId])
                return initialState();
            // Merge forward: a stored scenario from an older build gets the new fields.
            const base = (0, defaults_1.defaultScenario)((0, dates_5.today)(), parsed.activeScenarioId);
            Object.values(parsed.scenarios).forEach((s) => {
                var _a;
                s.inputs = { ...base, ...s.inputs, id: s.inputs.id };
                s.inputs.reno = { ...base.reno, ...s.inputs.reno };
                s.inputs.draws = { ...base.draws, ...s.inputs.draws };
                s.inputs.closing = { ...base.closing, ...s.inputs.closing };
                s.inputs.closing.overrides = { ...base.closing.overrides, ...s.inputs.closing.overrides };
                s.inputs.escrow = { ...base.escrow, ...s.inputs.escrow };
                s.inputs.bps = { ...base.bps, ...s.inputs.bps };
                s.inputs.assets = { ...base.assets, ...s.inputs.assets };
                s.inputs.rental = { ...base.rental, ...s.inputs.rental };
                s.inputs.projection = { ...base.projection, ...s.inputs.projection };
                s.inputs.borrowers = ((_a = s.inputs.borrowers) === null || _a === void 0 ? void 0 : _a.length) ? s.inputs.borrowers : base.borrowers;
            });
            const merged = { ...initialState(), ...parsed };
            if (!/^(quote|setup|renovation|maxmortgage|closing|escrow|qualify|rental|advanced|scenarios|summary)$/.test(String(merged.mode)))
                merged.mode = 'quote';
            merged.sections = {
                collapsed: { ...((_b = (_a = parsed.sections) === null || _a === void 0 ? void 0 : _a.collapsed) !== null && _b !== void 0 ? _b : {}) },
                pinned: { ...((_d = (_c = parsed.sections) === null || _c === void 0 ? void 0 : _c.pinned) !== null && _d !== void 0 ? _d : {}) },
            };
            return merged;
        }
        catch {
            return initialState();
        }
    }
    function persist(state) {
        try {
            if (typeof localStorage === 'undefined')
                return;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        }
        catch {
            /* private browsing / blocked storage - the app still works in memory */
        }
    }
    class ScenarioStore {
        constructor(state = loadState()) {
            this.listeners = new Set();
            this.cacheKey = '';
            /**
             * Jump to the place a number is produced: switch tab, open the section that
             * holds it, and leave a focus request for the renderer to scroll to and
             * highlight. The renderer clears it once it has been honoured.
             */
            this.focusRequest = null;
            this.state = state;
            this.cachedOutputs = (0, engine_1.runScenario)(this.activeInputs);
            this.cacheKey = JSON.stringify(this.activeInputs);
        }
        // ---- reads -------------------------------------------------------------
        get snapshot() {
            return this.state;
        }
        get active() {
            return this.state.scenarios[this.state.activeScenarioId];
        }
        get activeInputs() {
            return this.active.inputs;
        }
        get outputs() {
            const key = JSON.stringify(this.activeInputs);
            if (key !== this.cacheKey) {
                this.cachedOutputs = (0, engine_1.runScenario)(this.activeInputs);
                this.cacheKey = key;
            }
            return this.cachedOutputs;
        }
        outputsFor(scenarioId) {
            const s = this.state.scenarios[scenarioId];
            return s ? (0, engine_1.runScenario)(s.inputs) : null;
        }
        get scenarioList() {
            return Object.values(this.state.scenarios).map((s) => ({
                id: s.inputs.id,
                name: s.inputs.name,
                updatedAt: s.updatedAt,
            }));
        }
        // ---- subscription ------------------------------------------------------
        subscribe(fn) {
            this.listeners.add(fn);
            return () => this.listeners.delete(fn);
        }
        emit() {
            persist(this.state);
            this.listeners.forEach((fn) => fn());
        }
        audit(action, field, from, to) {
            const entry = {
                id: `a-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
                timestamp: nowISO(),
                user: this.state.user,
                action,
                field,
                from,
                to,
            };
            this.active.audit.unshift(entry);
            this.active.audit = this.active.audit.slice(0, 200);
        }
        // ---- shell -------------------------------------------------------------
        setMode(mode) {
            this.state.mode = mode;
            this.emit();
        }
        navigate(target) {
            this.state.mode = target.tab;
            if (target.section) {
                this.state.sections.collapsed[target.section] = false;
                this.state.sections.pinned[target.section] = true;
            }
            this.focusRequest = target;
            this.emit();
        }
        /** Reads and clears the pending focus request. */
        takeFocus() {
            const f = this.focusRequest;
            this.focusRequest = null;
            return f;
        }
        get pendingFocus() {
            return this.focusRequest;
        }
        /**
         * Section expansion. `defaultCollapsed` is the descriptor's own preference and
         * `autoExpand` is the "this is now relevant" rule; a section the user has
         * touched keeps whatever they chose, so automatic expansion can never fight
         * a deliberate collapse.
         */
        isCollapsed(id, defaultCollapsed, autoExpand, force = false) {
            // A blocking problem outranks everything: the section opens even if the
            // user closed it, because the figure they are reading is wrong.
            if (force)
                return false;
            const { collapsed, pinned } = this.state.sections;
            if (pinned[id])
                return Boolean(collapsed[id]);
            if (autoExpand)
                return false;
            return id in collapsed ? Boolean(collapsed[id]) : defaultCollapsed;
        }
        toggleSection(id, currentlyCollapsed) {
            this.state.sections.collapsed[id] = !currentlyCollapsed;
            this.state.sections.pinned[id] = true;
            this.emit();
        }
        setSectionsCollapsed(ids, collapsed) {
            ids.forEach((id) => {
                this.state.sections.collapsed[id] = collapsed;
                this.state.sections.pinned[id] = true;
            });
            this.emit();
        }
        toggleTheme() {
            this.state.theme = this.state.theme === 'dark' ? 'light' : 'dark';
            this.emit();
        }
        setLookupMessage(msg) {
            this.state.lookupMessage = msg;
            this.emit();
        }
        // ---- scenario inputs ---------------------------------------------------
        setField(path, value, label) {
            const parts = path.split('.');
            let target = this.activeInputs;
            for (let i = 0; i < parts.length - 1; i += 1) {
                const key = parts[i];
                const idx = Number(key);
                target = (Number.isInteger(idx) && Array.isArray(target)
                    ? target[idx]
                    : target[key]);
                if (!target)
                    return;
            }
            const key = parts[parts.length - 1];
            const from = target[key];
            if (from === value)
                return;
            target[key] = value;
            this.active.updatedAt = nowISO();
            this.audit('Field changed', label !== null && label !== void 0 ? label : path, String(from), String(value));
            this.emit();
        }
        replaceInputs(inputs, action) {
            this.state.scenarios[this.state.activeScenarioId].inputs = inputs;
            this.active.updatedAt = nowISO();
            this.audit(action);
            this.emit();
        }
        resetDefaults() {
            const id = this.state.activeScenarioId;
            const next = (0, defaults_1.defaultScenario)((0, dates_5.today)(), id);
            next.name = this.activeInputs.name;
            this.replaceInputs(next, 'Reset to defaults');
        }
        clearAll() {
            const id = this.state.activeScenarioId;
            const next = (0, defaults_1.blankScenario)((0, dates_5.today)(), id);
            next.name = this.activeInputs.name;
            this.replaceInputs(next, 'Cleared all values');
        }
        /**
         * switchProgram() - one-click FHA <-> Conventional.
         * Moving to Conventional adds the +0.375% rate premium by default; moving
         * back removes exactly what was added. The rate stays editable afterwards.
         */
        switchProgram(to) {
            const i = this.activeInputs;
            if (i.loanProgram === to)
                return;
            const from = i.loanProgram;
            if (to === 'Conventional') {
                const premium = defaults_1.CONVENTIONAL_RATE_PREMIUM;
                i.interestRate = (0, num_15.round)(i.interestRate + premium, 6);
                i.conventionalRatePremiumApplied = premium;
                if (i.finalDownPaymentPct < 0.05) {
                    i.finalDownPaymentPct = 0.05;
                    i.baseDownPaymentPct = 0.05;
                }
            }
            else {
                i.interestRate = Math.max(0, (0, num_15.round)(i.interestRate - i.conventionalRatePremiumApplied, 6));
                i.conventionalRatePremiumApplied = 0;
                if (i.finalDownPaymentPct > 0.035 && i.finalDownPaymentPct <= 0.05) {
                    i.finalDownPaymentPct = 0.035;
                    i.baseDownPaymentPct = 0.035;
                }
            }
            i.loanProgram = to;
            this.active.updatedAt = nowISO();
            this.audit('Program switched', 'Loan program', from, to);
            this.emit();
        }
        /** TEST FEATURE: apply the offline ZIP lookup to the scenario. */
        applyZipLookup() {
            const i = this.activeInputs;
            const r = (0, marketData_3.lookupZip)(i.zipCode);
            if (!r.valid) {
                this.setLookupMessage(`ZIP ${i.zipCode || '(empty)'} not recognised.`);
                return;
            }
            i.state = r.state;
            if (r.state === 'New York') {
                i.isNYC = r.isNYC;
                if (r.county && !r.isNYC)
                    i.nyCounty = r.county;
            }
            else {
                i.isNYC = false;
            }
            if (r.estimatedAnnualTaxes > 0) {
                i.propertyTaxAmount = r.estimatedAnnualTaxes;
                i.propertyTaxBasis = 'Annual';
                i.taxSourceType = 'MLS / Zillow / Redfin Estimate';
            }
            if (r.estimatedAnnualInsurance > 0) {
                i.insuranceAmount = r.estimatedAnnualInsurance;
                i.insuranceBasis = 'Annual';
            }
            this.active.updatedAt = nowISO();
            this.audit('ZIP lookup applied', 'ZIP', '', `${r.zip} - ${r.areaLabel}`);
            this.setLookupMessage(`Applied ${r.areaLabel}: taxes and insurance are AREA ESTIMATES - replace them with a tax certificate and an insurance binder before disclosing.`);
        }
        /**
         * TEST FEATURE: seed the as-is value and ARV from the area estimate.
         * Planning heuristic: roughly 70 cents of value per renovation dollar.
         */
        applyAreaValues() {
            const i = this.activeInputs;
            const r = (0, marketData_3.lookupZip)(i.zipCode);
            const typical = r.valid ? r.typicalValue : (0, marketData_3.lookupMarket)(i.state).medianValue;
            const reno = this.outputs.renovationOut.finalRenovationAmount;
            const asIs = i.basePurchasePrice > 0 ? i.basePurchasePrice : typical;
            i.asIsValue = (0, num_15.round)(asIs, 0);
            i.afterRepairValue = (0, num_15.round)(asIs + reno * 0.7, 0);
            this.active.updatedAt = nowISO();
            this.audit('Area value estimate applied', 'ARV', '', String(i.afterRepairValue));
            this.setLookupMessage(`Seeded as-is ${i.asIsValue.toLocaleString()} and ARV ${i.afterRepairValue.toLocaleString()} from area data (planning estimate at ~70% value recapture). Replace with the appraisal.`);
        }
        /** Optional online refinement of the ZIP lookup. Fails safe when offline. */
        async lookupZipOnline() {
            var _a;
            const zip = this.activeInputs.zipCode;
            if (!/^\d{5}$/.test(zip)) {
                this.setLookupMessage('Enter a 5-digit ZIP code first.');
                return;
            }
            this.setLookupMessage('Searching online...');
            try {
                const res = await fetch(`https://api.zippopotam.us/us/${zip}`);
                if (!res.ok)
                    throw new Error(String(res.status));
                const data = (await res.json());
                const place = (_a = data.places) === null || _a === void 0 ? void 0 : _a[0];
                if (!place)
                    throw new Error('no place');
                const i = this.activeInputs;
                i.state = place.state;
                if (!i.propertyAddress)
                    i.propertyAddress = `${place['place name']}, ${place.state} ${zip}`;
                this.active.updatedAt = nowISO();
                this.audit('Online ZIP lookup', 'ZIP', '', `${place['place name']}, ${place.state}`);
                this.setLookupMessage(`Online: ${place['place name']}, ${place.state}. Cost and value figures still come from the offline planning tables.`);
            }
            catch {
                this.applyZipLookup();
                this.setLookupMessage(`Online lookup unavailable (offline or blocked). Applied the built-in ZIP planning data instead.`);
            }
        }
        // ---- scenario management ----------------------------------------------
        saveVersion(label) {
            const version = {
                version: this.active.versions.length + 1,
                timestamp: nowISO(),
                user: this.state.user,
                label: label || `Version ${this.active.versions.length + 1}`,
                inputs: JSON.parse(JSON.stringify(this.activeInputs)),
            };
            this.active.versions.unshift(version);
            this.audit(`Version ${version.version} saved`, undefined, undefined, version.label);
            this.emit();
        }
        restoreVersion(versionNumber) {
            const v = this.active.versions.find((x) => x.version === versionNumber);
            if (!v)
                return;
            const inputs = JSON.parse(JSON.stringify(v.inputs));
            inputs.id = this.state.activeScenarioId;
            this.replaceInputs(inputs, `Restored version ${versionNumber}`);
        }
        duplicateScenario() {
            const id = `scenario-${Date.now()}`;
            const copy = JSON.parse(JSON.stringify(this.active));
            copy.inputs = { ...copy.inputs, id, name: `${this.activeInputs.name} (copy)` };
            copy.createdAt = nowISO();
            copy.updatedAt = nowISO();
            copy.versions = [];
            copy.audit = [{ id: `a-${Date.now()}`, timestamp: nowISO(), user: this.state.user, action: `Duplicated from ${this.activeInputs.name}` }];
            this.state.scenarios[id] = copy;
            this.state.activeScenarioId = id;
            this.emit();
            return id;
        }
        newScenario() {
            const id = `scenario-${Date.now()}`;
            const inputs = (0, defaults_1.defaultScenario)((0, dates_5.today)(), id);
            inputs.name = `Scenario ${Object.keys(this.state.scenarios).length + 1}`;
            this.state.scenarios[id] = newSavedScenario(inputs);
            this.state.activeScenarioId = id;
            this.emit();
            return id;
        }
        /** Duplicate the active scenario and flip it to the other program. */
        compareProgramScenario() {
            const other = this.activeInputs.loanProgram === 'FHA' ? 'Conventional' : 'FHA';
            const sourceId = this.state.activeScenarioId;
            const id = this.duplicateScenario();
            this.activeInputs.name = `${this.state.scenarios[sourceId].inputs.name} - ${other}`;
            this.switchProgram(other);
            this.state.compareIds = [sourceId, id];
            this.emit();
            return id;
        }
        renameScenario(name) {
            this.setField('name', name, 'Scenario name');
        }
        deleteScenario(id) {
            if (Object.keys(this.state.scenarios).length <= 1)
                return;
            delete this.state.scenarios[id];
            this.state.compareIds = this.state.compareIds.filter((x) => x !== id);
            if (this.state.activeScenarioId === id) {
                this.state.activeScenarioId = Object.keys(this.state.scenarios)[0];
            }
            this.emit();
        }
        selectScenario(id) {
            if (!this.state.scenarios[id])
                return;
            this.state.activeScenarioId = id;
            this.emit();
        }
        toggleCompare(id) {
            const i = this.state.compareIds.indexOf(id);
            if (i >= 0)
                this.state.compareIds.splice(i, 1);
            else
                this.state.compareIds.push(id);
            this.emit();
        }
        // ---- borrowers / properties -------------------------------------------
        saveBorrower(b) {
            var _a;
            const id = (_a = b.id) !== null && _a !== void 0 ? _a : `borrower-${Date.now()}`;
            const record = { ...b, id };
            const existing = this.state.borrowers.findIndex((x) => x.id === id);
            if (existing >= 0)
                this.state.borrowers[existing] = record;
            else
                this.state.borrowers.push(record);
            this.active.borrowerId = id;
            this.audit('Borrower saved', 'borrower', '', record.name);
            this.emit();
        }
        deleteBorrower(id) {
            this.state.borrowers = this.state.borrowers.filter((b) => b.id !== id);
            Object.values(this.state.scenarios).forEach((s) => {
                if (s.borrowerId === id)
                    s.borrowerId = null;
            });
            this.emit();
        }
        saveProperty(p) {
            var _a;
            const id = (_a = p.id) !== null && _a !== void 0 ? _a : `property-${Date.now()}`;
            const record = { ...p, id };
            const existing = this.state.properties.findIndex((x) => x.id === id);
            if (existing >= 0)
                this.state.properties[existing] = record;
            else
                this.state.properties.push(record);
            this.active.propertyId = id;
            this.audit('Property saved', 'property', '', record.address);
            this.emit();
        }
        deleteProperty(id) {
            this.state.properties = this.state.properties.filter((p) => p.id !== id);
            Object.values(this.state.scenarios).forEach((s) => {
                if (s.propertyId === id)
                    s.propertyId = null;
            });
            this.emit();
        }
        applyProperty(id) {
            const p = this.state.properties.find((x) => x.id === id);
            if (!p)
                return;
            const i = this.activeInputs;
            i.propertyAddress = p.address;
            i.zipCode = p.zipCode || i.zipCode;
            i.state = p.state;
            if (p.state === 'New York' && p.county)
                i.nyCounty = p.county;
            i.units = p.units;
            if (p.annualTaxes > 0) {
                i.propertyTaxAmount = p.annualTaxes;
                i.propertyTaxBasis = 'Annual';
            }
            if (p.annualInsurance > 0) {
                i.insuranceAmount = p.annualInsurance;
                i.insuranceBasis = 'Annual';
            }
            this.active.propertyId = id;
            this.audit('Property applied to scenario', 'property', '', p.address);
            this.emit();
        }
        applyBorrower(id) {
            const b = this.state.borrowers.find((x) => x.id === id);
            if (!b)
                return;
            this.activeInputs.borrowerName = b.name;
            if (b.creditScore > 0)
                this.activeInputs.creditScore = b.creditScore;
            this.active.borrowerId = id;
            this.audit('Borrower applied to scenario', 'borrower', '', b.name);
            this.emit();
        }
        /** Save the current borrower/property details straight from the scenario. */
        /**
         * Apply a parsed Mortgage Income Calculator export to the active scenario.
         *
         * Income and liabilities always come across; the housing figures and the loan
         * setup only fill fields the user has left empty, so an import can never
         * quietly overwrite a quote that is already built. Returns the lines to show.
         */
        importIncome(result, options = {}) {
            const applied = [];
            const i = this.activeInputs;
            if (result.borrowerName && !i.borrowerName) {
                i.borrowerName = result.borrowerName;
                applied.push(`Borrower name: ${result.borrowerName}`);
            }
            if (result.borrowers.length) {
                const rows = i.borrowers.map((row, idx) => {
                    const src = result.borrowers[idx];
                    if (!src)
                        return row;
                    return {
                        ...row,
                        name: src.name && !/^Borrower \d$/.test(src.name) ? src.name : row.name,
                        grossMonthlyIncome: src.grossMonthlyIncome,
                        otherMonthlyIncome: src.otherMonthlyIncome,
                        monthlyDebts: src.monthlyDebts,
                    };
                });
                i.borrowers = rows;
                const total = result.borrowers.reduce((n, b) => n + b.grossMonthlyIncome + b.otherMonthlyIncome, 0);
                const debts = result.borrowers.reduce((n, b) => n + b.monthlyDebts, 0);
                if (total > 0)
                    applied.push(`Qualifying income: ${total.toFixed(2)} / month`);
                if (debts > 0)
                    applied.push(`Monthly liabilities: ${debts.toFixed(2)}`);
            }
            else if (result.totalMonthlyDebts && result.totalMonthlyDebts > 0) {
                i.borrowers = i.borrowers.map((row, idx) => idx === 0 ? { ...row, monthlyDebts: result.totalMonthlyDebts } : row);
                applied.push(`Monthly liabilities: ${result.totalMonthlyDebts.toFixed(2)}`);
            }
            const fill = (current, incoming, apply, label, monthly = true) => {
                if (incoming === null || incoming <= 0)
                    return;
                if (current > 0 && !options.overwriteHousing)
                    return;
                apply(incoming);
                applied.push(`${label}: ${incoming.toFixed(2)}${monthly ? ' / month' : ''}`);
            };
            fill(i.propertyTaxAmount, result.housing.propertyTaxMonthly, (v) => {
                i.propertyTaxAmount = v;
                i.propertyTaxBasis = 'Monthly';
            }, 'Property taxes');
            fill(i.insuranceAmount, result.housing.insuranceMonthly, (v) => {
                i.insuranceAmount = v;
                i.insuranceBasis = 'Monthly';
            }, 'Homeowners insurance');
            fill(i.hoaMonthly, result.housing.hoaMonthly, (v) => {
                i.hoaMonthly = v;
            }, 'HOA');
            if (result.loan.propertyAddress && !i.propertyAddress) {
                i.propertyAddress = result.loan.propertyAddress;
                applied.push(`Property address: ${result.loan.propertyAddress}`);
            }
            if (result.loan.purchasePrice && i.basePurchasePrice <= 0) {
                i.basePurchasePrice = result.loan.purchasePrice;
                applied.push(`Purchase price: ${result.loan.purchasePrice.toFixed(2)}`);
            }
            if (result.loan.interestRate && i.interestRate <= 0) {
                i.interestRate = result.loan.interestRate;
                applied.push(`Interest rate: ${(result.loan.interestRate * 100).toFixed(3)}%`);
            }
            if (result.loan.termYears && result.loan.termYears !== i.termYears && i.termYears <= 0) {
                i.termYears = result.loan.termYears;
                applied.push(`Term: ${result.loan.termYears} years`);
            }
            this.audit(`Imported ${(0, incomeCalculator_1.describeImport)(result)}`, 'income calculator', '', applied.join('; '));
            this.active.updatedAt = nowISO();
            this.emit();
            return applied;
        }
        /** Parse and apply in one step; throws with a readable message on a bad file. */
        importIncomeText(text, fileName = '') {
            const result = (0, incomeCalculator_1.parseIncomeCalculatorFile)(text, fileName);
            const applied = this.importIncome(result);
            return { result, applied };
        }
        /**
         * The Mortgage Income Calculator autosaves under its own key. When both files
         * are open on the same origin the handoff needs no file at all.
         */
        readIncomeCalculatorFromBrowser() {
            try {
                if (typeof localStorage === 'undefined')
                    return null;
                const raw = localStorage.getItem('uwIncomeCalcAutosave');
                if (!raw)
                    return null;
                return (0, incomeCalculator_1.parseIncomeCalculatorFile)(raw);
            }
            catch {
                return null;
            }
        }
        captureBorrowerAndProperty() {
            const i = this.activeInputs;
            if (i.borrowerName) {
                this.saveBorrower({ name: i.borrowerName, email: '', phone: '', creditScore: i.creditScore, note: '' });
            }
            if (i.propertyAddress) {
                this.saveProperty({
                    address: i.propertyAddress,
                    zipCode: i.zipCode,
                    state: i.state,
                    county: i.state === 'New York' ? i.nyCounty : '',
                    units: i.units,
                    annualTaxes: i.propertyTaxBasis === 'Annual' ? i.propertyTaxAmount : i.propertyTaxAmount * 12,
                    annualInsurance: i.insuranceBasis === 'Annual' ? i.insuranceAmount : i.insuranceAmount * 12,
                    note: '',
                });
            }
        }
    }
    exports.ScenarioStore = ScenarioStore;
});
define("src/core/summary", ["require", "exports", "src/core/utils/num"], function (require, exports, num_16) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.borrowerSummaryLines = borrowerSummaryLines;
    exports.borrowerWarnings = borrowerWarnings;
    exports.borrowerSummaryText = borrowerSummaryText;
    exports.qualificationSummaryText = qualificationSummaryText;
    exports.internalSummaryLines = internalSummaryLines;
    /**
     * Borrower-facing summary. Excludes internal compliance detail and DTI - only
     * the numbers a borrower needs plus the warnings that actually affect them.
     */
    function borrowerSummaryLines(inputs, out) {
        const lines = [
            { label: 'Program', value: out.programLabel },
            { label: 'Purchase price', value: (0, num_16.currency)(out.purchase.finalPurchasePrice) },
        ];
        if (out.purchase.sellerConcessionAmount > 0) {
            lines.push({ label: 'Seller credit', value: (0, num_16.currency)(out.purchase.sellerConcessionAmount) });
        }
        if (out.renovationActive) {
            lines.push({ label: 'Renovation budget', value: (0, num_16.currency)(out.renovationOut.finalRenovationAmount) });
        }
        if (out.value.afterRepairValue > 0) {
            lines.push({ label: 'Estimated after-repair value', value: (0, num_16.currency)(out.value.afterRepairValue) });
        }
        lines.push({ label: 'Down payment', value: `${(0, num_16.currency)(out.loan.requiredInvestment)} (${(0, num_16.percent)(inputs.finalDownPaymentPct, 2)})` }, { label: 'Base loan', value: (0, num_16.currency)(out.loan.maximumBaseLoan) }, { label: 'Total loan', value: (0, num_16.currency)(out.loan.totalLoan) }, { label: 'Interest rate', value: `${(0, num_16.percent)(inputs.interestRate, 3)} / ${inputs.termYears} years` }, {
            label: 'Estimated monthly payment',
            value: `${(0, num_16.currency)(out.payment.paymentLow)} - ${(0, num_16.currency)(out.payment.paymentHigh)}`,
            emphasis: true,
        }, {
            label: 'Estimated closing costs',
            value: `${(0, num_16.currency)(out.closing.buyerClosingCostsLow)} - ${(0, num_16.currency)(out.closing.buyerClosingCostsHigh)}`,
        }, {
            label: 'Estimated cash to close',
            value: `${(0, num_16.currency)(out.cash.cashToCloseLow)} - ${(0, num_16.currency)(out.cash.cashToCloseHigh)}`,
            emphasis: true,
        });
        if (out.cash.earnestMoneyDeposit > 0) {
            lines.push({ label: 'Earnest money already paid (credit)', value: (0, num_16.currency)(out.cash.earnestMoneyDeposit) });
        }
        if (out.value.afterRepairValue > 0) {
            lines.push({ label: 'Estimated equity after the renovation', value: `${(0, num_16.currency)(out.value.equityAfterLoan)} (${(0, num_16.percent)(out.value.equityPct, 2)})` }, { label: `Projected value in ${out.value.projectionYears} years`, value: (0, num_16.currency)(out.value.projectedValue) });
        }
        lines.push({ label: 'Minimum as-is value needed', value: (0, num_16.currency)(out.value.minimumAsIsValueNeeded) });
        if (out.renovationActive) {
            lines.push({ label: 'Minimum after-repair value needed', value: (0, num_16.currency)(out.value.minimumArvNeeded) });
        }
        if (out.aus.totalSubjectQualifyingRent > 0) {
            lines.push({ label: 'Rental income counted', value: `${(0, num_16.currency)(out.aus.rentalIncomeUsedForDti)}/mo` });
        }
        return lines;
    }
    /** Warnings a borrower should actually see. */
    function borrowerWarnings(out) {
        return out.warnings
            .filter((w) => w.severity === 'error' ||
            w.code === 'ARV_SHORTFALL' ||
            w.code === 'FHA_OVER_LIMIT')
            .filter((w) => w.code !== 'MISSING_TAX_SOURCE' && w.code !== 'MMW_SYNC')
            .map((w) => `${w.title}: ${w.detail}`);
    }
    function borrowerSummaryText(inputs, out) {
        const header = [
            inputs.borrowerName ? `Prepared for: ${inputs.borrowerName}` : null,
            inputs.propertyAddress ? `Property: ${inputs.propertyAddress}` : null,
            `As of: ${inputs.asOfDate}   |   Estimated closing: ${inputs.closingDate}`,
        ].filter(Boolean);
        const body = borrowerSummaryLines(inputs, out).map((l) => `${l.label}: ${l.value}`);
        const warn = borrowerWarnings(out);
        return [
            'ESTIMATED LOAN SUMMARY',
            ...header,
            '',
            ...body,
            ...(warn.length ? ['', 'Please note:', ...warn.map((x) => `- ${x}`)] : []),
            '',
            'This is a planning estimate, not a commitment to lend. Final figures are subject to underwriting, appraisal, title, taxes, insurance and final loan terms.',
        ].join('\n');
    }
    /**
     * Qualification summary - INTERNAL. Rental income, self-sufficiency, reserves
     * and the DTI test. Never send this to a borrower.
     */
    function qualificationSummaryText(inputs, out) {
        const a = out.aus;
        return [
            'QUALIFICATION & AUS PLANNING SUMMARY - INTERNAL USE ONLY',
            `Program: ${out.programLabel}`,
            `Property type: ${a.propertyType} (${a.propertyTypeSource.toLowerCase()})`,
            `Representative credit score: ${inputs.creditScore} - ${a.creditTier}`,
            '',
            `Total borrower income: ${(0, num_16.currency)(a.totalBorrowerIncome)}/month`,
            `Subject rental income counted: ${(0, num_16.currency)(a.totalSubjectQualifyingRent)}/month`,
            `Vacating rental adjustment: ${a.vacatingStatus}`,
            `Total qualifying income: ${(0, num_16.currency)(a.totalQualifyingIncome)}/month`,
            `Monthly liabilities: ${(0, num_16.currency)(a.totalMonthlyLiabilities)}`,
            '',
            `Housing payment: ${(0, num_16.currency)(a.housingPayment)}/month`,
            `Maximum supported housing payment: ${(0, num_16.currency)(a.maxSupportedHousingPayment)}/month`,
            `Payment cushion: ${(0, num_16.currency)(a.paymentCushion)}`,
            `Front-end DTI: ${(0, num_16.percent)(a.frontEndDti, 2)} (limit ${(0, num_16.percent)(a.frontEndLimit, 0)}) - ${a.frontEndResult}`,
            `Back-end DTI: ${(0, num_16.percent)(a.backEndDti, 2)} (limit ${(0, num_16.percent)(a.backEndLimit, 0)}) - ${a.backEndResult}`,
            `Overall DTI: ${a.overallDti}`,
            '',
            `FHA self-sufficiency: ${a.selfSufficiencyStatus}`,
            `Required reserves: ${a.requiredReserveMonths} month(s) = ${(0, num_16.currency)(a.requiredReserveDollars)}`,
            `Own-fund reserves after closing: ${(0, num_16.currency)(a.ownFundReservesAfterClosing)} (${a.reserveMonthsAvailable.toFixed(2)}x)`,
            `Reserve result: ${a.reserveStatus}`,
            `Gift funds: ${a.giftUtilization} (${(0, num_16.percent)(a.giftPctOfAssets, 1)} of assets)`,
            '',
            ...a.riskFactors.map((f) => `${f.factor}: ${f.result}`),
            `AUS planning score: ${a.ausPlanningScore}/100`,
            `Overall risk level: ${a.overallRiskLevel}`,
            '',
            a.notes,
            'Planning tool only. Final rental treatment, self-sufficiency, reserves and approval remain subject to FHA, DU/LPA and lender underwriting.',
        ].join('\n');
    }
    /** Full internal scenario summary for the loan officer / file. */
    function internalSummaryLines(inputs, out) {
        return [
            { label: 'Loan program', value: out.programLabel },
            { label: 'Renovation program', value: out.renovationActive ? (out.isFha ? '203(k)' : 'HomeStyle') : 'No renovation' },
            { label: 'Property type', value: `${out.aus.propertyType} (${out.aus.propertyTypeSource.toLowerCase()})` },
            { label: 'State / county', value: `${inputs.state}${inputs.state === 'New York' ? (inputs.isNYC ? ' / NYC' : ` / ${inputs.nyCounty}`) : ''}` },
            { label: 'Units', value: String(inputs.units) },
            { label: 'Base purchase price', value: (0, num_16.currency)(out.purchase.basePurchasePrice) },
            { label: 'Seller concession', value: `${(0, num_16.currency)(out.purchase.sellerConcessionAmount)} (${(0, num_16.percent)(out.purchase.sellerConcessionPct, 3)})` },
            { label: 'Final purchase price', value: (0, num_16.currency)(out.purchase.finalPurchasePrice) },
            { label: 'Total rehabilitation cost (B14)', value: (0, num_16.currency)(out.renovationOut.finalRenovationAmount) },
            { label: 'Rehabilitation escrow (B5)', value: (0, num_16.currency)(out.renovationOut.rehabEscrowSubtotal) },
            { label: 'Released at closing (B13)', value: (0, num_16.currency)(out.renovationOut.releasedAtClosing) },
            { label: 'Supplemental origination (B11)', value: (0, num_16.currency)(out.renovationOut.supplementalOrigination) },
            { label: 'Total acquisition cost', value: (0, num_16.currency)(out.loan.totalAcquisitionCost) },
            { label: 'Value basis (C3)', value: (0, num_16.currency)(out.loan.valueBasis) },
            { label: 'Minimum statutory investment', value: `${(0, num_16.currency)(out.loan.minimumStatutoryInvestment)} (${out.loan.msiBasisLabel})` },
            { label: 'Final down payment', value: (0, num_16.currency)(out.purchase.finalDownPayment) },
            { label: 'Required investment', value: (0, num_16.currency)(out.loan.requiredInvestment), emphasis: true },
            { label: 'Base loan before limits', value: (0, num_16.currency)(out.loan.baseLoanBeforeLimits) },
            { label: 'Applied FHA limit', value: out.isFha ? (0, num_16.currency)(out.loan.fhaLimitApplied) : 'N/A' },
            { label: 'FHA limit status', value: out.loan.fhaLimitStatus },
            { label: 'Maximum base loan', value: (0, num_16.currency)(out.loan.maximumBaseLoan), emphasis: true },
            { label: 'UFMIP', value: out.isFha ? (0, num_16.currency)(out.loan.ufmip) : '$0 (Conventional)' },
            { label: 'Total loan', value: (0, num_16.currency)(out.loan.totalLoan), emphasis: true },
            { label: 'Loan-to-cost', value: (0, num_16.percent)(out.loan.loanToCost, 2) },
            { label: 'ARV LTV', value: (0, num_16.percent)(out.loan.arvLtv, 2) },
            { label: 'Interest rate / term', value: `${(0, num_16.percent)(inputs.interestRate, 3)} / ${inputs.termYears} yr` },
            { label: 'Principal & interest', value: (0, num_16.currency)(out.payment.principalAndInterest, 2) },
            { label: 'FHA MIP (monthly)', value: out.isFha ? `${(0, num_16.currency)(out.payment.monthlyFhaMip, 2)} @ ${(0, num_16.percent)(out.payment.fhaMipRateUsed, 3)}` : '$0' },
            { label: 'Conventional PMI (monthly)', value: out.isFha ? '$0' : `${(0, num_16.currency)(out.payment.monthlyPmi, 2)} @ ${(0, num_16.percent)(out.payment.pmiRateUsed, 3)} (estimate)` },
            { label: 'Total monthly payment', value: (0, num_16.currency)(out.payment.totalMonthlyPayment, 2), emphasis: true },
            { label: 'Payment range', value: `${(0, num_16.currency)(out.payment.paymentLow)} - ${(0, num_16.currency)(out.payment.paymentHigh)}` },
            { label: 'Buyer closing costs', value: (0, num_16.currency)(out.closing.buyerClosingCosts) },
            { label: 'Mortgage recording tax', value: (0, num_16.currency)(out.closing.mortgageRecordingTax) },
            { label: 'Seller transfer tax (final)', value: (0, num_16.currency)(out.closing.finalSellerTransferTax) },
            { label: 'Mansion / luxury tax (buyer)', value: (0, num_16.currency)(out.closing.buyerLuxuryTax) },
            { label: 'Per-diem interest', value: `${(0, num_16.currency)(out.closing.perDiemInterest)} (${out.closing.perDiemDays} days)` },
            { label: 'Initial escrow deposit', value: (0, num_16.currency)(out.escrowOut.initialEscrowDeposit) },
            { label: 'Cash to close before EMD', value: (0, num_16.currency)(out.cash.cashToCloseBeforeEmd) },
            { label: 'Earnest money credit', value: (0, num_16.currency)(out.cash.earnestMoneyDeposit) },
            { label: 'Cash to close', value: (0, num_16.currency)(out.cash.cashToClose), emphasis: true },
            { label: 'Cash to close range', value: `${(0, num_16.currency)(out.cash.cashToCloseLow)} - ${(0, num_16.currency)(out.cash.cashToCloseHigh)}` },
            { label: 'Borrower equity after loan', value: `${(0, num_16.currency)(out.value.equityAfterLoan)} (${(0, num_16.percent)(out.value.equityPct, 2)})` },
            { label: 'Value created per $10,000 renovated', value: (0, num_16.currency)(out.value.valuePer10kRenovated) },
            { label: 'Minimum ARV needed', value: (0, num_16.currency)(out.value.minimumArvNeeded) },
            { label: 'Front-end / back-end DTI', value: `${(0, num_16.percent)(out.aus.frontEndDti, 2)} / ${(0, num_16.percent)(out.aus.backEndDti, 2)}` },
            { label: 'Self-sufficiency', value: out.aus.selfSufficiencyStatus },
            { label: 'Reserves', value: out.aus.reserveStatus },
            { label: 'AUS planning score', value: `${out.aus.ausPlanningScore}/100 - ${out.aus.overallRiskLevel}` },
            { label: 'Worksheet check', value: out.mmw.overallCheck },
            { label: 'Warnings', value: String(out.warnings.length) },
        ];
    }
});
define("src/ui/format", ["require", "exports", "src/core/utils/num"], function (require, exports, num_17) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fmtCurrency = fmtCurrency;
    exports.fmtCurrency2 = fmtCurrency2;
    exports.fmtPercent = fmtPercent;
    exports.fmtNumber = fmtNumber;
    exports.fmtRange = fmtRange;
    exports.parseFieldValue = parseFieldValue;
    exports.toInputValue = toInputValue;
    function fmtCurrency(value, dp = 0) {
        const n = (0, num_17.num)(value);
        return `${n < 0 ? '-' : ''}$${Math.abs(n).toLocaleString('en-US', {
            minimumFractionDigits: dp,
            maximumFractionDigits: dp,
        })}`;
    }
    function fmtCurrency2(value) {
        return fmtCurrency(value, 2);
    }
    function fmtPercent(value, dp = 3) {
        return `${((0, num_17.num)(value) * 100).toFixed(dp)}%`;
    }
    function fmtNumber(value, dp = 0) {
        return (0, num_17.num)(value).toLocaleString('en-US', { minimumFractionDigits: dp, maximumFractionDigits: dp });
    }
    function fmtRange(low, high, dp = 0) {
        return `${fmtCurrency(low, dp)} - ${fmtCurrency(high, dp)}`;
    }
    /** Parse a user-typed value for a given field kind. */
    function parseFieldValue(kind, raw) {
        switch (kind) {
            case 'currency':
            case 'number':
                return (0, num_17.num)(raw);
            case 'percent':
                return (0, num_17.num)(raw) / 100;
            case 'checkbox':
                return raw === 'true';
            default:
                return raw;
        }
    }
    /** Format a stored value back into an input box. A null override renders blank. */
    function toInputValue(kind, value) {
        if (value === null || value === undefined)
            return '';
        switch (kind) {
            case 'currency':
                return value === 0 ? '' : String((0, num_17.num)(value));
            case 'number':
                return String((0, num_17.num)(value));
            case 'percent': {
                const n = (0, num_17.num)(value) * 100;
                return n === 0 ? '' : String(Number(n.toFixed(6)));
            }
            default:
                return value === null || value === undefined ? '' : String(value);
        }
    }
});
define("src/ui/exporters", ["require", "exports", "src/core/summary", "src/ui/format"], function (require, exports, summary_1, format_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.buildScenarioCsv = buildScenarioCsv;
    exports.buildBorrowerCsv = buildBorrowerCsv;
    exports.borrowerText = borrowerText;
    exports.qualificationText = qualificationText;
    exports.downloadFile = downloadFile;
    exports.safeFileName = safeFileName;
    /** CSV-escape one cell. */
    function esc(v) {
        const s = String(v !== null && v !== void 0 ? v : '');
        return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    }
    function section(title, rows) {
        return ['', title, ...rows.map((r) => r.map(esc).join(','))];
    }
    /**
     * buildScenarioCsv() - a full data export of the scenario: every input, every
     * calculated output, the closing-cost detail, the escrow projection, the draw
     * schedule, the worksheet and the qualification block. Opens in Excel, Numbers
     * or Google Sheets.
     */
    function buildScenarioCsv(i, o) {
        var _a, _b;
        const lines = [];
        lines.push(`Mortgage Renovation Suite export,${i.name}`);
        lines.push(`Generated,${new Date().toISOString()}`);
        lines.push(...section('SCENARIO', [
            ['Borrower', i.borrowerName],
            ['Property', i.propertyAddress],
            ['ZIP', i.zipCode],
            ['Program', o.programLabel],
            ['Property type', o.aus.propertyType],
            ['State', i.state],
            ['County / NYC', i.state === 'New York' ? (i.isNYC ? 'NYC' : i.nyCounty) : ''],
            ['Units', i.units],
            ['As-of date', i.asOfDate],
            ['Estimated closing date', i.closingDate],
            ['Credit score', i.creditScore],
            ['Credit tier', o.payment.creditTier],
        ]));
        lines.push(...section('PURCHASE & DOWN PAYMENT', [
            ['Base purchase price', o.purchase.basePurchasePrice],
            ['Seller concession %', o.purchase.sellerConcessionPct],
            ['Seller concession $', o.purchase.sellerConcessionAmount],
            ['Credit increases price', i.concessionIncreasesPrice ? 'Yes' : 'No'],
            ['Final purchase price', o.purchase.finalPurchasePrice],
            ['Base down payment %', i.baseDownPaymentPct],
            ['Final down payment %', i.finalDownPaymentPct],
            ['Base down payment', o.purchase.baseDownPayment],
            ['Final down payment', o.purchase.finalDownPayment],
            ['Down payment difference', o.purchase.downPaymentDifference],
        ]));
        lines.push(...section('RENOVATION (HUD-92700 B SECTION)', [
            ['B1 base construction', o.renovationOut.baseCost],
            ['B2 contingency reserve', o.renovationOut.contingencyReserve],
            ['B3 inspections + title updates', o.renovationOut.inspectionFees + o.renovationOut.titleUpdateFees],
            ['B4 mortgage payments escrowed', o.renovationOut.paymentReserve],
            ['B5 rehabilitation escrow', o.renovationOut.rehabEscrowSubtotal],
            ['B6 architectural', i.reno.architectural],
            ['B7 consultant', i.reno.consultant],
            ['B8 permits', i.reno.permits],
            ['B9 other fees', i.reno.feasibilityOther + i.reno.otherFinanceable],
            ['B10 sub-total', o.renovationOut.subtotalB10],
            ['B11 supplemental origination', o.renovationOut.supplementalOrigination],
            ['B12 discount points on rehab', o.renovationOut.discountPointsRehab],
            ['B13 released at closing', o.renovationOut.releasedAtClosing],
            ['B14 total rehabilitation cost', o.renovationOut.finalRenovationAmount],
            ['A6 energy improvements', o.renovationOut.energyImprovements],
        ]));
        lines.push(...section('LOAN', [
            ['Total acquisition cost', o.loan.totalAcquisitionCost],
            ['C3 value basis', o.loan.valueBasis],
            ['Minimum statutory investment', o.loan.minimumStatutoryInvestment],
            ['MSI basis', o.loan.msiBasisLabel],
            ['Required investment', o.loan.requiredInvestment],
            ['Base loan before limits', o.loan.baseLoanBeforeLimits],
            ['Applied FHA limit', o.loan.fhaLimitApplied],
            ['Maximum base loan', o.loan.maximumBaseLoan],
            ['UFMIP', o.loan.ufmip],
            ['Total loan', o.loan.totalLoan],
            ['Loan-to-cost', o.loan.loanToCost],
            ['ARV LTV', o.loan.arvLtv],
            ['FHA limit status', o.loan.fhaLimitStatus],
        ]));
        lines.push(...section('PAYMENT', [
            ['Interest rate', i.interestRate],
            ['Term (years)', i.termYears],
            ['Principal & interest', o.payment.principalAndInterest],
            ['Monthly FHA MIP', o.payment.monthlyFhaMip],
            ['Monthly conventional PMI', o.payment.monthlyPmi],
            ['PMI rate used', o.payment.pmiRateUsed],
            ['Monthly taxes', o.payment.monthlyTaxes],
            ['Monthly insurance', o.payment.monthlyInsurance],
            ['Monthly HOA', o.payment.hoaMonthly],
            ['Total monthly payment', o.payment.totalMonthlyPayment],
            ['Payment low', o.payment.paymentLow],
            ['Payment high', o.payment.paymentHigh],
            ['PMI cancellation value', o.payment.pmiCancelValue],
        ]));
        lines.push(...section('CLOSING COSTS', [
            ['Line', 'Amount', 'Payer', 'Basis'],
            ...o.closing.lines.map((l) => { var _a; return [l.label, l.amount, l.payer, (_a = l.basis) !== null && _a !== void 0 ? _a : '']; }),
            ['Buyer closing costs', o.closing.buyerClosingCosts, 'buyer', ''],
            ['Closing costs low', o.closing.buyerClosingCostsLow, 'buyer', ''],
            ['Closing costs high (with cushion)', o.closing.buyerClosingCostsHigh, 'buyer', ''],
        ]));
        lines.push(...section('CASH TO CLOSE', [
            ['Required investment', o.cash.requiredInvestment],
            ['Buyer closing costs', o.cash.buyerClosingCosts],
            ['Seller concession applied', o.cash.sellerConcessionApplied],
            ['Cash to close before EMD', o.cash.cashToCloseBeforeEmd],
            ['Earnest money deposit', o.cash.earnestMoneyDeposit],
            ['Cash to close', o.cash.cashToClose],
            ['Cash to close low', o.cash.cashToCloseLow],
            ['Cash to close high', o.cash.cashToCloseHigh],
            ['Minimum investment after EMD', o.cash.minimumInvestmentAfterEmd],
        ]));
        lines.push(...section('VALUE & EQUITY', [
            ['As-is value', o.value.asIsValue],
            ['After-repair value', o.value.afterRepairValue],
            ['110% of ARV', o.value.arv110],
            ['Loan supported by value', (_a = o.value.loanSupportedByValue) !== null && _a !== void 0 ? _a : 0],
            ['Value cushion', (_b = o.value.valueCushion) !== null && _b !== void 0 ? _b : 0],
            ['Minimum as-is value needed', o.value.minimumAsIsValueNeeded],
            ['Minimum ARV needed', o.value.minimumArvNeeded],
            ['Value gained', o.value.valueGained],
            ['Borrower equity after loan', o.value.equityAfterLoan],
            ['Equity %', o.value.equityPct],
            ['Value per $10,000 renovated', o.value.valuePer10kRenovated],
            ['Appreciation rate', o.value.appreciationRate],
            [`Projected value (${o.value.projectionYears} yr)`, o.value.projectedValue],
            ['Projected equity', o.value.projectedEquity],
        ]));
        lines.push(...section('DRAW SCHEDULE', [
            ['Draw', 'Stage', 'Release', 'Inspection fee', 'Title fee', 'Cumulative', 'Remaining holdback'],
            ...o.renovationOut.drawSchedule.map((d) => [
                d.draw,
                d.stage,
                d.releaseAmount,
                d.inspectionFee,
                d.titleFee,
                d.cumulativeRelease,
                d.remainingHoldback,
            ]),
        ]));
        lines.push(...section('AGGREGATE ESCROW', [
            ['Annual taxes', o.escrowOut.annualTaxes],
            ['Annual insurance', o.escrowOut.annualInsurance],
            ['Annual flood', o.escrowOut.annualFlood],
            ['Monthly deposit', o.escrowOut.monthlyDeposit],
            ['Cushion months', o.escrowOut.cushionMonths],
            ['Required cushion', o.escrowOut.requiredCushion],
            ['Lowest trial balance', o.escrowOut.lowestTrialBalance],
            ['Initial escrow deposit', o.escrowOut.initialEscrowDeposit],
            ['First payment date', o.escrowOut.firstPaymentDate],
            [],
            ['Month', 'Due date', 'Deposit', 'Disbursement', 'For', 'Balance'],
            ...o.escrowOut.rows.map((r) => [
                r.monthLabel,
                r.dueDate,
                r.deposit,
                r.disbursements,
                r.disbursementLabels.join(' + '),
                r.balance,
            ]),
        ]));
        lines.push(...section('QUALIFICATION', [
            ['Total borrower income', o.aus.totalBorrowerIncome],
            ['Subject rental income', o.aus.totalSubjectQualifyingRent],
            ['Vacating adjustment', o.aus.vacatingNetAdjustment],
            ['Total qualifying income', o.aus.totalQualifyingIncome],
            ['Monthly liabilities', o.aus.totalMonthlyLiabilities],
            ['Front-end DTI', o.aus.frontEndDti],
            ['Back-end DTI', o.aus.backEndDti],
            ['Front-end result', o.aus.frontEndResult],
            ['Back-end result', o.aus.backEndResult],
            ['Maximum supported housing payment', o.aus.maxSupportedHousingPayment],
            ['FHA 75% self-sufficiency rent', o.aus.fhaSelfSufficiencyRent],
            ['Self-sufficiency status', o.aus.selfSufficiencyStatus],
            ['Total assets including gift', o.aus.totalAssetsIncludingGift],
            ['Gift % of assets', o.aus.giftPctOfAssets],
            ['Own-fund reserves after closing', o.aus.ownFundReservesAfterClosing],
            ['Reserve months available', o.aus.reserveMonthsAvailable],
            ['Required reserve months', o.aus.requiredReserveMonths],
            ['Reserve cushion', o.aus.reserveCushion],
            ['AUS planning score', o.aus.ausPlanningScore],
            ['Overall risk level', o.aus.overallRiskLevel],
            ...o.aus.riskFactors.map((f) => [`Risk: ${f.factor}`, f.result]),
        ]));
        lines.push(...section('MAXIMUM MORTGAGE WORKSHEET', [
            ['Ref', 'Line', 'Amount'],
            ...[...o.mmw.sectionA, ...o.mmw.sectionB, ...o.mmw.sectionC].map((l) => [l.ref, l.label, l.amount]),
            [],
            ['Verification', 'Worksheet', 'Calculator', 'Match'],
            ...o.mmw.verification.map((v) => [v.label, v.worksheet, v.calculator, v.match ? 'YES' : 'NO']),
            ['Overall check', o.mmw.overallCheck],
        ]));
        lines.push(...section('WARNINGS', [
            ['Severity', 'Module', 'Title', 'Detail'],
            ...o.warnings.map((w) => [w.severity, w.module, w.title, w.detail]),
        ]));
        lines.push(...section('INTERNAL SUMMARY', (0, summary_1.internalSummaryLines)(i, o).map((l) => [l.label, l.value])));
        return lines.join('\n');
    }
    /** A compact borrower-facing CSV (no DTI, no internal detail). */
    function buildBorrowerCsv(i, o) {
        const rows = [
            ['Prepared for', i.borrowerName || ''],
            ['Property', i.propertyAddress || ''],
            ['Program', o.programLabel],
            ['Purchase price', (0, format_1.fmtCurrency)(o.purchase.finalPurchasePrice)],
            ['Seller credit', (0, format_1.fmtCurrency)(o.purchase.sellerConcessionAmount)],
            ['Renovation budget', (0, format_1.fmtCurrency)(o.renovationOut.finalRenovationAmount)],
            ['Down payment', (0, format_1.fmtCurrency)(o.loan.requiredInvestment)],
            ['Total loan', (0, format_1.fmtCurrency)(o.loan.totalLoan)],
            ['Interest rate', (0, format_1.fmtPercent)(i.interestRate)],
            ['Payment range', `${(0, format_1.fmtCurrency)(o.payment.paymentLow)} - ${(0, format_1.fmtCurrency)(o.payment.paymentHigh)}`],
            ['Closing cost range', `${(0, format_1.fmtCurrency)(o.closing.buyerClosingCostsLow)} - ${(0, format_1.fmtCurrency)(o.closing.buyerClosingCostsHigh)}`],
            ['Cash to close range', `${(0, format_1.fmtCurrency)(o.cash.cashToCloseLow)} - ${(0, format_1.fmtCurrency)(o.cash.cashToCloseHigh)}`],
            ['Estimated equity', (0, format_1.fmtCurrency)(o.value.equityAfterLoan)],
        ];
        return ['Borrower estimate', ...rows.map((r) => r.map(esc).join(','))].join('\n');
    }
    function borrowerText(i, o) {
        return (0, summary_1.borrowerSummaryText)(i, o);
    }
    function qualificationText(i, o) {
        return (0, summary_1.qualificationSummaryText)(i, o);
    }
    /** Trigger a client-side file download (works in the app and in the single file). */
    function downloadFile(filename, contents, mime = 'text/csv;charset=utf-8') {
        try {
            const blob = new Blob([contents], { type: mime });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        }
        catch {
            /* download blocked - the copy buttons remain available */
        }
    }
    function safeFileName(name, ext) {
        const base = (name || 'scenario').replace(/[^\w\-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
        return `${base || 'scenario'}-${new Date().toISOString().slice(0, 10)}.${ext}`;
    }
});
define("src/ui/sections", ["require", "exports", "src/core/data/states", "src/core/data/marketData", "src/core/defaults", "src/core/summary", "src/ui/exporters", "src/ui/format"], function (require, exports, states_2, marketData_4, defaults_2, summary_2, exporters_1, format_2) {
    "use strict";
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CONVENTIONAL_RATE_PREMIUM = exports.TRACE_TARGETS = exports.SECTION_IDS = exports.SCREENS = exports.RAIL = void 0;
    exports.renovationScopeLabel = renovationScopeLabel;
    exports.screenFor = screenFor;
    exports.visibleScreens = visibleScreens;
    Object.defineProperty(exports, "CONVENTIONAL_RATE_PREMIUM", { enumerable: true, get: function () { return defaults_2.CONVENTIONAL_RATE_PREMIUM; } });
    // ---------------------------------------------------------------------------
    // helpers
    // ---------------------------------------------------------------------------
    const opts = (values) => values.map((v) => ({ value: v, label: v }));
    const money = (n, dp = 0) => (0, format_2.fmtCurrency)(n, dp);
    const money2 = (n) => (0, format_2.fmtCurrency)(n, 2);
    /** $700,000 -> $700K, for the one-line status strip only. */
    function compactMoney(n) {
        if (!Number.isFinite(n) || n === 0)
            return '$0';
        if (Math.abs(n) >= 1000000)
            return `$${(n / 1000000).toFixed(n % 1000000 === 0 ? 0 : 1)}M`;
        if (Math.abs(n) >= 1000)
            return `$${Math.round(n / 1000)}K`;
        return money(n);
    }
    const f = (path, label, type, extra = {}) => ({ kind: 'field', path, label, type, ...extra });
    const o = (label, get, extra = {}) => ({ kind: 'out', label, get, ...extra });
    const note = (text, extra = {}) => ({
        kind: 'note',
        text,
        ...extra,
    });
    const heading = (text, extra = {}) => ({ kind: 'heading', text, ...extra });
    // ---- condition helpers ------------------------------------------------------
    const renoOn = (i) => i.renovation;
    const renoOff = (i) => !i.renovation;
    const isNy = (i) => i.state === 'New York';
    const isFha = (i) => i.loanProgram === 'FHA';
    const isConv = (i) => i.loanProgram === 'Conventional';
    const notNy = (i) => i.state !== 'New York';
    const anyRentEntered = (i) => i.units > 1 ||
        i.rental.propertyTypeOverride !== 'Auto' ||
        i.rental.mainUnit.gross > 0 ||
        i.rental.adu.gross > 0 ||
        i.rental.unit2.gross > 0 ||
        i.rental.unit3.gross > 0 ||
        i.rental.unit4.gross > 0;
    const incomeEntered = (i) => i.borrowers.some((b) => b.grossMonthlyIncome > 0 || b.otherMonthlyIncome > 0 || b.monthlyDebts > 0);
    const errorsIn = (out, module) => out.warnings.some((w) => w.severity === 'error' && w.module.toLowerCase().includes(module));
    /** The 203(k) Limited / Standard / HomeStyle label - display framing, never a calculation input. */
    function renovationScopeLabel(i, out) {
        if (!i.renovation)
            return 'No renovation';
        if (i.renovationScope !== 'Auto')
            return i.renovationScope;
        if (i.loanProgram === 'Conventional')
            return 'HomeStyle';
        return out.renovationOut.finalRenovationAmount > 35000 ? '203(k) Standard' : '203(k) Limited';
    }
    const CREDIT_HINT = 'The credit tier is derived from the score.';
    // ===========================================================================
    // 1. SCENARIO CONTROL CENTER
    // ===========================================================================
    const controlCenter = {
        id: 'control',
        title: 'Scenario control center',
        level: 'major',
        compact: true,
        badge: (out, i) => ({ text: `${out.programLabel} - ${renovationScopeLabel(i, out)}`, cls: out.isFha ? 'on' : 'off' }),
        nodes: [
            f('loanProgram', 'Program', 'select', {
                options: opts(['FHA', 'Conventional']),
                onChange: (raw, store) => store.switchProgram(raw),
            }),
            f('renovationScope', 'Renovation program', 'select', {
                when: renoOn,
                options: (i, out) => [
                    { value: 'Auto', label: `Auto (${renovationScopeLabel({ ...i, renovationScope: 'Auto' }, out)})` },
                    { value: '203(k) Limited', label: '203(k) Limited' },
                    { value: '203(k) Standard', label: '203(k) Standard' },
                    { value: 'HomeStyle', label: 'HomeStyle' },
                ],
            }),
            f('renovation', 'Renovation', 'select', {
                options: [
                    { value: 'yes', label: 'Yes' },
                    { value: 'no', label: 'No' },
                ],
                onChange: (raw, store) => store.setField('renovation', raw === 'yes', 'Include renovation'),
            }),
            f('transactionType', 'Transaction', 'select', { options: opts(['Purchase', 'Refinance']) }),
            f('occupancy', 'Occupancy', 'select', { options: opts(['Primary Residence', 'Second Home', 'Investment']) }),
            f('rental.propertyTypeOverride', 'Property type', 'select', {
                options: opts(['Auto', '1 Family', 'Single Family with ADU', '2 Family', '3 Family', '4 Family']),
            }),
            f('units', 'Units', 'number', { step: '1' }),
            f('state', 'State', 'select', { options: opts(states_2.US_STATES) }),
            f('nyCounty', 'County / area', 'select', { options: opts(states_2.NY_AREAS), when: isNy }),
            note((_out, i) => `${i.transactionType === 'Purchase'
                ? ''
                : 'This engine calculates PURCHASE transactions (HUD-92700 section C) - refinance figures are not modelled. '}${i.occupancy === 'Primary Residence'
                ? ''
                : 'Pricing and mortgage insurance assume an owner-occupied primary residence, so this scenario needs a manual check.'}`, { when: (i) => i.transactionType !== 'Purchase' || i.occupancy !== 'Primary Residence' }),
        ],
    };
    // ===========================================================================
    // 2. QUOTE  (always visible)
    // ===========================================================================
    const quoteCard = {
        id: 'quote',
        title: 'Quote',
        level: 'major',
        badge: (out) => ({ text: out.programLabel, cls: out.isFha ? 'on' : 'off' }),
        nodes: [
            {
                kind: 'columns',
                cols: [
                    {
                        title: 'Loan',
                        nodes: [
                            o('Purchase price', (out) => money(out.purchase.finalPurchasePrice), { trace: 'finalPurchasePrice' }),
                            o('Renovation', (out) => money(out.renovationOut.finalRenovationAmount), {
                                trace: 'finalRenovationAmount',
                                when: renoOn,
                            }),
                            o('ARV / value used', (out) => (out.value.afterRepairValue > 0 ? money(out.value.afterRepairValue) : 'Pending appraisal'), { tone: (out) => (out.value.afterRepairValue > 0 ? '' : 'na') }),
                            o('Base loan', (out) => money2(out.loan.maximumBaseLoan), { trace: 'maximumBaseLoan' }),
                            o('UFMIP', (out) => money2(out.loan.ufmip), { trace: 'ufmip', when: isFha }),
                            o('TOTAL LOAN', (out) => money2(out.loan.totalLoan), { trace: 'totalLoan', tone: () => 'final hero' }),
                        ],
                    },
                    {
                        title: 'Monthly payment',
                        nodes: [
                            f('interestRate', 'Rate %', 'percent'),
                            f('termYears', 'Term (years)', 'number', { step: '1' }),
                            o('Principal & interest', (out) => money2(out.payment.principalAndInterest), {
                                trace: 'principalAndInterest',
                            }),
                            o('Taxes', (out) => money2(out.payment.monthlyTaxes)),
                            o('Insurance', (out) => money2(out.payment.monthlyInsurance)),
                            o('HOA / other', (out) => money2(out.payment.hoaMonthly), { when: (i) => i.hoaMonthly > 0 }),
                            o('Monthly MIP', (out) => money2(out.payment.monthlyFhaMip), { trace: 'monthlyFhaMip', when: isFha }),
                            o('Monthly PMI', (out) => money2(out.payment.monthlyPmi), { trace: 'monthlyPmi', when: isConv }),
                            o('TOTAL PAYMENT', (out) => money2(out.payment.totalMonthlyPayment), {
                                trace: 'totalMonthlyPayment',
                                tone: () => 'final hero',
                            }),
                        ],
                    },
                    {
                        title: 'Borrower funds',
                        nodes: [
                            o('Minimum investment', (out) => money2(out.loan.requiredInvestment), { trace: 'requiredInvestment' }),
                            o('Plus closing costs', (out) => money2(out.closing.buyerClosingCosts), { trace: 'buyerClosingCosts' }),
                            o('Less seller credit', (out) => `- ${money2(out.cash.sellerConcessionApplied)}`, {
                                tone: () => 'pass',
                                when: (i, out) => out.cash.sellerConcessionApplied > 0,
                            }),
                            o('Less earnest money', (out) => `- ${money2(out.cash.earnestMoneyDeposit)}`, {
                                tone: () => 'pass',
                                when: (i) => i.closing.earnestMoneyDeposit > 0,
                            }),
                            o('REMAINING CASH TO CLOSE', (out) => money2(out.cash.cashToClose), {
                                trace: 'cashToClose',
                                tone: () => 'final hero',
                            }),
                            o('With the cushion', (out) => `${money(out.cash.cashToCloseLow)} - ${money(out.cash.cashToCloseHigh)}`, { tone: () => 'pass' }),
                        ],
                    },
                ],
            },
            {
                kind: 'chips',
                get: (out, i) => {
                    const chips = [
                        { text: `${out.programLabel}${i.renovation ? ` ${renovationScopeLabel(i, out)}` : ''}` },
                        { text: `${out.aus.propertyType}` },
                        { text: `${(0, format_2.fmtPercent)(out.payment.currentLtv, 1)} LTV` },
                    ];
                    if (out.renovationActive)
                        chips.push({ text: `${money(out.renovationOut.finalRenovationAmount)} rehab` });
                    if (out.value.afterRepairValue > 0)
                        chips.push({ text: `${compactMoney(out.value.afterRepairValue)} ARV` });
                    if (out.aus.totalQualifyingIncome > 0) {
                        chips.push({
                            text: `${(0, format_2.fmtPercent)(out.aus.backEndDti, 1)} DTI`,
                            tone: out.aus.overallDti === 'PASS' ? 'pass' : out.aus.overallDti === 'FAIL' ? 'bad' : '',
                        });
                    }
                    const errors = out.warnings.filter((w) => w.severity === 'error').length;
                    chips.push(errors === 0
                        ? { text: 'Major checks passed', tone: 'pass' }
                        : { text: `${errors} issue${errors === 1 ? '' : 's'} to review`, tone: 'bad' });
                    return chips;
                },
            },
        ],
    };
    // ===========================================================================
    // 3. PROPERTY & LOAN SETUP
    // ===========================================================================
    const setupCard = {
        id: 'setup',
        title: 'Property & loan setup',
        level: 'major',
        grid: true,
        collapsible: true,
        summary: (out, i) => `${i.state}${i.state === 'New York' && i.nyCounty ? ` - ${i.nyCounty}` : ''} - ${out.aus.propertyType} - ${money(out.purchase.finalPurchasePrice)} - ${(0, format_2.fmtPercent)(i.finalDownPaymentPct, 2)} down`,
        autoExpand: (out) => out.purchase.finalPurchasePrice === 0,
        nodes: [
            heading('Transaction'),
            f('transactionType', 'Transaction type', 'select', { options: opts(['Purchase', 'Refinance']) }),
            f('occupancy', 'Occupancy', 'select', {
                options: opts(['Primary Residence', 'Second Home', 'Investment']),
            }),
            f('loanProgram', 'Loan program', 'select', {
                options: opts(['FHA', 'Conventional']),
                onChange: (raw, store) => store.switchProgram(raw),
            }),
            f('renovation', 'Renovation', 'select', {
                options: [
                    { value: 'yes', label: 'Yes' },
                    { value: 'no', label: 'No' },
                ],
                onChange: (raw, store) => store.setField('renovation', raw === 'yes', 'Include renovation'),
            }),
            f('renovationScope', 'Renovation program', 'select', {
                options: opts(['Auto', '203(k) Limited', '203(k) Standard', 'HomeStyle']),
                when: renoOn,
            }),
            {
                kind: 'actions',
                buttons: [
                    {
                        label: 'Switch to Conventional (+0.375%)',
                        run: (s) => s.switchProgram('Conventional'),
                        hidden: (i) => i.loanProgram === 'Conventional',
                    },
                    {
                        label: 'Switch to FHA (-0.375%)',
                        run: (s) => s.switchProgram('FHA'),
                        hidden: (i) => i.loanProgram === 'FHA',
                    },
                    { label: 'Compare both programs', run: (s) => s.compareProgramScenario(), variant: 'ghost' },
                ],
            },
            heading('Property'),
            f('borrowerName', 'Borrower name', 'text'),
            f('propertyAddress', 'Property address', 'text'),
            f('zipCode', 'ZIP code', 'text'),
            f('state', 'State', 'select', { options: opts(states_2.US_STATES) }),
            f('nyCounty', 'NY county / area', 'select', { options: opts(states_2.NY_AREAS), when: isNy }),
            f('rental.propertyTypeOverride', 'Property type', 'select', {
                options: opts(['Auto', '1 Family', 'Single Family with ADU', '2 Family', '3 Family', '4 Family']),
            }),
            f('units', 'Units (1-4)', 'number', { step: '1' }),
            f('creditScore', 'Representative credit score', 'number', { step: '1', hint: CREDIT_HINT }),
            f('fhaAreaSelection', 'FHA area tier', 'select', {
                options: opts(['Auto', 'Standard', 'High-Cost', 'Special Exception']),
                when: isFha,
            }),
            f('isNYC', 'Property is in New York City', 'checkbox', { when: isNy }),
            {
                kind: 'actions',
                buttons: [
                    { label: 'Look up ZIP', run: (s) => s.applyZipLookup() },
                    { label: 'Search online', run: (s) => void s.lookupZipOnline(), variant: 'ghost' },
                    { label: 'Seed as-is + ARV from area', run: (s) => s.applyAreaValues(), variant: 'ghost' },
                    { label: 'Save borrower + property', run: (s) => s.captureBorrowerAndProperty(), variant: 'ghost' },
                ],
            },
            heading('Price & values'),
            f('basePurchasePrice', 'Purchase price', 'currency'),
            f('asIsValue', 'As-is value', 'currency'),
            f('afterRepairValue', 'After-repair value (ARV)', 'currency'),
            f('concessionInputMode', 'Seller credit entered as', 'select', {
                options: [
                    { value: 'percent', label: 'Percentage' },
                    { value: 'dollar', label: 'Dollar amount' },
                ],
            }),
            f('sellerConcessionPct', 'Seller credit %', 'percent', {
                disabled: (i) => i.concessionInputMode !== 'percent',
            }),
            f('sellerConcessionAmount', 'Seller credit $', 'currency', {
                disabled: (i) => i.concessionInputMode !== 'dollar',
            }),
            o('Maximum seller credit', (out) => `${money2(out.purchase.sellerConcessionLimit)} (${(0, format_2.fmtPercent)(out.purchase.sellerConcessionLimitPct, 0)})`, {
                tone: (out) => (out.purchase.sellerConcessionOverLimit > 0 ? 'bad' : 'pass'),
            }),
            o('Over the limit - not applied', (out) => money2(out.purchase.sellerConcessionOverLimit), {
                when: (_i, out) => out.purchase.sellerConcessionOverLimit > 0,
                tone: () => 'bad',
            }),
            note((out) => `Interested-party limit: ${out.purchase.concessionLimitNote}.`),
            o('Seller credit applied', (out) => `${money2(out.purchase.sellerConcessionAllowed)} (${(0, format_2.fmtPercent)(out.purchase.sellerConcessionPct)})`, {
                trace: 'sellerConcession',
            }),
            f('concessionIncreasesPrice', 'The seller credit increases the purchase price', 'checkbox', {
                hint: 'On: Final = Base + credit. Off: the credit comes out of the agreed price.',
            }),
            heading('Financing'),
            f('finalDownPaymentPct', 'Down payment %', 'percent'),
            f('baseDownPaymentPct', 'Comparison down payment %', 'percent', { hint: 'Side-by-side only' }),
            f('interestRate', 'Interest rate %', 'percent'),
            f('termYears', 'Term (years)', 'number', { step: '1' }),
            f('closing.earnestMoneyDeposit', 'Earnest money deposit', 'currency'),
            f('asOfDate', 'As-of date', 'date'),
            f('closingDate', 'Estimated closing date', 'date'),
            f('ufmipRate', 'UFMIP rate', 'percent', { when: isFha }),
            f('fhaAnnualMipRate', 'Annual FHA MIP rate', 'select', {
                options: defaults_2.FHA_MIP_RATE_OPTIONS.map((r) => ({ value: String(r), label: `${(r * 100).toFixed(2)}%` })),
                when: isFha,
                onChange: (raw, store) => store.setField('fhaAnnualMipRate', Number(raw), 'Annual FHA MIP rate'),
            }),
            f('fhaMipOverrideRate', 'FHA MIP override %', 'percent', { when: isFha }),
            f('pmiOverrideRate', 'PMI override %', 'percent', { when: isConv }),
            o('Suggested PMI rate', (out) => (0, format_2.fmtPercent)(out.payment.pmiSuggestedRate), { when: isConv }),
            o('Value needed to cancel PMI at 80% LTV', (out) => money(out.payment.pmiCancelValue), {
                when: isConv,
                tone: () => 'pass',
            }),
            heading('Taxes, insurance & rounding'),
            f('propertyTaxAmount', 'Property taxes', 'currency'),
            f('propertyTaxBasis', 'Taxes entered as', 'select', { options: opts(['Annual', 'Monthly']) }),
            f('insuranceAmount', 'Homeowners insurance', 'currency'),
            f('insuranceBasis', 'Insurance entered as', 'select', { options: opts(['Annual', 'Monthly']) }),
            f('taxInsuranceOverrideMonthly', 'Monthly T&I override', 'currency', {
                hint: 'Over $0 replaces the two fields above',
            }),
            f('hoaMonthly', 'HOA / other monthly', 'currency'),
            f('taxSourceType', 'Property tax source', 'select', {
                options: opts([
                    'Title Company Tax Certificate',
                    'County/City Tax Assessor',
                    'Property Tax Card',
                    'MLS / Zillow / Redfin Estimate',
                    'Manual',
                ]),
            }),
            f('taxHasExemption', 'Current taxes include an exemption', 'checkbox'),
            f('exemptionType', 'Exemption type', 'text', { when: (i) => i.taxHasExemption }),
            f('paymentRoundingIncrement', 'Payment rounding', 'select', {
                options: defaults_2.PAYMENT_ROUNDING_OPTIONS.map((r) => ({ value: String(r), label: `$${r}` })),
                onChange: (raw, store) => store.setField('paymentRoundingIncrement', Number(raw), 'Payment rounding'),
            }),
            note((out) => `Area planning data for ${out.stateRules.state}: ${out.value.appreciationSource}. Replace ZIP-derived taxes and insurance with the tax certificate and the insurance quote before disclosing.`),
        ],
    };
    // ===========================================================================
    // 4. RENOVATION
    // ===========================================================================
    const renovationCard = {
        id: 'renovation',
        title: 'Renovation',
        level: 'major',
        collapsible: true,
        visible: (out, i) => i.renovation,
        autoExpand: (out, i) => i.renovation && out.renovationOut.finalRenovationAmount === 0,
        summary: (out) => money(out.renovationOut.finalRenovationAmount),
        badge: (out, i) => ({ text: renovationScopeLabel(i, out), cls: 'on' }),
        nodes: [
            {
                kind: 'columns',
                cols: [
                    {
                        title: 'Repairs',
                        nodes: [
                            f('reno.baseCost', 'Contractor / base renovation', 'currency'),
                            f('reno.feasibilityOther', 'Additional repairs / feasibility', 'currency'),
                            f('reno.permits', 'Permits', 'currency'),
                            f('reno.architectural', 'Architect / engineering', 'currency'),
                            f('reno.energyImprovements', 'Allowable energy improvements', 'currency'),
                        ],
                    },
                    {
                        title: 'Financed / required costs',
                        nodes: [
                            f('reno.contingencyPct', 'Contingency %', 'percent'),
                            f('reno.utilitiesOff', 'Utilities off at inspection', 'checkbox', {
                                hint: 'Suggests 20% instead of 10%',
                            }),
                            o('Contingency reserve', (out) => money2(out.renovationOut.contingencyReserve), {
                                trace: 'contingencyReserve',
                            }),
                            o('Suggested contingency', (out) => (0, format_2.fmtPercent)(out.renovationOut.suggestedContingencyPct, 0), {
                                tone: (out, i) => (i.reno.contingencyPct < out.renovationOut.suggestedContingencyPct ? 'amber' : 'pass'),
                            }),
                            f('reno.consultant', 'Consultant fee', 'currency'),
                            f('reno.syncDrawFees', 'Sync draw fees to the draw planner', 'checkbox'),
                            f('reno.inspectionFees', 'Draw inspection fees', 'currency', {
                                disabled: (i) => i.reno.syncDrawFees,
                            }),
                            f('reno.titleUpdateFees', 'Title update fees', 'currency', {
                                disabled: (i) => i.reno.syncDrawFees,
                            }),
                            f('reno.supplementalOriginationOverride', 'Supplemental origination override', 'currency', {
                                hint: 'Blank / $0 auto-calculates: greater of $350 or 1.5%',
                            }),
                            o('Supplemental origination', (out) => money2(out.renovationOut.supplementalOrigination), {
                                trace: 'supplementalOrigination',
                            }),
                            f('reno.discountPointsRehabPct', 'Discount points on rehab %', 'percent'),
                            o('Discount points on rehab', (out) => money2(out.renovationOut.discountPointsRehab)),
                            f('reno.otherFinanceable', 'Other eligible costs', 'currency'),
                        ],
                    },
                    {
                        title: 'Mortgage payment reserve',
                        nodes: [
                            f('reno.paymentReserveMonths', 'Months escrowed (0-6)', 'number', { step: '1' }),
                            o('Monthly PITI used', (out) => money2(out.payment.totalMonthlyPayment), {
                                trace: 'totalMonthlyPayment',
                            }),
                            o('Reserve financed', (out) => money2(out.renovationOut.paymentReserve), { tone: () => 'pass' }),
                            note((out, i) => i.reno.paymentReserveMonths > 0
                                ? `${i.reno.paymentReserveMonths} x ${money2(out.payment.totalMonthlyPayment)} = ${money2(out.renovationOut.paymentReserve)}, financed inside the renovation budget. The payment is taken from the preliminary pass, so the reserve never chases its own result.`
                                : 'Enter a number of months and the reserve calculates itself from the live monthly payment.'),
                            o('Rehabilitation escrow account', (out) => money2(out.renovationOut.rehabEscrowSubtotal), {
                                tone: () => 'pass',
                            }),
                            o('Released at closing', (out) => money2(out.renovationOut.releasedAtClosing)),
                        ],
                    },
                ],
            },
            o('FINAL RENOVATION AMOUNT', (out) => money2(out.renovationOut.finalRenovationAmount), {
                trace: 'finalRenovationAmount',
                tone: () => 'final hero',
            }),
            note('Supplemental origination and rehab discount points recalculate from the sub-total on every change, exactly as on HUD-92700. They are financed into the loan, not collected from the borrower at the table.'),
        ],
        children: [
            {
                id: 'reno-draws',
                title: 'Draw planner & contractor milestones',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: (out) => `${out.renovationOut.drawCount} draw${out.renovationOut.drawCount === 1 ? '' : 's'}`,
                nodes: [
                    {
                        kind: 'columns',
                        cols: [
                            {
                                title: 'Planner',
                                nodes: [
                                    o('Suggested draw count', (out) => String(out.renovationOut.suggestedDrawCount)),
                                    f('draws.manualOverride', 'Override the draw count', 'checkbox'),
                                    f('draws.manualDrawCount', 'Number of draws', 'number', {
                                        step: '1',
                                        disabled: (i) => !i.draws.manualOverride,
                                    }),
                                    f('draws.inspectionFeePerDraw', 'Inspection fee per draw', 'currency'),
                                    f('draws.titleFeePerDraw', 'Title update fee per draw', 'currency'),
                                    f('draws.initialMaterialRelease', 'Initial material release', 'currency', { when: isConv }),
                                ],
                            },
                            {
                                title: 'Reconciliation',
                                nodes: [
                                    o('Draw count used', (out) => String(out.renovationOut.drawCount)),
                                    o('Expected inspection fees', (out) => money2(out.renovationOut.expectedInspectionFees), {
                                        trace: 'drawInspectionFees',
                                    }),
                                    o('Expected title update fees', (out) => money2(out.renovationOut.expectedTitleFees), {
                                        trace: 'drawTitleFees',
                                    }),
                                    o('Budgeted inspection fees', (out) => money2(out.renovationOut.inspectionFees), {
                                        tone: (out) => Math.abs(out.renovationOut.inspectionFees - out.renovationOut.expectedInspectionFees) > 0.5
                                            ? 'bad'
                                            : 'pass',
                                    }),
                                    o('Budgeted title update fees', (out) => money2(out.renovationOut.titleUpdateFees), {
                                        tone: (out) => Math.abs(out.renovationOut.titleUpdateFees - out.renovationOut.expectedTitleFees) > 0.5
                                            ? 'bad'
                                            : 'pass',
                                    }),
                                ],
                            },
                        ],
                    },
                    {
                        kind: 'table',
                        head: ['Draw', 'Construction stage', 'Scope', 'Release', 'Inspection', 'Title', 'Cumulative', 'Remaining'],
                        rows: (out) => out.renovationOut.drawSchedule.map((d) => [
                            { text: `Draw ${d.draw}`, align: 'l' },
                            { text: d.stage, align: 'l' },
                            { text: (0, format_2.fmtPercent)(d.scopeShare, 0) },
                            { text: money2(d.releaseAmount) },
                            { text: money2(d.inspectionFee) },
                            { text: money2(d.titleFee) },
                            { text: money2(d.cumulativeRelease) },
                            { text: money2(d.remainingHoldback), tone: 'muted' },
                        ]),
                    },
                    note('One stage per draw, scaled to the draw count. Planning suggestions - cross-check the contractor payment schedule and current lender guidance.'),
                ],
            },
        ],
    };
    // ===========================================================================
    // 5. MAXIMUM MORTGAGE & VALUE
    // ===========================================================================
    /** The one headline verdict, shared by the summary rail and the maximum-mortgage tab. */
    const fitStatus = {
        kind: 'status',
        get: (out) => {
            if (out.isFha && out.loan.amountOverFhaLimit > 0) {
                return `Over the FHA county limit by ${money(out.loan.amountOverFhaLimit)} - reduce the loan or check the area tier`;
            }
            if (out.value.valueCushion === null) {
                return `Enter an after-repair value to test the ${out.value.arvLimitLabel}`;
            }
            return out.value.valueCushion >= 0
                ? `Fits - ${money(out.value.valueCushion)} under the ${out.value.arvLimitLabel}`
                : `Over by ${money(Math.abs(out.value.valueCushion))} against the ${out.value.arvLimitLabel}`;
        },
        tone: (out) => {
            if (out.isFha && out.loan.amountOverFhaLimit > 0)
                return 'bad';
            if (out.value.valueCushion === null)
                return 'na';
            return out.value.valueCushion >= 0 ? 'pass' : 'bad';
        },
    };
    const maxMortgageCard = {
        id: 'maxmortgage',
        title: 'Maximum mortgage & value',
        level: 'major',
        collapsible: true,
        defaultCollapsed: true,
        force: (out) => errorsIn(out, 'loan') || errorsIn(out, 'value'),
        autoExpand: (_out, i) => i.loanProgram === 'FHA' && i.renovation,
        summary: (out) => out.isFha && out.loan.amountOverFhaLimit > 0
            ? `${money(out.loan.maximumBaseLoan)} - over the county limit`
            : out.loan.limitBinding === 'none'
                ? `${money(out.loan.maximumBaseLoan)} \u2713`
                : `${money(out.loan.maximumBaseLoan)} - value capped`,
        summaryTone: (out) => out.isFha && out.loan.amountOverFhaLimit > 0 ? 'bad' : out.loan.limitBinding === 'none' ? 'pass' : 'amber',
        badge: (out) => out.isFha
            ? out.loan.amountOverFhaLimit > 0
                ? { text: 'OVER COUNTY LIMIT', cls: 'bad' }
                : { text: 'WITHIN COUNTY LIMIT', cls: 'on' }
            : { text: 'VALUE-SUPPORTED', cls: 'on' },
        nodes: [
            fitStatus,
            {
                kind: 'columns',
                cols: [
                    {
                        title: 'Maximum mortgage',
                        nodes: [
                            o('Purchase / acquisition', (out) => money2(out.purchase.finalPurchasePrice), {
                                trace: 'finalPurchasePrice',
                            }),
                            o('Eligible renovation', (out) => money2(out.renovationOut.finalRenovationAmount), {
                                when: renoOn,
                                trace: 'finalRenovationAmount',
                            }),
                            o('Acquisition + improvements', (out) => money2(out.loan.totalAcquisitionCost), {
                                trace: 'totalAcquisitionCost',
                            }),
                            o('Value ceiling', (out) => out.value.afterRepairValue > 0
                                ? `${money2(out.value.arvLimitValue)} (${out.value.arvLimitLabel})`
                                : 'No ARV entered', {
                                trace: 'arv110',
                                tone: (out) => (out.value.afterRepairValue > 0 ? '' : 'na'),
                            }),
                            o('Lesser value used (C3)', (out) => money2(out.loan.valueBasis), { trace: 'valueBasis' }),
                            o('Maximum LTV', (out, i) => out.renovationActive && !out.isFha
                                ? `${(0, format_2.fmtPercent)(Math.min(1 - i.finalDownPaymentPct, out.value.arvLimitPct), 2)} (HomeStyle caps at 95%)`
                                : (0, format_2.fmtPercent)(1 - i.finalDownPaymentPct, 2), {
                                tone: (out, i) => out.renovationActive && !out.isFha && 1 - i.finalDownPaymentPct > out.value.arvLimitPct
                                    ? 'amber'
                                    : '',
                            }),
                            o('MAXIMUM BASE MORTGAGE', (out) => money2(out.loan.maximumBaseLoan), {
                                trace: 'maximumBaseLoan',
                                tone: () => 'final',
                            }),
                            o('County limit', (out) => money(out.loan.fhaLimitApplied), { trace: 'fhaLimit', when: isFha }),
                            o('Amount over the county limit', (out) => money2(out.loan.amountOverFhaLimit), {
                                when: (i, out) => out.isFha && out.loan.amountOverFhaLimit > 0,
                                tone: () => 'bad',
                            }),
                            o('UFMIP added', (out) => money2(out.loan.ufmip), { trace: 'ufmip', when: isFha }),
                            o('TOTAL LOAN', (out) => money2(out.loan.totalLoan), { trace: 'totalLoan', tone: () => 'final' }),
                        ],
                    },
                    {
                        title: 'Borrower investment',
                        nodes: [
                            o('Minimum statutory investment', (out) => money2(out.loan.minimumStatutoryInvestment), {
                                trace: 'minimumStatutoryInvestment',
                                when: isFha,
                            }),
                            o('Basis used', (out) => out.loan.msiBasisLabel, { when: isFha }),
                            o('Required investment', (out) => money2(out.loan.requiredInvestment), { trace: 'requiredInvestment' }),
                            o('Earnest money applied', (out) => money2(out.cash.earnestMoneyDeposit), {
                                when: (i) => i.closing.earnestMoneyDeposit > 0,
                            }),
                            o('REMAINING MINIMUM INVESTMENT', (out) => money2(out.cash.minimumInvestmentAfterEmd), {
                                tone: () => 'final',
                            }),
                            o('Base down payment', (out) => money2(out.purchase.baseDownPayment), { trace: 'baseDownPayment' }),
                            o('Down payment difference', (out) => money2(out.purchase.downPaymentDifference), {
                                trace: 'downPaymentDifference',
                            }),
                            note('FHA takes the statutory investment against the C3 value basis - the lesser of (price or as-is value) plus rehabilitation, capped at 110% of the after-repair value - not against total acquisition cost.', { when: isFha }),
                        ],
                    },
                    {
                        title: 'ARV, equity & value',
                        nodes: [
                            o('Purchase price', (out) => money(out.purchase.finalPurchasePrice)),
                            o('Renovation', (out) => money(out.renovationOut.finalRenovationAmount), { when: renoOn }),
                            o('Total basis', (out) => money(out.loan.totalAcquisitionCost)),
                            o('After-repair value', (out) => out.value.afterRepairValue > 0 ? money(out.value.afterRepairValue) : 'Pending appraisal'),
                            o('Value created', (out) => money(out.value.valueGained), {
                                tone: (out) => (out.value.valueGained > 0 ? 'pass' : 'na'),
                            }),
                            o('Loan-to-ARV', (out) => out.value.afterRepairValue > 0 ? (0, format_2.fmtPercent)(out.loan.arvLtv, 2) : 'No ARV entered'),
                            o('Projected equity', (out) => money2(out.value.equityAfterLoan), {
                                trace: 'borrowerEquity',
                                tone: () => 'pass',
                            }),
                            o('Equity %', (out) => (0, format_2.fmtPercent)(out.value.equityPct, 2)),
                            o('Value needed to cancel MI at 80% LTV', (out) => money(out.payment.pmiCancelValue), {
                                when: isConv,
                                tone: () => 'pass',
                            }),
                            o('Minimum as-is value needed', (out) => money(out.value.minimumAsIsValueNeeded), {
                                trace: 'minimumAsIsValue',
                            }),
                            o('Minimum ARV needed', (out) => money(out.value.minimumArvNeeded), { trace: 'minimumArv' }),
                        ],
                    },
                ],
            },
        ],
        children: [
            {
                id: 'mmw-detail',
                title: 'Show full HUD / MMW detail',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                // The HUD-92700 worksheet is an FHA form - it has no place in a Conventional file.
                visible: (_out, i) => i.loanProgram === 'FHA',
                summary: (out) => out.mmw.overallCheck,
                summaryTone: (out) => (out.mmw.overallCheck === 'PASS - SYNCED' ? 'pass' : 'bad'),
                nodes: [
                    {
                        kind: 'columns',
                        cols: [
                            {
                                title: 'A. Property information',
                                nodes: [
                                    {
                                        kind: 'table',
                                        head: ['Ref', 'Line', 'Amount'],
                                        rows: (out) => out.mmw.sectionA.map((l) => [
                                            { text: l.ref, align: 'l' },
                                            { text: l.label + (l.note ? ` - ${l.note}` : ''), align: 'l' },
                                            { text: money2(l.amount) },
                                        ]),
                                    },
                                    {
                                        kind: 'table',
                                        head: ['Ref', 'C. Purchase transactions', 'Amount'],
                                        rows: (out) => out.mmw.sectionC.map((l) => [
                                            { text: l.ref, align: 'l' },
                                            { text: l.label + (l.note ? ` - ${l.note}` : ''), align: 'l' },
                                            { text: money2(l.amount) },
                                        ]),
                                    },
                                ],
                            },
                            {
                                title: 'B. Rehabilitation & other allowable costs',
                                nodes: [
                                    {
                                        kind: 'table',
                                        head: ['Ref', 'Line', 'Amount'],
                                        rows: (out) => out.mmw.sectionB.map((l) => [
                                            { text: l.ref, align: 'l' },
                                            { text: l.label + (l.note ? ` - ${l.note}` : ''), align: 'l' },
                                            { text: money2(l.amount) },
                                        ]),
                                        maxHeight: 460,
                                    },
                                ],
                            },
                            {
                                title: 'Final loan, EMD & verification',
                                nodes: [
                                    {
                                        kind: 'table',
                                        head: ['Line', 'Amount'],
                                        rows: (out) => out.mmw.finalBlock.map((l) => [
                                            { text: l.label + (l.note ? ` - ${l.note}` : ''), align: 'l' },
                                            { text: money2(l.amount) },
                                        ]),
                                    },
                                    o('County limit status', (out) => out.mmw.countyLimitStatus, {
                                        tone: (out) => (out.mmw.countyLimitStatus === 'OVER LIMIT' ? 'bad' : 'pass'),
                                    }),
                                    {
                                        kind: 'table',
                                        head: ['Line', 'Worksheet', 'Calculator', 'Match'],
                                        rows: (out) => out.mmw.verification.map((v) => [
                                            { text: v.label, align: 'l' },
                                            { text: money2(v.worksheet) },
                                            { text: money2(v.calculator) },
                                            { text: v.match ? 'MATCH' : 'REVIEW', tone: v.match ? 'pos' : 'neg' },
                                        ]),
                                    },
                                    note('The worksheet is not a second calculation - every line reads the live engine, so it cannot drift out of sync.'),
                                ],
                            },
                        ],
                    },
                ],
            },
            {
                id: 'value-projection',
                title: 'Property value projection',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: (out) => `${money(out.value.projectedValue)} in ${out.value.projectionYears} yrs`,
                nodes: [
                    {
                        kind: 'columns',
                        cols: [
                            {
                                title: 'Assumptions',
                                nodes: [
                                    f('projection.years', 'Projection years', 'number', { step: '1' }),
                                    f('projection.appreciationRateOverride', 'Appreciation override %', 'percent', {
                                        hint: 'Leave 0% to use the state assumption',
                                    }),
                                    o('Appreciation rate used', (out) => (0, format_2.fmtPercent)(out.value.appreciationRate, 2)),
                                    o('Appreciation source', (out) => out.value.appreciationSource),
                                ],
                            },
                            {
                                title: 'Projection',
                                nodes: [
                                    o('Projected value', (out) => money(out.value.projectedValue), {
                                        trace: 'projectedValue',
                                        tone: () => 'pass',
                                    }),
                                    o('Projected equity', (out) => money(out.value.projectedEquity), { tone: () => 'pass' }),
                                    o('Equity from the down payment alone', (out) => money2(out.value.equityAtDownPaymentOnly)),
                                    o('Equity difference', (out) => money2(out.value.equityDifference)),
                                    o('Value created per $10,000 renovated', (out) => money2(out.value.valuePer10kRenovated), {
                                        when: renoOn,
                                    }),
                                ],
                            },
                            {
                                title: 'Area data',
                                nodes: [
                                    o('Area', (_out, i) => (0, marketData_4.lookupZip)(i.zipCode).areaLabel || '-'),
                                    o('Typical area value', (_out, i) => money((0, marketData_4.lookupZip)(i.zipCode).typicalValue)),
                                    o('Area annual appreciation', (_out, i) => (0, format_2.fmtPercent)((0, marketData_4.lookupZip)(i.zipCode).appreciation, 2)),
                                    o('Area effective tax rate', (_out, i) => (0, format_2.fmtPercent)((0, marketData_4.lookupZip)(i.zipCode).effectiveTaxRate, 3)),
                                    o('Estimated annual taxes', (_out, i) => money((0, marketData_4.lookupZip)(i.zipCode).estimatedAnnualTaxes)),
                                    o('Estimated annual insurance', (_out, i) => money((0, marketData_4.lookupZip)(i.zipCode).estimatedAnnualInsurance)),
                                    note((out) => out.value.efficiencyNarrative),
                                    note((out) => out.value.equityNarrative),
                                ],
                            },
                        ],
                    },
                ],
            },
        ],
    };
    // ===========================================================================
    // 6. CLOSING COSTS
    // ===========================================================================
    const closingCard = {
        id: 'closing',
        title: 'Closing costs',
        level: 'major',
        collapsible: true,
        defaultCollapsed: true,
        force: (out) => errorsIn(out, 'closing'),
        autoExpand: (out) => out.cash.sellerConcessionApplied > 0,
        summary: (out) => `${money(out.closing.buyerClosingCosts)}${out.cash.sellerConcessionApplied > 0 ? ` - ${money(out.cash.sellerConcessionApplied)} seller credit` : ''}`,
        badge: (_out, i) => ({ text: i.state, cls: 'off' }),
        nodes: [
            note((out) => `Every fee is derived from the ${out.stateRules.state} profile, the purchase price and the loan amount. Leave an override blank to keep the state estimate.`),
            {
                kind: 'columns',
                cols: [
                    {
                        title: 'Lender fees',
                        nodes: [
                            f('closing.originationPointsPct', 'Origination points %', 'percent'),
                            o('Origination points', (out) => money2(out.closing.originationPoints), { trace: 'originationPoints' }),
                            f('closing.overrides.lenderOrigination', 'Origination / underwriting', 'currency'),
                            f('closing.overrides.lenderProcessing', 'Processing / doc prep', 'currency'),
                            f('closing.overrides.appraisal', 'Appraisal', 'currency'),
                            f('closing.overrides.creditReport', 'Credit report', 'currency'),
                            f('closing.overrides.floodTaxService', 'Flood + tax service', 'currency'),
                            f('closing.overrides.inspections', 'Inspections', 'currency'),
                            o('Supplemental origination (financed)', (out) => money2(out.renovationOut.supplementalOrigination), {
                                when: renoOn,
                                tone: () => 'na',
                            }),
                            note('The supplemental origination fee is financed inside the renovation budget, so it is never added again as borrower cash due.', {
                                when: renoOn,
                            }),
                        ],
                    },
                    {
                        title: 'Title & government',
                        nodes: [
                            f('closing.overrides.titleInsurance', 'Title insurance', 'currency'),
                            f('closing.overrides.titleSearchSettlement', 'Title search + settlement', 'currency'),
                            f('closing.overrides.attorney', 'Attorney', 'currency'),
                            f('closing.overrides.survey', 'Survey', 'currency'),
                            f('closing.overrides.recording', 'Recording', 'currency'),
                            f('closing.overrides.other', 'Other buyer costs', 'currency'),
                            f('closing.otherStateMortgageTaxRate', 'Mortgage tax rate %', 'percent', { when: notNy }),
                            o('Mortgage recording tax', (out) => money2(out.closing.mortgageRecordingTax), {
                                trace: 'mortgageRecordingTax',
                            }),
                            heading('New York', { when: isNy }),
                            o('NY mortgage tax', (out) => money2(out.closing.mortgageRecordingTax), {
                                when: isNy,
                                trace: 'mortgageRecordingTax',
                            }),
                            o('Mansion / luxury tax (buyer)', (out) => money2(out.closing.buyerLuxuryTax), {
                                when: isNy,
                                trace: 'luxuryTax',
                            }),
                            o('Transfer tax (seller)', (out) => money2(out.closing.finalSellerTransferTax), {
                                when: isNy,
                                trace: 'sellerTransferTax',
                            }),
                            o('Seller tax increase from the credit', (out) => money2(out.closing.sellerTransferTaxDifference), {
                                when: isNy,
                                tone: () => 'amber',
                            }),
                            note((out) => out.stateRules.closingNote),
                            o('Closing method', (out) => out.stateRules.closingMethod),
                            o('Typical earnest holder', (out) => out.stateRules.earnestHolder),
                            o('Spousal / community property', (out) => out.stateRules.maritalClassification, {
                                when: (_i, out) => Boolean(out.stateRules.maritalClassification),
                            }),
                        ],
                    },
                    {
                        title: 'Prepaids & escrows',
                        nodes: [
                            f('closing.useAggregateEscrowForPrepaids', 'Use the aggregate escrow deposit', 'checkbox', {
                                hint: 'Instead of pickup months - never both',
                            }),
                            f('closing.taxPickupMonths', 'Tax pickup months', 'number', {
                                step: '1',
                                when: (i) => !i.closing.useAggregateEscrowForPrepaids,
                            }),
                            f('closing.insurancePickupMonths', 'Insurance pickup months', 'number', {
                                step: '1',
                                when: (i) => !i.closing.useAggregateEscrowForPrepaids,
                            }),
                            o('Initial escrow deposit', (out) => money2(out.escrowOut.initialEscrowDeposit), {
                                trace: 'escrowInitialDeposit',
                                when: (i) => i.closing.useAggregateEscrowForPrepaids,
                            }),
                            o('Per-diem interest', (out) => `${money2(out.closing.perDiemInterest)} (${out.closing.perDiemDays} days)`, {
                                trace: 'perDiemInterest',
                            }),
                            o('Monthly escrow deposit', (out) => money2(out.escrowOut.monthlyDeposit), {
                                trace: 'escrowMonthlyDeposit',
                            }),
                            o('First payment date', (out) => out.escrowOut.firstPaymentDate),
                            o('First tax disbursement', (out) => out.escrowOut.firstTaxDueDate || 'None scheduled'),
                            o('Next insurance renewal', (out) => out.escrowOut.nextInsuranceDueDate || 'None scheduled'),
                        ],
                    },
                    {
                        title: 'Credits',
                        nodes: [
                            f('closing.earnestMoneyDeposit', 'Earnest money deposit', 'currency'),
                            o('Seller concession applied', (out) => money2(out.cash.sellerConcessionApplied), { tone: () => 'pass' }),
                            o('Maximum allowed', (out) => `${money2(out.purchase.sellerConcessionLimit)} (${(0, format_2.fmtPercent)(out.purchase.sellerConcessionLimitPct, 0)})`, { tone: (out) => (out.purchase.sellerConcessionOverLimit > 0 ? 'bad' : '') }),
                            o('Entered above the limit', (out) => money2(out.purchase.sellerConcessionOverLimit), {
                                when: (_i, out) => out.purchase.sellerConcessionOverLimit > 0,
                                tone: () => 'bad',
                            }),
                            o('Earnest money credited', (out) => money2(out.cash.earnestMoneyDeposit), { tone: () => 'pass' }),
                            f('closing.cushionPct', 'Cushion %', 'percent'),
                            f('closing.roundingIncrement', 'Rounding', 'select', {
                                options: defaults_2.CLOSING_ROUNDING_OPTIONS.map((r) => ({ value: String(r), label: `$${r}` })),
                                onChange: (raw, store) => store.setField('closing.roundingIncrement', Number(raw), 'Closing cost rounding'),
                            }),
                            o('Estimated range with the cushion', (out) => `${money(out.closing.buyerClosingCostsLow)} - ${money(out.closing.buyerClosingCostsHigh)}`, { tone: () => 'pass' }),
                            o('New York comparison', (out) => money(out.closing.estimateNewYork), { when: notNy }),
                            o('Outside New York comparison', (out) => money(out.closing.estimateOutsideNewYork), { when: isNy }),
                        ],
                    },
                ],
            },
            o('ESTIMATED CLOSING COSTS', (out) => money2(out.closing.buyerClosingCosts), {
                trace: 'buyerClosingCosts',
                tone: () => 'final',
            }),
            o('NET BORROWER CLOSING COSTS AFTER CREDITS', (out) => money2(Math.max(0, out.closing.buyerClosingCosts - out.cash.sellerConcessionApplied)), { tone: () => 'final' }),
        ],
        children: [
            {
                id: 'closing-lines',
                title: 'Itemised fee sheet',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: (out) => `${out.closing.lines.filter((l) => l.payer === 'buyer').length} buyer lines`,
                nodes: [
                    {
                        kind: 'table',
                        head: ['Line', 'Amount', 'Basis'],
                        rows: (out) => out.closing.lines
                            .filter((l) => l.payer === 'buyer')
                            .map((l) => {
                            var _a;
                            return [
                                { text: l.label + (l.overridden ? '  (override)' : ''), align: 'l' },
                                { text: money2(l.amount) },
                                { text: (_a = l.basis) !== null && _a !== void 0 ? _a : '', align: 'l', tone: 'muted' },
                            ];
                        }),
                        maxHeight: 360,
                    },
                ],
            },
            {
                id: 'closing-escrow',
                title: 'Aggregate escrow analysis',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: (out) => `${money2(out.escrowOut.monthlyDeposit)}/mo - ${money(out.escrowOut.initialEscrowDeposit)} deposit`,
                nodes: [
                    {
                        kind: 'columns',
                        cols: [
                            {
                                title: 'Setup',
                                nodes: [
                                    f('escrow.annualFlood', 'Annual flood insurance', 'currency'),
                                    f('escrow.autoFirstPaymentDate', 'Derive the first payment date from closing', 'checkbox'),
                                    f('escrow.firstPaymentDate', 'First payment date', 'date', {
                                        when: (i) => !i.escrow.autoFirstPaymentDate,
                                    }),
                                    f('escrow.cushionMonthsOverride', 'Cushion months override (-1 = state rule)', 'number', { step: '1' }),
                                    o('Tax structure', (out) => out.escrowOut.taxSetupNote),
                                    o('Disbursement rule', (out) => out.escrowOut.disbursementScheduleNote),
                                    o('Cushion source', (out) => out.escrowOut.cushionMonthsSource),
                                ],
                            },
                            {
                                title: 'Analysis',
                                nodes: [
                                    o('Annual property taxes', (out) => money2(out.escrowOut.annualTaxes)),
                                    o('Annual homeowners insurance', (out) => money2(out.escrowOut.annualInsurance)),
                                    o('Annual flood insurance', (out) => money2(out.escrowOut.annualFlood), {
                                        when: (i) => i.escrow.annualFlood > 0,
                                    }),
                                    o('Total annual escrowed', (out) => money2(out.escrowOut.totalAnnualEscrowed)),
                                    o('Cushion months', (out) => String(out.escrowOut.cushionMonths)),
                                    o('Required cushion', (out) => money2(out.escrowOut.requiredCushion)),
                                    o('Lowest projected balance', (out) => money2(out.escrowOut.lowestTrialBalance), {
                                        tone: (out) => (out.escrowOut.lowestTrialBalance < 0 ? 'bad' : 'pass'),
                                    }),
                                    o('INITIAL ESCROW DEPOSIT', (out) => money2(out.escrowOut.initialEscrowDeposit), {
                                        trace: 'escrowInitialDeposit',
                                        tone: () => 'final',
                                    }),
                                    note('Monthly FHA MIP and conventional PMI receive no separate escrow cushion.'),
                                ],
                            },
                        ],
                    },
                    {
                        kind: 'table',
                        head: ['Month', 'Due date', 'Deposit', 'Disbursement', 'For', 'Balance'],
                        rows: (out) => out.escrowOut.rows.map((r) => [
                            { text: r.monthLabel, align: 'l' },
                            { text: r.dueDate, align: 'l', tone: 'muted' },
                            { text: money2(r.deposit) },
                            { text: r.disbursements > 0 ? money2(r.disbursements) : '-' },
                            { text: r.disbursementLabels.join(', ') || '-', align: 'l' },
                            { text: money2(r.balance), tone: r.balance < 0 ? 'neg' : 'pos' },
                        ]),
                        maxHeight: 420,
                    },
                ],
            },
        ],
    };
    // ===========================================================================
    // 7. QUALIFICATION & RENTAL
    // ===========================================================================
    const qualifyCard = {
        id: 'qualify',
        title: 'Qualification & rental',
        level: 'major',
        collapsible: true,
        defaultCollapsed: true,
        autoExpand: (_out, i) => incomeEntered(i),
        force: (out) => out.aus.overallDti === 'FAIL',
        summary: (out) => out.aus.totalQualifyingIncome > 0
            ? `${(0, format_2.fmtPercent)(out.aus.backEndDti, 1)} DTI ${out.aus.overallDti === 'PASS' ? '\u2713' : '- ' + out.aus.overallDti}`
            : 'Enter income to test',
        summaryTone: (out) => out.aus.totalQualifyingIncome === 0 ? '' : out.aus.overallDti === 'PASS' ? 'pass' : out.aus.overallDti === 'FAIL' ? 'bad' : 'amber',
        badge: (out) => ({
            text: out.aus.overallDti,
            cls: out.aus.overallDti === 'PASS' ? 'on' : out.aus.overallDti === 'FAIL' ? 'bad' : 'off',
        }),
        nodes: [
            {
                kind: 'import',
                label: 'Import from the income calculator',
                accept: '.json,.csv,.html,.htm,application/json,text/csv,text/html',
                hint: 'Reads the Mortgage Income Calculator handoff (RenovationSuite_Income_*.json), a full save, the worksheet CSV or the exported summary page.',
                run: (text, fileName, store) => {
                    const { result, applied } = store.importIncomeText(text, fileName);
                    const lines = [
                        ...applied.map((a) => `Applied - ${a}`),
                        ...result.notes.map((n) => `Read - ${n}`),
                        ...result.warnings.map((w) => `Note - ${w}`),
                    ];
                    return lines.length ? lines.join('\n') : 'Nothing in that file could be applied.';
                },
                alt: {
                    label: 'Use the calculator open in this browser',
                    run: (store) => {
                        const found = store.readIncomeCalculatorFromBrowser();
                        if (!found) {
                            return 'No income calculator autosave was found in this browser. Open the calculator, switch autosave on, or export a file and use the button on the left.';
                        }
                        const applied = store.importIncome(found);
                        return applied.length
                            ? applied.map((a) => `Applied - ${a}`).join('\n')
                            : 'The calculator file in this browser had nothing to apply.';
                    },
                },
            },
            {
                kind: 'columns',
                cols: [
                    {
                        title: 'Income & liabilities',
                        nodes: [
                            ...[0, 1, 2, 3].flatMap((n) => [
                                heading(`Borrower ${n + 1}`, {
                                    when: (i) => {
                                        var _a, _b, _c, _d;
                                        return n < 2 ||
                                            ((_a = i.borrowers[n]) === null || _a === void 0 ? void 0 : _a.grossMonthlyIncome) > 0 ||
                                            ((_b = i.borrowers[n]) === null || _b === void 0 ? void 0 : _b.otherMonthlyIncome) > 0 ||
                                            ((_c = i.borrowers[n]) === null || _c === void 0 ? void 0 : _c.monthlyDebts) > 0 ||
                                            ((_d = i.borrowers[n - 1]) === null || _d === void 0 ? void 0 : _d.grossMonthlyIncome) > 0;
                                    },
                                }),
                                f(`borrowers.${n}.grossMonthlyIncome`, 'Gross monthly income', 'currency', {
                                    when: (i) => {
                                        var _a, _b, _c, _d;
                                        return n < 2 ||
                                            ((_a = i.borrowers[n]) === null || _a === void 0 ? void 0 : _a.grossMonthlyIncome) > 0 ||
                                            ((_b = i.borrowers[n]) === null || _b === void 0 ? void 0 : _b.otherMonthlyIncome) > 0 ||
                                            ((_c = i.borrowers[n]) === null || _c === void 0 ? void 0 : _c.monthlyDebts) > 0 ||
                                            ((_d = i.borrowers[n - 1]) === null || _d === void 0 ? void 0 : _d.grossMonthlyIncome) > 0;
                                    },
                                }),
                                f(`borrowers.${n}.otherMonthlyIncome`, 'Other monthly income', 'currency', {
                                    when: (i) => {
                                        var _a, _b, _c, _d;
                                        return n < 2 ||
                                            ((_a = i.borrowers[n]) === null || _a === void 0 ? void 0 : _a.grossMonthlyIncome) > 0 ||
                                            ((_b = i.borrowers[n]) === null || _b === void 0 ? void 0 : _b.otherMonthlyIncome) > 0 ||
                                            ((_c = i.borrowers[n]) === null || _c === void 0 ? void 0 : _c.monthlyDebts) > 0 ||
                                            ((_d = i.borrowers[n - 1]) === null || _d === void 0 ? void 0 : _d.grossMonthlyIncome) > 0;
                                    },
                                }),
                                f(`borrowers.${n}.monthlyDebts`, 'Monthly liabilities', 'currency', {
                                    when: (i) => {
                                        var _a, _b, _c, _d;
                                        return n < 2 ||
                                            ((_a = i.borrowers[n]) === null || _a === void 0 ? void 0 : _a.grossMonthlyIncome) > 0 ||
                                            ((_b = i.borrowers[n]) === null || _b === void 0 ? void 0 : _b.otherMonthlyIncome) > 0 ||
                                            ((_c = i.borrowers[n]) === null || _c === void 0 ? void 0 : _c.monthlyDebts) > 0 ||
                                            ((_d = i.borrowers[n - 1]) === null || _d === void 0 ? void 0 : _d.grossMonthlyIncome) > 0;
                                    },
                                }),
                            ]),
                            o('Total borrower income', (out) => money2(out.aus.totalBorrowerIncome), { tone: () => 'pass' }),
                            o('Total monthly liabilities', (out) => money2(out.aus.totalMonthlyLiabilities)),
                        ],
                    },
                    {
                        title: 'DTI test',
                        nodes: [
                            o('Subject housing payment', (out) => money2(out.aus.housingPayment)),
                            o('Rental income used for DTI', (out) => money2(out.aus.rentalIncomeUsedForDti), {
                                when: (i) => anyRentEntered(i),
                            }),
                            o('Total qualifying income', (out) => money2(out.aus.totalQualifyingIncome), {
                                trace: 'totalQualifyingIncome',
                                tone: () => 'pass',
                            }),
                            o('Front-end DTI', (out) => `${(0, format_2.fmtPercent)(out.aus.frontEndDti, 2)} / ${(0, format_2.fmtPercent)(out.aus.frontEndLimit, 0)} target`, {
                                trace: 'frontEndDti',
                                tone: (out) => out.aus.frontEndResult === 'PASS' ? 'pass' : out.aus.frontEndResult === 'FAIL' ? 'bad' : 'na',
                            }),
                            o('Back-end DTI', (out) => `${(0, format_2.fmtPercent)(out.aus.backEndDti, 2)} / ${(0, format_2.fmtPercent)(out.aus.backEndLimit, 0)} target`, {
                                trace: 'backEndDti',
                                tone: (out) => out.aus.backEndResult === 'PASS' ? 'pass' : out.aus.backEndResult === 'FAIL' ? 'bad' : 'na',
                            }),
                            o('OVERALL DTI', (out) => out.aus.overallDti, {
                                tone: (out) => (out.aus.overallDti === 'PASS' ? 'final' : out.aus.overallDti === 'FAIL' ? 'bad' : 'amber'),
                            }),
                            o('Maximum supported housing payment', (out) => money2(out.aus.maxSupportedHousingPayment), {
                                tone: () => 'pass',
                            }),
                            o('Payment cushion / shortfall', (out) => money2(out.aus.paymentCushion), {
                                tone: (out) => (out.aus.paymentCushion >= 0 ? 'pass' : 'bad'),
                            }),
                        ],
                    },
                    {
                        title: 'Assets & reserves',
                        nodes: [
                            f('assets.liquidAssets', 'Liquid assets', 'currency'),
                            f('assets.retirementOtherAssets', 'Retirement / other eligible assets', 'currency'),
                            f('assets.giftFunds', 'Gift funds', 'currency'),
                            o('Total assets including gift', (out) => money2(out.aus.totalAssetsIncludingGift)),
                            o('Gift % of total assets', (out) => (0, format_2.fmtPercent)(out.aus.giftPctOfAssets, 1), {
                                when: (i) => i.assets.giftFunds > 0,
                            }),
                            o('Gift utilisation', (out) => out.aus.giftUtilization, {
                                when: (i) => i.assets.giftFunds > 0,
                                tone: (out) => (out.aus.giftUtilization === 'None' ? 'pass' : 'amber'),
                            }),
                            o('Assets remaining after closing', (out) => money2(out.aus.assetsRemainingAfterClosing)),
                            o('Own-fund reserves after closing', (out) => money2(out.aus.ownFundReservesAfterClosing), {
                                trace: 'reserveCushion',
                            }),
                            o('Required reserves', (out) => `${out.aus.requiredReserveMonths} month(s) - ${money2(out.aus.requiredReserveDollars)}`),
                            o('Reserve months available', (out) => `${(0, format_2.fmtNumber)(out.aus.reserveMonthsAvailable, 2)}x`),
                            o('RESERVE STATUS', (out) => out.aus.reserveStatus, {
                                tone: (out) => (out.aus.reserveCushion >= 0 ? 'pass' : 'bad'),
                            }),
                            note('Gift funds are shown separately and never increase own-fund reserves.'),
                        ],
                    },
                ],
            },
        ],
        children: [
            {
                id: 'rental',
                title: 'Rental income',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                autoExpand: (_out, i) => anyRentEntered(i),
                summary: (out, i) => (anyRentEntered(i) ? money2(out.aus.totalSubjectQualifyingRent) : 'Not used'),
                summaryTone: (_out, i) => (anyRentEntered(i) ? 'pass' : ''),
                nodes: [
                    note('A 1-unit owner-occupied property with no ADU rent has no rental income to count. Enter a rent below to bring the unit fields in.', {
                        when: (i) => !anyRentEntered(i),
                    }),
                    {
                        kind: 'columns',
                        cols: [
                            {
                                title: 'Gross monthly rents',
                                nodes: [
                                    f('rental.mainUnit.gross', 'Main unit rent', 'currency', {
                                        hint: 'Excluded from DTI income; included in the FHA 75% test',
                                    }),
                                    f('rental.adu.gross', 'ADU rent', 'currency'),
                                    f('rental.unit2.gross', '2nd unit rent', 'currency', {
                                        when: (i) => i.units >= 2 || i.rental.unit2.gross > 0,
                                    }),
                                    f('rental.unit3.gross', '3rd unit rent', 'currency', {
                                        when: (i) => i.units >= 3 || i.rental.unit3.gross > 0,
                                    }),
                                    f('rental.unit4.gross', '4th unit rent', 'currency', {
                                        when: (i) => i.units >= 4 || i.rental.unit4.gross > 0,
                                    }),
                                    f('rental.unit2.qualifyingPct', 'Qualifying % (units)', 'percent'),
                                    o('Property type used', (out) => `${out.aus.propertyType} (${out.aus.propertyTypeSource.toLowerCase()})`, {
                                        tone: () => 'pass',
                                    }),
                                ],
                            },
                            {
                                title: 'Net qualifying rent',
                                nodes: [
                                    o('ADU', (out) => money2(out.aus.netQualifyingRent.adu), { when: (i) => i.rental.adu.gross > 0 }),
                                    o('2nd unit', (out) => money2(out.aus.netQualifyingRent.unit2), {
                                        when: (i) => i.rental.unit2.gross > 0,
                                    }),
                                    o('3rd unit', (out) => money2(out.aus.netQualifyingRent.unit3), {
                                        when: (i) => i.rental.unit3.gross > 0,
                                    }),
                                    o('4th unit', (out) => money2(out.aus.netQualifyingRent.unit4), {
                                        when: (i) => i.rental.unit4.gross > 0,
                                    }),
                                    o('TOTAL SUBJECT QUALIFYING RENT', (out) => money2(out.aus.totalSubjectQualifyingRent), {
                                        tone: () => 'pass',
                                    }),
                                    heading('Vacating departure residence', { when: isConv }),
                                    f('rental.includeVacatingRental', 'Include vacating rental?', 'checkbox', { when: isConv }),
                                    f('rental.vacatingGrossRent', 'Vacating gross monthly rent', 'currency', {
                                        when: (i) => isConv(i) && i.rental.includeVacatingRental,
                                    }),
                                    f('rental.vacatingQualifyingPct', 'Vacating qualifying %', 'percent', {
                                        when: (i) => isConv(i) && i.rental.includeVacatingRental,
                                    }),
                                    f('rental.vacatingHousingExpense', 'Current housing expense', 'currency', {
                                        when: (i) => isConv(i) && i.rental.includeVacatingRental,
                                    }),
                                    o('Net adjustment', (out) => money2(out.aus.vacatingNetAdjustment), {
                                        when: (i) => isConv(i) && i.rental.includeVacatingRental,
                                        tone: (out) => (out.aus.vacatingNetAdjustment >= 0 ? 'pass' : 'bad'),
                                    }),
                                    o('Vacating status', (out) => out.aus.vacatingStatus, {
                                        when: (i) => isConv(i) && i.rental.includeVacatingRental,
                                    }),
                                ],
                            },
                            {
                                title: 'FHA self-sufficiency',
                                nodes: [
                                    o('75% test rent', (out) => money2(out.aus.fhaSelfSufficiencyRent), { trace: 'selfSufficiency' }),
                                    o('Exact monthly housing payment', (out) => money2(out.aus.housingPayment)),
                                    o('Cushion / shortfall', (out) => money2(out.aus.selfSufficiencyCushion), {
                                        tone: (out) => !out.aus.selfSufficiencyApplies ? 'na' : out.aus.selfSufficiencyCushion >= 0 ? 'pass' : 'bad',
                                    }),
                                    o('SELF-SUFFICIENCY STATUS', (out) => out.aus.selfSufficiencyStatus, {
                                        tone: (out) => !out.aus.selfSufficiencyApplies ? 'na' : out.aus.selfSufficiencyCushion >= 0 ? 'pass' : 'bad',
                                    }),
                                    note((out) => out.aus.notes),
                                ],
                            },
                        ],
                    },
                ],
            },
        ],
    };
    // ===========================================================================
    // 8. ADVANCED / INTERNAL
    // ===========================================================================
    const advancedCard = {
        id: 'advanced',
        title: 'Advanced / internal',
        level: 'major',
        collapsible: true,
        defaultCollapsed: true,
        force: (out) => out.warnings.some((w) => w.severity === 'error'),
        summary: (out) => {
            const errors = out.warnings.filter((w) => w.severity === 'error').length;
            return errors ? `${errors} blocking warning${errors === 1 ? '' : 's'}` : `AUS ${out.aus.ausPlanningScore}/100`;
        },
        summaryTone: (out) => (out.warnings.some((w) => w.severity === 'error') ? 'bad' : 'pass'),
        nodes: [{ kind: 'warnings' }],
        children: [
            {
                id: 'aus',
                title: 'AUS risk & planning (internal)',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: (out) => `${out.aus.ausPlanningScore}/100 ${out.aus.overallRiskLevel}`,
                summaryTone: (out) => out.aus.overallRiskLevel === 'PASS' ? 'pass' : out.aus.overallRiskLevel === 'HIGH RISK' ? 'amber' : 'bad',
                nodes: [
                    {
                        kind: 'columns',
                        cols: [
                            {
                                title: 'Scorecard',
                                nodes: [
                                    {
                                        kind: 'table',
                                        head: ['Risk factor', 'Result'],
                                        rows: (out) => out.aus.riskFactors.map((r) => [
                                            { text: r.factor, align: 'l' },
                                            { text: r.result, tone: r.result === 'PASS' ? 'pos' : r.result === 'AT RISK' ? 'neg' : '' },
                                        ]),
                                    },
                                    o('Representative credit score', (_out, i) => String(i.creditScore)),
                                    o('Credit tier', (out) => out.payment.creditTier),
                                    o('Current LTV', (out) => (0, format_2.fmtPercent)(out.payment.currentLtv, 2)),
                                    o('AUS PLANNING SCORE', (out) => `${out.aus.ausPlanningScore} / 100`, {
                                        trace: 'ausPlanningScore',
                                        tone: () => 'final',
                                    }),
                                    o('Overall risk level', (out) => out.aus.overallRiskLevel, {
                                        tone: (out) => out.aus.overallRiskLevel === 'PASS'
                                            ? 'pass'
                                            : out.aus.overallRiskLevel === 'HIGH RISK'
                                                ? 'amber'
                                                : 'bad',
                                    }),
                                ],
                            },
                            {
                                title: 'Internal summary',
                                nodes: [
                                    {
                                        kind: 'lines',
                                        get: (i, out) => (0, summary_2.internalSummaryLines)(i, out),
                                        copy: exporters_1.qualificationText,
                                        copyLabel: 'COPY INTERNAL SUMMARY',
                                    },
                                    note('Internal use only. Final rental treatment, self-sufficiency, reserves and approval remain subject to FHA, DU/LPA and lender underwriting.'),
                                ],
                            },
                        ],
                    },
                ],
            },
            {
                id: 'bps',
                title: 'BPS calculator',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: (out) => money2(out.bpsOut.cappedDollars),
                nodes: [
                    {
                        kind: 'columns',
                        cols: [
                            {
                                title: 'Inputs',
                                nodes: [
                                    f('bps.leadSource', 'Lead source', 'select', {
                                        options: opts(['Self Generated', 'Corporate', 'Manual']),
                                    }),
                                    o('Suggested BPS', (out) => (out.bpsOut.suggestedBps ? String(out.bpsOut.suggestedBps) : '-')),
                                    f('bps.bps', 'Input BPS', 'number', {
                                        step: '1',
                                        onChange: (raw, store) => {
                                            const v = raw === '' ? null : Number(raw);
                                            store.setField('bps.bps', v, 'BPS');
                                            store.setField('bps.percent', null, 'BPS percent');
                                            store.setField('bps.dollars', null, 'BPS dollars');
                                        },
                                    }),
                                    f('bps.percent', 'Input percentage %', 'percent', {
                                        onChange: (raw, store) => {
                                            const v = raw === '' ? null : Number(raw) / 100;
                                            store.setField('bps.percent', v, 'BPS percent');
                                            store.setField('bps.bps', null, 'BPS');
                                            store.setField('bps.dollars', null, 'BPS dollars');
                                        },
                                    }),
                                    f('bps.dollars', 'Input dollar amount', 'currency', {
                                        onChange: (raw, store) => {
                                            const v = raw === '' ? null : Number(raw);
                                            store.setField('bps.dollars', v, 'BPS dollars');
                                            store.setField('bps.bps', null, 'BPS');
                                            store.setField('bps.percent', null, 'BPS percent');
                                        },
                                    }),
                                    f('bps.loanAmountOverride', 'Loan amount override', 'currency'),
                                    f('bps.cap', 'Compensation cap', 'currency'),
                                ],
                            },
                            {
                                title: 'Result',
                                nodes: [
                                    o('Linked total loan', (out) => money2(out.loan.totalLoan)),
                                    o('Loan amount used', (out) => money2(out.bpsOut.loanAmountUsed)),
                                    o('Effective BPS', (out) => (0, format_2.fmtNumber)(out.bpsOut.effectiveBps, 2), { tone: () => 'pass' }),
                                    o('Equivalent percentage', (out) => (0, format_2.fmtPercent)(out.bpsOut.percent, 4), { tone: () => 'pass' }),
                                    o('Calculated compensation', (out) => money2(out.bpsOut.dollars), { tone: () => 'pass' }),
                                    o('CAPPED COMPENSATION', (out) => money2(out.bpsOut.cappedDollars), { tone: () => 'final' }),
                                    o('Input used', (out) => out.bpsOut.inputUsed),
                                    note('BPS -> % : BPS / 10,000. % -> BPS : Percentage x 10,000. BPS -> $ : Loan x BPS / 10,000. Capped $ : MIN(Calculated, Cap).'),
                                ],
                            },
                        ],
                    },
                ],
            },
            {
                id: 'reference',
                title: 'Reference data & rule tables',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: () => 'Effective dates & sources',
                nodes: [{ kind: 'reference' }],
            },
        ],
    };
    // ===========================================================================
    // 9. SCENARIO SUMMARY
    // ===========================================================================
    const summaryCard = {
        id: 'summary',
        title: 'Scenario summary',
        level: 'major',
        collapsible: true,
        defaultCollapsed: true,
        summary: (out) => `${money(out.loan.totalLoan)} loan - ${money2(out.payment.totalMonthlyPayment)}/mo`,
        nodes: [
            {
                kind: 'columns',
                cols: [
                    {
                        title: 'Borrower summary',
                        nodes: [
                            {
                                kind: 'lines',
                                get: summary_2.borrowerSummaryLines,
                                copy: exporters_1.borrowerText,
                                copyLabel: 'COPY BORROWER QUOTE',
                                warnings: true,
                                footer: () => 'This is a planning estimate, not a commitment to lend. Final figures are subject to underwriting, appraisal, title, taxes, insurance and final loan terms.',
                            },
                        ],
                    },
                    {
                        title: 'What the borrower should expect',
                        nodes: [
                            o('MONTHLY PAYMENT', (out) => `${money(out.payment.paymentLow)} - ${money(out.payment.paymentHigh)}`, {
                                tone: () => 'final',
                            }),
                            o('CLOSING COSTS', (out) => `${money(out.closing.buyerClosingCostsLow)} - ${money(out.closing.buyerClosingCostsHigh)}`, { tone: () => 'final' }),
                            o('CASH TO CLOSE', (out) => `${money(out.cash.cashToCloseLow)} - ${money(out.cash.cashToCloseHigh)}`, {
                                tone: () => 'final',
                            }),
                            o('Cushion included', (_out, i) => `${(0, format_2.fmtPercent)(i.closing.cushionPct, 0)} on the high estimate`),
                            o('Earnest money already paid', (out) => money(out.cash.earnestMoneyDeposit), {
                                when: (i) => i.closing.earnestMoneyDeposit > 0,
                            }),
                            o('Estimated equity after the renovation', (out) => money(out.value.equityAfterLoan), {
                                tone: () => 'pass',
                            }),
                            o('Projected value', (out) => `${money(out.value.projectedValue)} in ${out.value.projectionYears} years`),
                            {
                                kind: 'actions',
                                buttons: [
                                    { label: 'PRINT / SAVE AS PDF', run: () => window.print() },
                                    {
                                        label: 'EXPORT BORROWER CSV',
                                        run: (s) => {
                                            const i = s.activeInputs;
                                            const out = s.outputs;
                                            void new Promise((resolve_1, reject_1) => { require(["src/ui/exporters"], resolve_1, reject_1); }).then(__importStar).then((m) => m.downloadFile(m.safeFileName(`${i.name}-borrower`, 'csv'), (0, exporters_1.buildBorrowerCsv)(i, out)));
                                        },
                                        variant: 'ghost',
                                    },
                                    {
                                        label: 'EXPORT FULL DATA (CSV)',
                                        run: (s) => {
                                            const i = s.activeInputs;
                                            const out = s.outputs;
                                            void new Promise((resolve_2, reject_2) => { require(["src/ui/exporters"], resolve_2, reject_2); }).then(__importStar).then((m) => m.downloadFile(m.safeFileName(i.name, 'csv'), (0, exporters_1.buildScenarioCsv)(i, out)));
                                        },
                                        variant: 'ghost',
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
        ],
        children: [
            {
                id: 'compare',
                title: 'Saved scenarios, comparison & history',
                level: 'sub',
                collapsible: true,
                defaultCollapsed: true,
                summary: () => 'Save, duplicate, compare',
                nodes: [
                    {
                        kind: 'actions',
                        buttons: [
                            { label: 'NEW SCENARIO', run: (s) => s.newScenario() },
                            { label: 'DUPLICATE', run: (s) => s.duplicateScenario() },
                            { label: 'COMPARE FHA vs CONVENTIONAL', run: (s) => s.compareProgramScenario() },
                            { label: 'SAVE VERSION', run: (s) => s.saveVersion('Manual save'), variant: 'ghost' },
                        ],
                    },
                    { kind: 'scenarios' },
                    note('Scenarios, borrowers and properties are stored in this browser. Export the CSV for a permanent copy.'),
                ],
            },
        ],
    };
    // ===========================================================================
    // THE PERSISTENT SUMMARY RAIL
    // ===========================================================================
    /**
     * Shown beside every tab. Each line knows where its number is produced, so a
     * click takes you to that tab, opens the section and highlights the field.
     */
    exports.RAIL = {
        id: 'rail',
        title: 'Live summary',
        level: 'major',
        badge: (out) => ({ text: out.programLabel, cls: out.isFha ? 'on' : 'off' }),
        nodes: [
            fitStatus,
            heading('Acquisition'),
            o('Purchase price', (out) => money(out.purchase.finalPurchasePrice), {
                goto: { tab: 'setup', section: 'setup', field: 'basePurchasePrice' },
            }),
            o('Renovation', (out) => money(out.renovationOut.finalRenovationAmount), {
                when: renoOn,
                goto: { tab: 'renovation', section: 'renovation', field: 'reno.baseCost' },
            }),
            o('After-repair value', (out) => out.value.afterRepairValue > 0 ? money(out.value.afterRepairValue) : 'Pending appraisal', { goto: { tab: 'setup', section: 'setup', field: 'afterRepairValue' } }),
            o('Required investment', (out) => money2(out.loan.requiredInvestment), {
                goto: { tab: 'maxmortgage', section: 'maxmortgage', field: 'finalDownPaymentPct' },
            }),
            heading('Loan'),
            o('Maximum base loan', (out) => money2(out.loan.maximumBaseLoan), {
                goto: { tab: 'maxmortgage', section: 'maxmortgage' },
            }),
            o('UFMIP', (out) => money2(out.loan.ufmip), {
                when: isFha,
                goto: { tab: 'setup', section: 'setup', field: 'ufmipRate' },
            }),
            o('TOTAL LOAN', (out) => money2(out.loan.totalLoan), {
                tone: () => 'final',
                goto: { tab: 'maxmortgage', section: 'maxmortgage' },
            }),
            heading('Monthly payment'),
            o('Principal & interest', (out) => money2(out.payment.principalAndInterest), {
                goto: { tab: 'setup', section: 'setup', field: 'interestRate' },
            }),
            o('Mortgage insurance', (out) => (out.isFha ? money2(out.payment.monthlyFhaMip) : money2(out.payment.monthlyPmi)), {
                goto: { tab: 'setup', section: 'setup', field: 'fhaAnnualMipRate' },
            }),
            o('Taxes & insurance', (out) => money2(out.payment.monthlyTaxes + out.payment.monthlyInsurance), {
                goto: { tab: 'setup', section: 'setup', field: 'propertyTaxAmount' },
            }),
            o('TOTAL PAYMENT', (out) => money2(out.payment.totalMonthlyPayment), {
                tone: () => 'final',
                goto: { tab: 'quote' },
            }),
            heading('Cash to close'),
            o('Closing costs', (out) => money2(out.closing.buyerClosingCosts), {
                goto: { tab: 'closing', section: 'closing' },
            }),
            o('Less seller credit', (out) => `- ${money2(out.cash.sellerConcessionApplied)}`, {
                when: (_i, out) => out.cash.sellerConcessionApplied > 0,
                tone: () => 'pass',
                goto: { tab: 'setup', section: 'setup', field: 'sellerConcessionPct' },
            }),
            o('Less earnest money', (out) => `- ${money2(out.cash.earnestMoneyDeposit)}`, {
                when: (i) => i.closing.earnestMoneyDeposit > 0,
                tone: () => 'pass',
                goto: { tab: 'setup', section: 'setup', field: 'closing.earnestMoneyDeposit' },
            }),
            o('CASH TO CLOSE', (out) => money2(out.cash.cashToClose), {
                tone: () => 'final hero',
                goto: { tab: 'quote' },
            }),
            heading('Checks'),
            o('DTI', (out) => (out.aus.totalQualifyingIncome > 0 ? `${(0, format_2.fmtPercent)(out.aus.backEndDti, 1)} ${out.aus.overallDti}` : 'Enter income'), {
                tone: (out) => out.aus.totalQualifyingIncome === 0 ? 'na' : out.aus.overallDti === 'PASS' ? 'pass' : 'bad',
                goto: { tab: 'qualify', section: 'qualify', field: 'borrowers.0.grossMonthlyIncome' },
            }),
            o('Reserves', (out) => out.aus.reserveStatus, {
                tone: (out) => (out.aus.reserveCushion >= 0 ? 'pass' : 'bad'),
                goto: { tab: 'qualify', section: 'qualify', field: 'assets.liquidAssets' },
            }),
            o('Blocking warnings', (out) => String(out.warnings.filter((w) => w.severity === 'error').length), {
                tone: (out) => (out.warnings.some((w) => w.severity === 'error') ? 'bad' : 'pass'),
                goto: { tab: 'advanced', section: 'advanced' },
            }),
            note('Click any line to jump to the field that drives it.'),
        ],
    };
    // ===========================================================================
    // TABS
    // ===========================================================================
    const screen = (id, label, blurb, cards, extra = {}) => ({ id, label, short: label, blurb, layout: '1col', columns: [cards], ...extra });
    /** The renovation section, minus its nested draw planner, which gets its own room. */
    const drawPlannerSection = ((_a = renovationCard.children) !== null && _a !== void 0 ? _a : [])[0];
    const mmwDetailSection = ((_b = maxMortgageCard.children) !== null && _b !== void 0 ? _b : [])[0];
    const valueProjectionSection = ((_c = maxMortgageCard.children) !== null && _c !== void 0 ? _c : [])[1];
    const closingLinesSection = ((_d = closingCard.children) !== null && _d !== void 0 ? _d : [])[0];
    const escrowSection = ((_e = closingCard.children) !== null && _e !== void 0 ? _e : [])[1];
    const rentalSection = ((_f = qualifyCard.children) !== null && _f !== void 0 ? _f : [])[0];
    const ausSection = ((_g = advancedCard.children) !== null && _g !== void 0 ? _g : [])[0];
    const bpsSection = ((_h = advancedCard.children) !== null && _h !== void 0 ? _h : [])[1];
    const referenceSection = ((_j = advancedCard.children) !== null && _j !== void 0 ? _j : [])[2];
    const compareSection = ((_k = summaryCard.children) !== null && _k !== void 0 ? _k : [])[0];
    exports.SCREENS = [
        screen('quote', 'QUOTE', '', [controlCenter, quoteCard]),
        screen('setup', 'SETUP', 'Everything that defines the file. These selections control what appears on every other tab.', [{ ...setupCard, collapsible: false, defaultCollapsed: false }]),
        screen('renovation', 'RENOVATION', 'The renovation budget and the draw schedule it feeds.', [{ ...renovationCard, children: [] }, drawPlannerSection], { visible: (_out, i) => i.renovation }),
        screen('maxmortgage', 'MAX MORTGAGE', 'Maximum mortgage, the value tests and the HUD-92700 worksheet.', [
            { ...maxMortgageCard, children: [] },
            mmwDetailSection,
            valueProjectionSection,
        ]),
        screen('closing', 'CLOSING', 'Closing costs by state, price and loan, with the credits that reduce them.', [
            { ...closingCard, children: [] },
            closingLinesSection,
        ]),
        screen('escrow', 'ESCROW', 'Aggregate escrow with due dates driven by the closing date and the state rule.', [
            escrowSection,
        ]),
        screen('qualify', 'QUALIFY', 'Income, liabilities, the DTI test, assets and reserves.', [
            { ...qualifyCard, children: [] },
        ]),
        screen('rental', 'RENTAL', 'Rental income, the qualifying percentages and the FHA self-sufficiency test.', [
            rentalSection,
        ]),
        screen('advanced', 'ADVANCED', 'Internal only: warnings, AUS planning, compensation and the rule tables.', [
            { ...advancedCard, children: [] },
            ausSection,
            bpsSection,
            referenceSection,
        ]),
        screen('scenarios', 'SCENARIOS', 'Save, duplicate, compare and review the history.', [compareSection]),
        screen('summary', 'SUMMARY', 'The page you show the borrower.', [{ ...summaryCard, children: [] }]),
    ];
    function screenFor(mode) {
        var _a;
        return (_a = exports.SCREENS.find((s) => s.id === mode)) !== null && _a !== void 0 ? _a : exports.SCREENS[0];
    }
    /** The tabs that apply to this scenario, in order. */
    function visibleScreens(out, i) {
        return exports.SCREENS.filter((s) => (s.visible ? s.visible(out, i) : true));
    }
    /** Every collapsible section id, for the collapse-all / expand-all actions. */
    exports.SECTION_IDS = (function collect(cards) {
        return cards.flatMap((c) => [
            ...(c.collapsible && c.id ? [c.id] : []),
            ...(c.children ? collect(c.children) : []),
        ]);
    })(exports.SCREENS.flatMap((s) => s.columns.flat()));
    /**
     * Where each traced calculation is produced. The formula drawer uses this to
     * offer "open the inputs behind this".
     */
    exports.TRACE_TARGETS = {
        finalPurchasePrice: { tab: 'setup', section: 'setup', field: 'basePurchasePrice', label: 'Purchase price' },
        sellerConcession: { tab: 'setup', section: 'setup', field: 'sellerConcessionPct', label: 'Seller credit' },
        baseDownPayment: { tab: 'setup', section: 'setup', field: 'baseDownPaymentPct', label: 'Down payment' },
        finalDownPayment: { tab: 'setup', section: 'setup', field: 'finalDownPaymentPct', label: 'Down payment' },
        downPaymentDifference: { tab: 'setup', section: 'setup', field: 'finalDownPaymentPct', label: 'Down payment' },
        finalRenovationAmount: { tab: 'renovation', section: 'renovation', field: 'reno.baseCost', label: 'Renovation budget' },
        contingencyReserve: { tab: 'renovation', section: 'renovation', field: 'reno.contingencyPct', label: 'Contingency' },
        supplementalOrigination: {
            tab: 'renovation',
            section: 'renovation',
            field: 'reno.supplementalOriginationOverride',
            label: 'Supplemental origination',
        },
        drawInspectionFees: { tab: 'renovation', section: 'reno-draws', field: 'draws.inspectionFeePerDraw', label: 'Draw fees' },
        drawTitleFees: { tab: 'renovation', section: 'reno-draws', field: 'draws.titleFeePerDraw', label: 'Draw fees' },
        totalAcquisitionCost: { tab: 'maxmortgage', section: 'maxmortgage', label: 'Acquisition' },
        valueBasis: { tab: 'maxmortgage', section: 'maxmortgage', label: 'Value basis (C3)' },
        minimumStatutoryInvestment: { tab: 'maxmortgage', section: 'maxmortgage', label: 'Statutory investment' },
        requiredInvestment: { tab: 'setup', section: 'setup', field: 'finalDownPaymentPct', label: 'Down payment' },
        baseLoanBeforeLimits: { tab: 'maxmortgage', section: 'maxmortgage', label: 'Base loan' },
        maximumBaseLoan: { tab: 'maxmortgage', section: 'maxmortgage', label: 'Maximum base loan' },
        fhaLimit: { tab: 'setup', section: 'setup', field: 'fhaAreaSelection', label: 'FHA area tier' },
        ufmip: { tab: 'setup', section: 'setup', field: 'ufmipRate', label: 'UFMIP rate' },
        totalLoan: { tab: 'maxmortgage', section: 'maxmortgage', label: 'Total loan' },
        principalAndInterest: { tab: 'setup', section: 'setup', field: 'interestRate', label: 'Rate and term' },
        monthlyFhaMip: { tab: 'setup', section: 'setup', field: 'fhaAnnualMipRate', label: 'MIP rate' },
        monthlyPmi: { tab: 'setup', section: 'setup', field: 'pmiOverrideRate', label: 'PMI rate' },
        totalMonthlyPayment: { tab: 'setup', section: 'setup', field: 'propertyTaxAmount', label: 'Taxes and insurance' },
        paymentRange: { tab: 'setup', section: 'setup', field: 'paymentRoundingIncrement', label: 'Payment rounding' },
        arv110: { tab: 'setup', section: 'setup', field: 'afterRepairValue', label: 'After-repair value' },
        loanSupportedByValue: { tab: 'setup', section: 'setup', field: 'afterRepairValue', label: 'After-repair value' },
        valueCushion: { tab: 'setup', section: 'setup', field: 'afterRepairValue', label: 'After-repair value' },
        minimumAsIsValue: { tab: 'setup', section: 'setup', field: 'asIsValue', label: 'As-is value' },
        minimumArv: { tab: 'setup', section: 'setup', field: 'afterRepairValue', label: 'After-repair value' },
        borrowerEquity: { tab: 'maxmortgage', section: 'maxmortgage', label: 'Equity' },
        projectedValue: { tab: 'maxmortgage', section: 'value-projection', field: 'projection.years', label: 'Projection' },
        originationPoints: { tab: 'closing', section: 'closing', field: 'closing.originationPointsPct', label: 'Points' },
        mortgageRecordingTax: { tab: 'closing', section: 'closing', label: 'Mortgage tax' },
        luxuryTax: { tab: 'closing', section: 'closing', label: 'Mansion tax' },
        sellerTransferTax: { tab: 'closing', section: 'closing', label: 'Transfer tax' },
        perDiemInterest: { tab: 'setup', section: 'setup', field: 'closingDate', label: 'Closing date' },
        buyerClosingCosts: { tab: 'closing', section: 'closing', label: 'Closing costs' },
        cashToClose: { tab: 'closing', section: 'closing', label: 'Cash to close' },
        escrowMonthlyDeposit: { tab: 'escrow', section: 'closing-escrow', field: 'escrow.annualFlood', label: 'Escrow setup' },
        escrowInitialDeposit: { tab: 'escrow', section: 'closing-escrow', label: 'Initial deposit' },
        totalQualifyingIncome: {
            tab: 'qualify',
            section: 'qualify',
            field: 'borrowers.0.grossMonthlyIncome',
            label: 'Income',
        },
        frontEndDti: { tab: 'qualify', section: 'qualify', field: 'borrowers.0.monthlyDebts', label: 'Liabilities' },
        backEndDti: { tab: 'qualify', section: 'qualify', field: 'borrowers.0.monthlyDebts', label: 'Liabilities' },
        reserveCushion: { tab: 'qualify', section: 'qualify', field: 'assets.liquidAssets', label: 'Assets' },
        selfSufficiency: { tab: 'rental', section: 'rental', field: 'rental.mainUnit.gross', label: 'Rents' },
        ausPlanningScore: { tab: 'advanced', section: 'aus', label: 'AUS scorecard' },
    };
});
define("src/core/data/index", ["require", "exports", "src/core/data/fhaLimits", "src/core/data/mortgageInsurance", "src/core/data/transferTaxes", "src/core/data/mortgageRecordingTax", "src/core/data/luxuryTaxes", "src/core/data/stateClosingRules", "src/core/data/escrowRules", "src/core/data/renovationRules", "src/core/data/closingCostProfiles", "src/core/data/marketData", "src/core/data/qualificationRules", "src/core/data/meta", "src/core/data/states", "src/core/data/fhaLimits", "src/core/data/mortgageInsurance", "src/core/data/transferTaxes", "src/core/data/mortgageRecordingTax", "src/core/data/luxuryTaxes", "src/core/data/stateClosingRules", "src/core/data/escrowRules", "src/core/data/renovationRules", "src/core/data/closingCostProfiles", "src/core/data/marketData", "src/core/data/qualificationRules", "src/core/data/concessionLimits"], function (require, exports, fhaLimits_2, mortgageInsurance_2, transferTaxes_4, mortgageRecordingTax_2, luxuryTaxes_2, stateClosingRules_2, escrowRules_3, renovationRules_5, closingCostProfiles_2, marketData_5, qualificationRules_3, meta_1, states_3, fhaLimits_3, mortgageInsurance_3, transferTaxes_5, mortgageRecordingTax_3, luxuryTaxes_3, stateClosingRules_3, escrowRules_4, renovationRules_6, closingCostProfiles_3, marketData_6, qualificationRules_4, concessionLimits_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.REFERENCE_TABLES = void 0;
    exports.getReferenceTable = getReferenceTable;
    __exportStar(meta_1, exports);
    __exportStar(states_3, exports);
    __exportStar(fhaLimits_3, exports);
    __exportStar(mortgageInsurance_3, exports);
    __exportStar(transferTaxes_5, exports);
    __exportStar(mortgageRecordingTax_3, exports);
    __exportStar(luxuryTaxes_3, exports);
    __exportStar(stateClosingRules_3, exports);
    __exportStar(escrowRules_4, exports);
    __exportStar(renovationRules_6, exports);
    __exportStar(closingCostProfiles_3, exports);
    __exportStar(marketData_6, exports);
    __exportStar(qualificationRules_4, exports);
    /** Everything the Reference Data screen can list and edit. */
    exports.REFERENCE_TABLES = [
        fhaLimits_2.FHA_LIMIT_TABLE,
        mortgageInsurance_2.FHA_MIP_TABLE,
        mortgageInsurance_2.PMI_TABLE,
        qualificationRules_3.DTI_LIMITS,
        qualificationRules_3.RESERVE_RULES,
        closingCostProfiles_2.CLOSING_COST_PROFILES,
        transferTaxes_4.TRANSFER_TAX_TABLE,
        mortgageRecordingTax_2.NY_MORTGAGE_TAX_TABLE,
        luxuryTaxes_2.LUXURY_TAX_TABLE,
        stateClosingRules_2.STATE_CLOSING_RULES,
        escrowRules_3.ESCROW_RULES,
        marketData_5.MARKET_TABLE,
        renovationRules_5.DRAW_RULES,
        renovationRules_5.FEE_RULES,
        concessionLimits_2.CONCESSION_LIMIT_TABLE,
    ];
    function getReferenceTable(id) {
        return exports.REFERENCE_TABLES.find((t) => t.id === id);
    }
});
/** Tiny DOM helper used by the standalone (no-framework) build. */
define("src/standalone/dom", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.h = h;
    exports.append = append;
    exports.clear = clear;
    exports.qs = qs;
    function h(tag, attrs = {}, ...children) {
        const el = document.createElement(tag);
        for (const [k, v] of Object.entries(attrs)) {
            if (v === null || v === undefined || v === false)
                continue;
            if (k === 'class')
                el.className = String(v);
            else if (k === 'style')
                el.setAttribute('style', String(v));
            else if (k.startsWith('on') && typeof v === 'function') {
                el.addEventListener(k.slice(2).toLowerCase(), v);
            }
            else if (k === 'value')
                el.value = String(v);
            else if (k === 'checked')
                el.checked = Boolean(v);
            else if (k === 'disabled')
                el.disabled = Boolean(v);
            else
                el.setAttribute(k, String(v));
        }
        append(el, children);
        return el;
    }
    function append(parent, children) {
        for (const c of children) {
            if (c === null || c === undefined || c === false)
                continue;
            parent.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
        }
    }
    function clear(node) {
        if (node.replaceChildren) {
            node.replaceChildren();
            return;
        }
        while (node.firstChild) {
            const child = node.firstChild;
            if (child.parentNode !== node)
                continue;
            node.removeChild(child);
        }
    }
    function qs(sel, root = document) {
        return root.querySelector(sel);
    }
});
define("src/standalone/app", ["require", "exports", "src/core/data/index", "src/core/data/states", "src/ui/sections", "src/ui/format", "src/ui/exporters", "src/standalone/dom"], function (require, exports, index_1, states_4, sections_1, format_3, exporters_2, dom_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.App = void 0;
    class App {
        constructor(root, store) {
            this.refreshers = [];
            this.shellCount = 0;
            this.railCount = 0;
            this.renderedMode = null;
            this.root = root;
            this.store = store;
            this.store.subscribe(() => this.refresh());
            this.build();
        }
        get i() {
            return this.store.activeInputs;
        }
        get o() {
            return this.store.outputs;
        }
        reg(fn) {
            this.refreshers.push(fn);
            fn();
        }
        refresh() {
            document.documentElement.setAttribute('data-theme', this.store.snapshot.theme);
            // A tab change - however it was triggered, including by a jump-to-source
            // click in the summary rail - rebuilds the screen before anything else.
            if ((0, sections_1.screenFor)(this.store.snapshot.mode).id !== this.renderedMode) {
                this.renderScreen();
                return;
            }
            this.refreshers.forEach((fn) => fn());
            if (this.store.pendingFocus)
                this.honourFocus();
        }
        // =========================================================================
        build() {
            (0, dom_1.clear)(this.root);
            const topbar = this.buildTopbar();
            const toolbar = this.buildToolbar();
            const tabs = this.buildTabs();
            this.blurb = (0, dom_1.h)('div', { class: 'blurb no-print' }, '');
            this.main = (0, dom_1.h)('div', { id: 'screen-body' });
            this.rail = (0, dom_1.h)('div', { class: 'rail no-print' });
            const split = (0, dom_1.h)('div', { class: 'cols-main' }, (0, dom_1.h)('div', {}, this.blurb, this.main), this.rail);
            // Toolbar and tabs travel together, so the active tab stays visible while
            // you scroll - which matters once a jump-to-source click has moved you.
            const chrome = (0, dom_1.h)('div', { class: 'chrome no-print' }, toolbar, tabs);
            (0, dom_1.append)(this.root, [topbar, chrome, split, this.legend()]);
            this.shellCount = this.refreshers.length;
            this.rail.appendChild(this.renderCard(sections_1.RAIL));
            this.railCount = this.refreshers.length;
            this.renderScreen();
        }
        /** One tab per screen; the summary is last. */
        buildTabs() {
            const wrap = (0, dom_1.h)('div', { class: 'tabs no-print' });
            const buttons = [];
            for (const sc of sections_1.SCREENS) {
                const b = (0, dom_1.h)('button', {
                    class: 'tab',
                    onclick: () => this.store.setMode(sc.id),
                }, sc.label);
                buttons.push(b);
                wrap.appendChild(b);
            }
            this.reg(() => {
                const shown = (0, sections_1.visibleScreens)(this.o, this.i);
                buttons.forEach((b, idx) => {
                    const sc = sections_1.SCREENS[idx];
                    const visible = shown.includes(sc);
                    b.style.display = visible ? '' : 'none';
                    b.className = `tab${this.store.snapshot.mode === sc.id ? ' active' : ''}`;
                });
                // If the active tab no longer applies, fall back to the quote.
                if (!shown.some((sc) => sc.id === this.store.snapshot.mode))
                    this.store.setMode('quote');
            });
            return wrap;
        }
        /**
         * Honour a pending "take me to this number" request: the tab has already been
         * switched and the section opened, so all that remains is to find the element,
         * scroll it into view and flash it.
         */
        honourFocus() {
            const target = this.store.takeFocus();
            if (!target)
                return;
            window.setTimeout(() => {
                var _a, _b;
                let el = null;
                if (target.field)
                    el = this.main.querySelector(`[data-path="${target.field}"]`);
                if (!el && target.label) {
                    el = (_a = Array.from(this.main.querySelectorAll('[data-out]')).find((x) => x.dataset.out === target.label)) !== null && _a !== void 0 ? _a : null;
                }
                if (!el && target.section)
                    el = this.main.querySelector(`[data-section="${target.section}"]`);
                if (!el)
                    return;
                // Flash the row that holds the field; for a whole-section target, flash
                // its header rather than lighting up the entire card.
                const row = el.closest('.row, .checkrow, .out');
                const flash = row !== null && row !== void 0 ? row : (el.matches('.card') ? (_b = el.querySelector('h3')) !== null && _b !== void 0 ? _b : el : el);
                flash.scrollIntoView({ behavior: 'smooth', block: 'center' });
                flash.classList.remove('flash');
                // restart the animation even when the same element is targeted twice
                void flash.offsetWidth;
                flash.classList.add('flash');
                const input = el.matches('input,select') ? el : el.querySelector('input,select');
                if (input)
                    input.focus({ preventScroll: true });
                window.setTimeout(() => flash.classList.remove('flash'), 2600);
            }, 60);
        }
        /** One toolbar: New/Reset | Save Scenario | Compare | Copy Borrower Quote | Print/PDF | More. */
        buildToolbar() {
            const scenarioPick = (0, dom_1.h)('select', {
                class: 'f pick',
                onchange: (e) => {
                    this.store.selectScenario(e.target.value);
                    this.renderScreen();
                },
            });
            this.reg(() => {
                const list = this.store.scenarioList;
                const active = this.store.snapshot.activeScenarioId;
                scenarioPick.style.display = list.length > 1 ? '' : 'none';
                const signature = list.map((x) => `${x.id}:${x.name}`).join('|');
                if (scenarioPick.dataset.sig !== signature) {
                    (0, dom_1.clear)(scenarioPick);
                    for (const sc of list)
                        scenarioPick.appendChild((0, dom_1.h)('option', { value: sc.id }, sc.name));
                    scenarioPick.dataset.sig = signature;
                }
                if (document.activeElement !== scenarioPick)
                    scenarioPick.value = active;
            });
            const name = (0, dom_1.h)('input', {
                class: 'f namebox',
                value: this.i.name,
                oninput: (e) => this.store.renameScenario(e.target.value),
            });
            this.reg(() => {
                if (document.activeElement !== name)
                    name.value = this.i.name;
            });
            const menu = (label, primary, items) => {
                const list = (0, dom_1.h)('div', { class: 'menu' });
                for (const it of items) {
                    list.appendChild((0, dom_1.h)('button', {
                        class: 'menuitem',
                        onclick: () => {
                            it.run();
                            wrap.classList.remove('open');
                        },
                    }, it.label));
                }
                const btn = (0, dom_1.h)('button', {
                    class: primary ? 'btn primary' : 'btn ghost',
                    onclick: (e) => {
                        e.stopPropagation();
                        const wasOpen = wrap.classList.contains('open');
                        document.querySelectorAll('.menuwrap.open').forEach((x) => x.classList.remove('open'));
                        if (!wasOpen)
                            wrap.classList.add('open');
                    },
                }, `${label} \u25be`);
                const wrap = (0, dom_1.h)('div', { class: 'menuwrap' }, btn, list);
                return wrap;
            };
            document.addEventListener('click', () => {
                document.querySelectorAll('.menuwrap.open').forEach((x) => x.classList.remove('open'));
            });
            return (0, dom_1.h)('div', { class: 'toolbar no-print' }, (0, dom_1.h)('span', { class: 'tlabel' }, 'Scenario'), scenarioPick, name, (0, dom_1.h)('span', { class: 'spacer' }), (0, dom_1.h)('button', { class: 'btn ghost', onclick: () => { this.store.newScenario(); this.renderScreen(); } }, 'New'), (0, dom_1.h)('button', { class: 'btn ghost', onclick: () => this.store.resetDefaults() }, 'Reset'), (0, dom_1.h)('div', { class: 'sep' }), menu('Save scenario', true, [
                { label: 'Save a version', run: () => this.store.saveVersion(`Saved ${new Date().toLocaleString()}`) },
                { label: 'Duplicate this scenario', run: () => { this.store.duplicateScenario(); this.renderScreen(); } },
                { label: 'Save borrower + property', run: () => this.store.captureBorrowerAndProperty() },
            ]), (0, dom_1.h)('button', { class: 'btn ghost', onclick: () => { this.store.compareProgramScenario(); this.renderScreen(); } }, 'Compare'), (0, dom_1.h)('button', {
                class: 'btn ghost',
                onclick: () => this.copyModal('Borrower quote', (0, exporters_2.borrowerText)(this.i, this.o)),
            }, 'Copy borrower quote'), (0, dom_1.h)('button', { class: 'btn ghost', onclick: () => window.print() }, 'Print / PDF'), menu('More', false, [
                { label: 'Export full data (CSV)', run: () => (0, exporters_2.downloadFile)((0, exporters_2.safeFileName)(this.i.name, 'csv'), (0, exporters_2.buildScenarioCsv)(this.i, this.o)) },
                { label: 'Expand every section', run: () => this.store.setSectionsCollapsed(sections_1.SECTION_IDS, false) },
                { label: 'Collapse every section', run: () => this.store.setSectionsCollapsed(sections_1.SECTION_IDS, true) },
                { label: 'Toggle dark mode', run: () => this.store.toggleTheme() },
                { label: 'Clear every value', run: () => this.store.clearAll() },
                { label: 'Reset to the default scenario', run: () => this.store.resetDefaults() },
            ]));
        }
        legend() {
            const sw = (bg, line, label) => (0, dom_1.h)('span', {}, (0, dom_1.h)('i', { class: 'sw', style: `background:${bg};border-color:${line}` }), label);
            return (0, dom_1.h)('div', { class: 'legend no-print' }, sw('var(--input-bg)', 'var(--input-line)', 'Editable input'), sw('var(--calc-bg)', 'var(--calc-line)', 'Calculated'), sw('var(--pass-bg)', 'var(--pass-line)', 'Pass'), sw('var(--final-bg)', 'var(--final-bg)', 'Final result'), sw('var(--warn-bg)', 'var(--warn-line)', 'Warning'), sw('var(--off-bg)', 'var(--off-line)', 'Not applicable'), (0, dom_1.h)('span', { style: 'margin-left:auto' }, 'Click any calculated value to see its formula.'));
        }
        buildTopbar() {
            const prog = (0, dom_1.h)('span', { class: 'prog' }, '');
            this.reg(() => {
                prog.textContent = this.o.programLabel;
            });
            const asOf = (0, dom_1.h)('input', {
                type: 'date',
                value: this.i.asOfDate,
                onchange: (e) => this.store.setField('asOfDate', e.target.value, 'As-of date'),
            });
            const closing = (0, dom_1.h)('input', {
                type: 'date',
                value: this.i.closingDate,
                onchange: (e) => this.store.setField('closingDate', e.target.value, 'Estimated closing date'),
            });
            this.reg(() => {
                if (document.activeElement !== asOf)
                    asOf.value = this.i.asOfDate;
                if (document.activeElement !== closing)
                    closing.value = this.i.closingDate;
            });
            const themeBtn = (0, dom_1.h)('button', {
                class: 'btn ghost icon',
                title: 'Toggle dark mode',
                onclick: () => this.store.toggleTheme(),
            }, '');
            this.reg(() => {
                themeBtn.textContent = this.store.snapshot.theme === 'dark' ? '☀' : '☾';
            });
            return (0, dom_1.h)('div', { class: 'topbar no-print' }, (0, dom_1.h)('span', { class: 'mark' }, 'MS'), (0, dom_1.h)('h1', {}, 'Mortgage Renovation Suite'), prog, (0, dom_1.h)('span', { class: 'spacer' }), (0, dom_1.h)('span', { class: 'datefield' }, 'As of', asOf), (0, dom_1.h)('span', { class: 'datefield' }, 'Closing', closing), themeBtn);
        }
        renderScreen() {
            var _a;
            this.refreshers = this.refreshers.slice(0, this.railCount || this.shellCount);
            (0, dom_1.clear)(this.main);
            const screen = (0, sections_1.screenFor)(this.store.snapshot.mode);
            this.blurb.textContent = screen.blurb;
            this.blurb.style.display = screen.blurb ? '' : 'none';
            const colsClass = screen.layout === '3col'
                ? 'cols'
                : screen.layout === '2col'
                    ? 'cols-2'
                    : screen.layout === 'main'
                        ? 'cols-main'
                        : 'cols-1';
            const grid = (0, dom_1.h)('div', { class: colsClass });
            screen.columns.forEach((column, idx) => {
                // On a `main` screen the last column is the sticky summary rail.
                const isRail = screen.layout === 'main' && idx === screen.columns.length - 1;
                const col = (0, dom_1.h)('div', isRail ? { class: 'rail' } : {});
                for (const card of column)
                    col.appendChild(this.renderCard(card));
                grid.appendChild(col);
            });
            this.main.appendChild(grid);
            this.rail.style.display = screen.hideRail ? 'none' : '';
            if ((_a = screen.bottom) === null || _a === void 0 ? void 0 : _a.length) {
                const bottom = (0, dom_1.h)('div', { class: 'bottom' });
                for (const card of screen.bottom)
                    bottom.appendChild(this.renderCard(card));
                this.main.appendChild(bottom);
            }
            this.renderedMode = screen.id;
            this.refresh();
        }
        // =========================================================================
        // node renderers
        // =========================================================================
        renderCard(card) {
            var _a, _b, _c;
            const level = (_a = card.level) !== null && _a !== void 0 ? _a : 'sub';
            const collapsible = Boolean(card.collapsible && card.id);
            const sectionId = (_b = card.id) !== null && _b !== void 0 ? _b : card.title;
            const chevron = (0, dom_1.h)('span', { class: 'chev' }, '');
            const badge = (0, dom_1.h)('span', { class: 'badge off' }, '');
            const summary = (0, dom_1.h)('span', { class: 'sum' }, '');
            const head = (0, dom_1.h)('h3', {}, collapsible ? chevron : null, (0, dom_1.h)('span', { class: 'ttl' }, card.title), summary, badge);
            const body = (0, dom_1.h)('div', { class: `body${card.grid ? ' gridbody' : ''}` });
            for (const node of card.nodes) {
                const el = this.renderNode(node);
                if (el)
                    body.appendChild(el);
            }
            for (const child of (_c = card.children) !== null && _c !== void 0 ? _c : [])
                body.appendChild(this.renderCard(child));
            const base = `card lvl-${level}${card.grid ? ' grid' : ''}${card.compact ? ' compact' : ''}${collapsible ? ' collapsible' : ''}`;
            const el = (0, dom_1.h)('div', { class: base, 'data-section': sectionId }, head, body);
            if (collapsible) {
                head.addEventListener('click', () => {
                    const now = this.store.isCollapsed(sectionId, Boolean(card.defaultCollapsed), card.autoExpand ? card.autoExpand(this.o, this.i) : false, card.force ? card.force(this.o, this.i) : false);
                    this.store.toggleSection(sectionId, now);
                });
                head.setAttribute('title', 'Click to expand or collapse');
            }
            this.reg(() => {
                // conditional whole sections are removed from the page, never greyed out
                const visible = card.visible ? card.visible(this.o, this.i) : true;
                el.style.display = visible ? '' : 'none';
                if (!visible)
                    return;
                if (card.badge) {
                    const b = card.badge(this.o, this.i);
                    if (b) {
                        badge.textContent = b.text;
                        badge.className = `badge ${b.cls}`;
                        badge.style.display = '';
                    }
                    else
                        badge.style.display = 'none';
                }
                else
                    badge.style.display = 'none';
                let collapsed = false;
                if (collapsible) {
                    collapsed = this.store.isCollapsed(sectionId, Boolean(card.defaultCollapsed), card.autoExpand ? card.autoExpand(this.o, this.i) : false, card.force ? card.force(this.o, this.i) : false);
                    chevron.textContent = collapsed ? '\u203a' : '\u25be';
                    body.style.display = collapsed ? 'none' : '';
                }
                if (card.summary) {
                    summary.textContent = card.summary(this.o, this.i);
                    summary.className = `sum ${card.summaryTone ? card.summaryTone(this.o, this.i) : ''}`;
                    summary.style.display = '';
                }
                else
                    summary.style.display = 'none';
                el.className = `${base}${collapsed ? ' closed' : ''}${card.dim && card.dim(this.o, this.i) ? ' disabled' : ''}`;
            });
            return el;
        }
        renderNode(node) {
            const el = this.renderNodeInner(node);
            if (el && node.when) {
                const when = node.when;
                this.reg(() => {
                    el.style.display = when(this.i, this.o) ? '' : 'none';
                });
            }
            return el;
        }
        renderNodeInner(node) {
            switch (node.kind) {
                case 'field':
                    return this.renderField(node);
                case 'out':
                    return this.renderOut(node);
                case 'note': {
                    const el = (0, dom_1.h)('div', { class: 'note' }, '');
                    this.reg(() => {
                        el.textContent = typeof node.text === 'function' ? node.text(this.o, this.i) : node.text;
                    });
                    return el;
                }
                case 'heading':
                    return (0, dom_1.h)('div', { class: 'sec-head' }, node.text);
                case 'actions': {
                    const wrap = (0, dom_1.h)('div', { class: 'inline no-print' });
                    for (const b of node.buttons) {
                        const btn = (0, dom_1.h)('button', { class: `btn small${b.variant === 'ghost' ? ' ghost' : b.variant === 'warn' ? ' warn' : ''}`, onclick: () => b.run(this.store) }, b.label);
                        wrap.appendChild(btn);
                        if (b.hidden)
                            this.reg(() => {
                                btn.style.display = b.hidden && b.hidden(this.i, this.o) ? 'none' : '';
                            });
                    }
                    return wrap;
                }
                case 'table':
                    return this.renderTable(node);
                case 'lines':
                    return this.renderLines(node);
                case 'warnings':
                    return this.renderWarnings();
                case 'status': {
                    const mark = (0, dom_1.h)('span', { class: 'mk' }, '');
                    const text = (0, dom_1.h)('span', {}, '');
                    const el = (0, dom_1.h)('div', { class: 'statuspill' }, mark, text);
                    this.reg(() => {
                        const tone = node.tone ? node.tone(this.o, this.i) : 'pass';
                        el.className = `statuspill ${tone}`;
                        mark.textContent = tone === 'pass' ? '✓' : tone === 'bad' ? '✕' : tone === 'amber' ? '!' : 'i';
                        text.textContent = node.get(this.o, this.i);
                    });
                    return el;
                }
                case 'reference':
                    return this.renderReference();
                case 'chips': {
                    const strip = (0, dom_1.h)('div', { class: 'strip' });
                    this.reg(() => {
                        (0, dom_1.clear)(strip);
                        node.get(this.o, this.i).forEach((c, idx) => {
                            var _a;
                            if (idx)
                                strip.appendChild((0, dom_1.h)('span', { class: 'dot' }, '\u00b7'));
                            strip.appendChild((0, dom_1.h)('span', { class: `chip ${(_a = c.tone) !== null && _a !== void 0 ? _a : ''}` }, c.text));
                        });
                    });
                    return strip;
                }
                case 'columns': {
                    const wrap = (0, dom_1.h)('div', { class: `colgroup cols-${node.cols.length}` });
                    for (const col of node.cols) {
                        const box = (0, dom_1.h)('div', { class: 'colbox' });
                        if (col.title)
                            box.appendChild((0, dom_1.h)('div', { class: 'coltitle' }, col.title));
                        for (const n of col.nodes) {
                            const child = this.renderNode(n);
                            if (child)
                                box.appendChild(child);
                        }
                        wrap.appendChild(box);
                    }
                    return wrap;
                }
                case 'scenarios':
                    return this.scenarioManager();
                case 'import': {
                    const status = (0, dom_1.h)('div', { class: 'note importstatus' }, '');
                    const show = (text, bad = false) => {
                        (0, dom_1.clear)(status);
                        status.className = `note importstatus${bad ? ' bad' : ' ok'}`;
                        for (const line of text.split('\n'))
                            status.appendChild((0, dom_1.h)('div', {}, line));
                    };
                    const picker = (0, dom_1.h)('input', {
                        type: 'file',
                        accept: node.accept,
                        style: 'display:none',
                        onchange: (e) => {
                            const input = e.target;
                            const file = input.files && input.files[0];
                            if (!file)
                                return;
                            const reader = new FileReader();
                            reader.onload = () => {
                                var _a;
                                try {
                                    show(node.run(String((_a = reader.result) !== null && _a !== void 0 ? _a : ''), file.name, this.store));
                                }
                                catch (err) {
                                    show(`Could not read ${file.name}: ${err.message}`, true);
                                }
                            };
                            reader.onerror = () => show(`Could not read ${file.name}.`, true);
                            reader.readAsText(file);
                            input.value = '';
                        },
                    });
                    const bar = (0, dom_1.h)('div', { class: 'inline no-print' }, (0, dom_1.h)('button', { class: 'btn small', onclick: () => picker.click() }, node.label), node.alt
                        ? (0, dom_1.h)('button', {
                            class: 'btn small ghost',
                            onclick: () => {
                                try {
                                    show(node.alt.run(this.store));
                                }
                                catch (err) {
                                    show(err.message, true);
                                }
                            },
                        }, node.alt.label)
                        : null, picker);
                    return (0, dom_1.h)('div', { class: 'importbox' }, bar, node.hint ? (0, dom_1.h)('div', { class: 'note' }, node.hint) : null, status);
                }
                default:
                    return null;
            }
        }
        renderField(node) {
            var _a, _b;
            const get = () => node.path.split('.').reduce((acc, k) => acc === null || acc === void 0 ? void 0 : acc[k], this.i);
            let input;
            if (node.type === 'select') {
                const sel = (0, dom_1.h)('select', {
                    class: 'f',
                    onchange: (e) => {
                        const raw = e.target.value;
                        if (node.onChange)
                            node.onChange(raw, this.store);
                        else
                            this.store.setField(node.path, raw, node.label);
                    },
                });
                if (typeof node.options !== 'function') {
                    for (const opt of (_a = node.options) !== null && _a !== void 0 ? _a : [])
                        sel.appendChild((0, dom_1.h)('option', { value: opt.value }, opt.label));
                }
                else {
                    const build = node.options;
                    // Option labels that depend on the scenario (for example "Auto (203(k) Standard)")
                    // are rebuilt only when they actually change, so the open dropdown is not disturbed.
                    this.reg(() => {
                        const list = build(this.i, this.o);
                        const sig = list.map((x) => `${x.value}=${x.label}`).join('|');
                        if (sel.dataset.sig === sig)
                            return;
                        const keep = sel.value;
                        (0, dom_1.clear)(sel);
                        for (const opt of list)
                            sel.appendChild((0, dom_1.h)('option', { value: opt.value }, opt.label));
                        sel.dataset.sig = sig;
                        sel.value = keep;
                    });
                }
                input = sel;
            }
            else if (node.type === 'checkbox') {
                input = (0, dom_1.h)('input', {
                    type: 'checkbox',
                    onchange: (e) => this.store.setField(node.path, e.target.checked, node.label),
                });
            }
            else {
                input = (0, dom_1.h)('input', {
                    class: `f${node.type === 'text' || node.type === 'date' ? ' text' : ''}`,
                    type: node.type === 'date' ? 'date' : node.type === 'text' ? 'text' : 'number',
                    step: (_b = node.step) !== null && _b !== void 0 ? _b : (node.type === 'percent' ? '0.001' : node.type === 'currency' ? '100' : '1'),
                    oninput: (e) => {
                        const raw = e.target.value;
                        if (node.onChange)
                            node.onChange(raw, this.store);
                        else if (raw === '' && node.path.includes('.overrides.')) {
                            this.store.setField(node.path, null, node.label);
                        }
                        else
                            this.store.setField(node.path, (0, format_3.parseFieldValue)(node.type, raw), node.label);
                    },
                });
            }
            const label = (0, dom_1.h)('label', {}, node.label, node.hint ? (0, dom_1.h)('span', { class: 'sub' }, node.hint) : null);
            input.setAttribute('data-path', node.path);
            const row = (0, dom_1.h)('div', { class: node.type === 'checkbox' ? 'checkrow' : 'row', 'data-field': node.path }, ...(node.type === 'checkbox' ? [input, label] : [label, input]));
            this.reg(() => {
                const value = get();
                const disabled = node.disabled ? node.disabled(this.i, this.o) : false;
                input.disabled = disabled;
                row.className = `${node.type === 'checkbox' ? 'checkrow' : 'row'}${disabled ? ' disabled' : ''}`;
                if (document.activeElement === input)
                    return;
                if (node.type === 'checkbox')
                    input.checked = Boolean(value);
                else if (node.type === 'select') {
                    input.value = typeof value === 'boolean' ? (value ? 'yes' : 'no') : String(value);
                }
                else
                    input.value = (0, format_3.toInputValue)(node.type, value);
            });
            return row;
        }
        renderOut(node) {
            const v = (0, dom_1.h)('div', { class: 'v' }, '');
            const el = (0, dom_1.h)('div', { class: 'out', 'data-out': node.label }, (0, dom_1.h)('div', { class: 'l' }, node.label), v);
            if (node.goto) {
                // A summary line: take me to the field that drives this number.
                el.classList.add('jump');
                el.addEventListener('click', () => this.store.navigate(node.goto));
                el.setAttribute('title', 'Click to open the field behind this number');
            }
            else if (node.trace) {
                el.addEventListener('click', () => this.showTrace(node.trace));
                el.setAttribute('title', 'Click to see the formula');
            }
            this.reg(() => {
                v.textContent = node.get(this.o, this.i);
                el.className = `out ${node.tone ? node.tone(this.o, this.i) : ''}`;
            });
            return el;
        }
        renderTable(node) {
            const table = (0, dom_1.h)('table', { class: 'grid' });
            const wrap = (0, dom_1.h)('div', {
                class: 'scroll',
                style: node.maxHeight ? `max-height:${node.maxHeight}px` : '',
            }, table);
            this.reg(() => {
                (0, dom_1.clear)(table);
                const thead = (0, dom_1.h)('thead', {});
                thead.appendChild((0, dom_1.h)('tr', {}, ...node.head.map((t, idx) => (0, dom_1.h)('th', { class: idx === 0 ? 'l' : '' }, t))));
                table.appendChild(thead);
                const tbody = (0, dom_1.h)('tbody', {});
                for (const row of node.rows(this.o, this.i)) {
                    tbody.appendChild((0, dom_1.h)('tr', {}, ...row.map((c) => { var _a; return (0, dom_1.h)('td', { class: `${c.align === 'l' ? 'l ' : ''}${(_a = c.tone) !== null && _a !== void 0 ? _a : ''}` }, c.text); })));
                }
                table.appendChild(tbody);
            });
            return wrap;
        }
        renderLines(node) {
            var _a;
            const box = (0, dom_1.h)('div', { class: 'summary' });
            const bar = (0, dom_1.h)('div', { class: 'inline no-print' });
            if (node.copy) {
                bar.appendChild((0, dom_1.h)('button', { class: 'btn small', onclick: () => { var _a; return this.copyModal((_a = node.copyLabel) !== null && _a !== void 0 ? _a : 'Copy', node.copy(this.i, this.o)); } }, (_a = node.copyLabel) !== null && _a !== void 0 ? _a : 'COPY'));
                bar.appendChild((0, dom_1.h)('button', { class: 'btn small ghost', onclick: () => window.print() }, 'PRINT / PDF'));
            }
            this.reg(() => {
                (0, dom_1.clear)(box);
                for (const line of node.get(this.i, this.o)) {
                    box.appendChild((0, dom_1.h)('div', { class: `line${line.emphasis ? ' em' : ''}` }, (0, dom_1.h)('span', {}, line.label), (0, dom_1.h)('span', {}, line.value)));
                }
                if (node.warnings) {
                    const warns = this.o.warnings.filter((w) => w.severity === 'error');
                    if (warns.length) {
                        box.appendChild((0, dom_1.h)('div', { class: 'warn error', style: 'margin-top:12px' }, (0, dom_1.h)('b', {}, 'Please note'), ...warns.map((w) => (0, dom_1.h)('div', {}, `- ${w.title}: ${w.detail}`))));
                    }
                }
                if (node.footer)
                    box.appendChild((0, dom_1.h)('div', { class: 'disclaim' }, node.footer(this.i, this.o)));
            });
            return (0, dom_1.h)('div', {}, bar, box);
        }
        renderWarnings() {
            const list = (0, dom_1.h)('div', { class: 'warns' });
            this.reg(() => {
                (0, dom_1.clear)(list);
                const order = { error: 0, warning: 1, info: 2 };
                const ws = [...this.o.warnings].sort((a, b) => order[a.severity] - order[b.severity]);
                if (!ws.length) {
                    list.appendChild((0, dom_1.h)('div', { class: 'warn info' }, (0, dom_1.h)('b', {}, 'No warnings'), 'Every check passed.'));
                    return;
                }
                for (const w of ws)
                    list.appendChild(this.warningEl(w));
            });
            return list;
        }
        warningEl(w) {
            return (0, dom_1.h)('div', { class: `warn ${w.severity}` }, (0, dom_1.h)('span', { class: 'mod' }, w.module), (0, dom_1.h)('b', {}, w.title), w.detail);
        }
        renderReference() {
            const wrap = (0, dom_1.h)('div', {});
            for (const table of index_1.REFERENCE_TABLES) {
                const grid = (0, dom_1.h)('table', { class: 'grid' });
                grid.appendChild((0, dom_1.h)('thead', {}, (0, dom_1.h)('tr', {}, ...table.columns.map((c) => (0, dom_1.h)('th', { class: 'l' }, c.label)))));
                const tbody = (0, dom_1.h)('tbody', {});
                for (const row of table.rows.slice(0, 200)) {
                    const tr = (0, dom_1.h)('tr', {});
                    for (const col of table.columns) {
                        const raw = row[col.key];
                        const editable = table.meta.overrideAllowed && ['currency', 'percent', 'number'].includes(col.type);
                        const td = (0, dom_1.h)('td', { class: col.type === 'text' || col.type === 'boolean' ? 'l' : '' });
                        if (editable) {
                            td.appendChild((0, dom_1.h)('input', {
                                class: 'f',
                                style: 'padding:3px 6px',
                                type: 'number',
                                step: col.type === 'percent' ? '0.001' : '1',
                                value: col.type === 'percent' ? String(Number(raw !== null && raw !== void 0 ? raw : 0) * 100) : String(Number(raw !== null && raw !== void 0 ? raw : 0)),
                                onchange: (e) => {
                                    const v = Number(e.target.value);
                                    row[col.key] = col.type === 'percent' ? v / 100 : v;
                                    this.refresh();
                                },
                            }));
                        }
                        else {
                            td.textContent =
                                col.type === 'currency'
                                    ? (0, format_3.fmtCurrency)(Number(raw))
                                    : col.type === 'percent'
                                        ? raw === null
                                            ? 'None'
                                            : (0, format_3.fmtPercent)(Number(raw))
                                        : col.type === 'boolean'
                                            ? raw
                                                ? 'Yes'
                                                : 'No'
                                            : String(raw !== null && raw !== void 0 ? raw : '');
                        }
                        tr.appendChild(td);
                    }
                    tbody.appendChild(tr);
                }
                grid.appendChild(tbody);
                wrap.appendChild((0, dom_1.h)('div', { class: 'card' }, (0, dom_1.h)('h3', {}, table.title), (0, dom_1.h)('div', { class: 'body' }, (0, dom_1.h)('div', { class: 'note' }, table.description), (0, dom_1.h)('div', { class: 'inline', style: 'margin-top:8px' }, (0, dom_1.h)('span', { class: 'pill info' }, `Effective ${table.meta.effectiveDate}`), (0, dom_1.h)('span', { class: 'pill info' }, `Reviewed ${table.meta.lastReviewed}`), (0, dom_1.h)('span', { class: 'pill' }, table.meta.confidence), table.meta.sourceUrl
                    ? (0, dom_1.h)('a', { class: 'pill', href: table.meta.sourceUrl, target: '_blank', rel: 'noreferrer' }, table.meta.sourceName)
                    : (0, dom_1.h)('span', { class: 'pill' }, table.meta.sourceName)), table.meta.notes ? (0, dom_1.h)('div', { class: 'note' }, table.meta.notes) : null, (0, dom_1.h)('div', { class: 'scroll', style: 'margin-top:10px' }, grid), table.rows.length > 200
                    ? (0, dom_1.h)('div', { class: 'note' }, `Showing the first 200 of ${table.rows.length} rows.`)
                    : null)));
            }
            return wrap;
        }
        // =========================================================================
        // scenario manager (list + comparison + borrowers + properties)
        // =========================================================================
        scenarioManager() {
            const list = (0, dom_1.h)('div', {});
            this.reg(() => {
                (0, dom_1.clear)(list);
                for (const s of this.store.scenarioList) {
                    const active = s.id === this.store.snapshot.activeScenarioId;
                    list.appendChild((0, dom_1.h)('div', { class: 'rowitem' }, (0, dom_1.h)('input', {
                        type: 'checkbox',
                        checked: this.store.snapshot.compareIds.includes(s.id),
                        onchange: () => this.store.toggleCompare(s.id),
                    }), (0, dom_1.h)('b', { style: active ? 'color:var(--pass-ink)' : '' }, s.name), (0, dom_1.h)('span', { class: 'sub' }, new Date(s.updatedAt).toLocaleString()), (0, dom_1.h)('span', { style: 'flex:1' }), (0, dom_1.h)('button', { class: 'btn small', onclick: () => { this.store.selectScenario(s.id); this.renderScreen(); } }, 'Open'), (0, dom_1.h)('button', { class: 'btn small warn', onclick: () => this.store.deleteScenario(s.id) }, 'Delete')));
                }
            });
            const compare = (0, dom_1.h)('div', { class: 'scroll' });
            this.reg(() => {
                (0, dom_1.clear)(compare);
                const ids = this.store.snapshot.compareIds.length
                    ? this.store.snapshot.compareIds
                    : [this.store.snapshot.activeScenarioId];
                const cols = ids
                    .map((id) => { var _a, _b; return ({ id, name: (_b = (_a = this.store.snapshot.scenarios[id]) === null || _a === void 0 ? void 0 : _a.inputs.name) !== null && _b !== void 0 ? _b : '', out: this.store.outputsFor(id) }); })
                    .filter((c) => c.out);
                const rows = [
                    ['Program', (o) => o.programLabel],
                    ['Property type', (o) => o.aus.propertyType],
                    ['Purchase price', (o) => (0, format_3.fmtCurrency)(o.purchase.finalPurchasePrice)],
                    ['Renovation budget', (o) => (0, format_3.fmtCurrency)(o.renovationOut.finalRenovationAmount)],
                    ['Interest rate / term', (_o, id) => {
                            const inp = this.store.snapshot.scenarios[id].inputs;
                            return `${(0, format_3.fmtPercent)(inp.interestRate)} / ${inp.termYears}y`;
                        }],
                    ['Down payment', (o) => (0, format_3.fmtCurrency)(o.loan.requiredInvestment)],
                    ['Base loan', (o) => (0, format_3.fmtCurrency)(o.loan.maximumBaseLoan)],
                    ['Total loan', (o) => (0, format_3.fmtCurrency)(o.loan.totalLoan)],
                    ['Monthly payment', (o) => (0, format_3.fmtCurrency)(o.payment.totalMonthlyPayment, 2)],
                    ['Payment range', (o) => `${(0, format_3.fmtCurrency)(o.payment.paymentLow)} - ${(0, format_3.fmtCurrency)(o.payment.paymentHigh)}`],
                    ['Mortgage insurance', (o) => (o.isFha ? `MIP ${(0, format_3.fmtCurrency)(o.payment.monthlyFhaMip, 2)}` : `PMI ${(0, format_3.fmtCurrency)(o.payment.monthlyPmi, 2)}`)],
                    ['Closing costs', (o) => (0, format_3.fmtCurrency)(o.closing.buyerClosingCosts)],
                    ['Cash to close', (o) => (0, format_3.fmtCurrency)(o.cash.cashToClose)],
                    ['Minimum ARV needed', (o) => (0, format_3.fmtCurrency)(o.value.minimumArvNeeded)],
                    ['Borrower equity', (o) => (0, format_3.fmtCurrency)(o.value.equityAfterLoan)],
                    ['Front / back DTI', (o) => `${(0, format_3.fmtPercent)(o.aus.frontEndDti, 1)} / ${(0, format_3.fmtPercent)(o.aus.backEndDti, 1)}`],
                    ['Reserves', (o) => o.aus.reserveStatus],
                    ['AUS risk', (o) => `${o.aus.ausPlanningScore}/100 ${o.aus.overallRiskLevel}`],
                    ['Blocking warnings', (o) => String(o.warnings.filter((w) => w.severity === 'error').length)],
                ];
                const t = (0, dom_1.h)('table', { class: 'grid' });
                t.appendChild((0, dom_1.h)('thead', {}, (0, dom_1.h)('tr', {}, (0, dom_1.h)('th', { class: 'l' }, 'Metric'), ...cols.map((c) => (0, dom_1.h)('th', {}, c.name)))));
                const tb = (0, dom_1.h)('tbody', {});
                for (const [label, get] of rows) {
                    const values = cols.map((c) => get(c.out, c.id));
                    const differs = new Set(values).size > 1;
                    tb.appendChild((0, dom_1.h)('tr', {}, (0, dom_1.h)('td', { class: 'l' }, label), ...values.map((v) => (0, dom_1.h)('td', { style: differs ? 'background:var(--amber-bg);font-weight:700' : '' }, v))));
                }
                t.appendChild(tb);
                compare.appendChild(t);
            });
            return (0, dom_1.h)('div', {}, (0, dom_1.h)('div', { class: 'cols-2' }, (0, dom_1.h)('div', {}, (0, dom_1.h)('div', { class: 'card' }, (0, dom_1.h)('h3', {}, 'Saved scenarios'), (0, dom_1.h)('div', { class: 'body' }, list))), (0, dom_1.h)('div', {}, this.borrowerCard(), this.propertyCard())), (0, dom_1.h)('div', { class: 'card' }, (0, dom_1.h)('h3', {}, 'Scenario comparison'), (0, dom_1.h)('div', { class: 'body' }, compare)), this.versionCard());
        }
        borrowerCard() {
            const list = (0, dom_1.h)('div', {});
            const name = (0, dom_1.h)('input', { placeholder: 'Borrower name' });
            const email = (0, dom_1.h)('input', { placeholder: 'Email' });
            const phone = (0, dom_1.h)('input', { placeholder: 'Phone', style: 'width:120px' });
            const score = (0, dom_1.h)('input', { type: 'number', placeholder: 'Score', style: 'width:90px' });
            this.reg(() => {
                (0, dom_1.clear)(list);
                const bs = this.store.snapshot.borrowers;
                if (!bs.length)
                    list.appendChild((0, dom_1.h)('div', { class: 'note' }, 'No saved borrowers yet.'));
                for (const b of bs) {
                    list.appendChild((0, dom_1.h)('div', { class: 'rowitem' }, (0, dom_1.h)('b', {}, b.name), (0, dom_1.h)('span', { class: 'sub' }, `${b.creditScore || '-'} ${b.email}`), (0, dom_1.h)('span', { style: 'flex:1' }), (0, dom_1.h)('button', { class: 'btn small', onclick: () => this.store.applyBorrower(b.id) }, 'Use'), (0, dom_1.h)('button', { class: 'btn small warn', onclick: () => this.store.deleteBorrower(b.id) }, 'x')));
                }
            });
            return (0, dom_1.h)('div', { class: 'card' }, (0, dom_1.h)('h3', {}, 'Saved borrowers'), (0, dom_1.h)('div', { class: 'body' }, (0, dom_1.h)('div', { class: 'inline' }, name, email, phone, score, (0, dom_1.h)('button', {
                class: 'btn small',
                onclick: () => {
                    if (!name.value)
                        return;
                    this.store.saveBorrower({ name: name.value, email: email.value, phone: phone.value, creditScore: Number(score.value) || 0, note: '' });
                    name.value = '';
                    email.value = '';
                    phone.value = '';
                    score.value = '';
                },
            }, 'SAVE')), list));
        }
        propertyCard() {
            const list = (0, dom_1.h)('div', {});
            const addr = (0, dom_1.h)('input', { placeholder: 'Address' });
            const zip = (0, dom_1.h)('input', { placeholder: 'ZIP', style: 'width:80px' });
            const st = (0, dom_1.h)('select', {}, ...states_4.US_STATES.map((s) => (0, dom_1.h)('option', { value: s }, s)));
            const taxes = (0, dom_1.h)('input', { type: 'number', placeholder: 'Annual taxes', style: 'width:120px' });
            this.reg(() => {
                (0, dom_1.clear)(list);
                const ps = this.store.snapshot.properties;
                if (!ps.length)
                    list.appendChild((0, dom_1.h)('div', { class: 'note' }, 'No saved properties yet.'));
                for (const p of ps) {
                    list.appendChild((0, dom_1.h)('div', { class: 'rowitem' }, (0, dom_1.h)('b', {}, p.address), (0, dom_1.h)('span', { class: 'sub' }, `${p.state} ${p.county} ${p.zipCode}`), (0, dom_1.h)('span', { style: 'flex:1' }), (0, dom_1.h)('button', { class: 'btn small', onclick: () => this.store.applyProperty(p.id) }, 'Use'), (0, dom_1.h)('button', { class: 'btn small warn', onclick: () => this.store.deleteProperty(p.id) }, 'x')));
                }
            });
            return (0, dom_1.h)('div', { class: 'card' }, (0, dom_1.h)('h3', {}, 'Saved properties'), (0, dom_1.h)('div', { class: 'body' }, (0, dom_1.h)('div', { class: 'inline' }, addr, zip, st, taxes, (0, dom_1.h)('button', {
                class: 'btn small',
                onclick: () => {
                    if (!addr.value)
                        return;
                    this.store.saveProperty({
                        address: addr.value, zipCode: zip.value, state: st.value, county: '',
                        units: 1, annualTaxes: Number(taxes.value) || 0, annualInsurance: 0, note: '',
                    });
                    addr.value = '';
                    zip.value = '';
                    taxes.value = '';
                },
            }, 'SAVE')), list, (0, dom_1.h)('div', { class: 'inline', style: 'margin-top:8px' }, (0, dom_1.h)('button', { class: 'btn small ghost', onclick: () => this.store.captureBorrowerAndProperty() }, 'Save from the current scenario'))));
        }
        versionCard() {
            const versions = (0, dom_1.h)('div', {});
            const audit = (0, dom_1.h)('div', { class: 'scroll', style: 'max-height:260px' });
            this.reg(() => {
                (0, dom_1.clear)(versions);
                const vs = this.store.active.versions;
                if (!vs.length)
                    versions.appendChild((0, dom_1.h)('div', { class: 'note' }, 'No versions saved yet.'));
                for (const v of vs) {
                    versions.appendChild((0, dom_1.h)('div', { class: 'rowitem' }, (0, dom_1.h)('span', { class: 'n' }, String(v.version)), (0, dom_1.h)('span', {}, `${v.label} - ${new Date(v.timestamp).toLocaleString()}`), (0, dom_1.h)('span', { style: 'flex:1' }), (0, dom_1.h)('button', { class: 'btn small', onclick: () => this.store.restoreVersion(v.version) }, 'Restore')));
                }
                (0, dom_1.clear)(audit);
                const t = (0, dom_1.h)('table', { class: 'grid' });
                t.appendChild((0, dom_1.h)('thead', {}, (0, dom_1.h)('tr', {}, (0, dom_1.h)('th', { class: 'l' }, 'When'), (0, dom_1.h)('th', { class: 'l' }, 'User'), (0, dom_1.h)('th', { class: 'l' }, 'Action'), (0, dom_1.h)('th', { class: 'l' }, 'Detail'))));
                const tb = (0, dom_1.h)('tbody', {});
                for (const a of this.store.active.audit.slice(0, 50)) {
                    tb.appendChild((0, dom_1.h)('tr', {}, (0, dom_1.h)('td', { class: 'l muted' }, new Date(a.timestamp).toLocaleString()), (0, dom_1.h)('td', { class: 'l' }, a.user), (0, dom_1.h)('td', { class: 'l' }, a.action), (0, dom_1.h)('td', { class: 'l muted' }, a.field ? `${a.field}: ${a.from} -> ${a.to}` : '')));
                }
                t.appendChild(tb);
                audit.appendChild(t);
            });
            return (0, dom_1.h)('div', { class: 'cols-2' }, (0, dom_1.h)('div', {}, (0, dom_1.h)('div', { class: 'card' }, (0, dom_1.h)('h3', {}, 'Version history'), (0, dom_1.h)('div', { class: 'body' }, (0, dom_1.h)('div', { class: 'inline' }, (0, dom_1.h)('button', { class: 'btn small', onclick: () => this.store.saveVersion(`Saved ${new Date().toLocaleString()}`) }, 'SAVE VERSION')), versions))), (0, dom_1.h)('div', {}, (0, dom_1.h)('div', { class: 'card' }, (0, dom_1.h)('h3', {}, 'Audit trail'), (0, dom_1.h)('div', { class: 'body' }, audit))));
        }
        // =========================================================================
        // modals
        // =========================================================================
        showTrace(key) {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
            const t = this.o.traces[key];
            if (!t)
                return;
            const fmt = (v, f) => f === 'currency'
                ? (0, format_3.fmtCurrency)(Number(v), 2)
                : f === 'percent'
                    ? (0, format_3.fmtPercent)(Number(v))
                    : f === 'number'
                        ? (0, format_3.fmtNumber)(Number(v), 0)
                        : String(v);
            const headStyle = 'margin:16px 0 6px;font-size:10.5px;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);font-weight:700';
            const body = (0, dom_1.h)('div', { class: 'content' }, (0, dom_1.h)('div', { class: 'formula' }, t.formula), (0, dom_1.h)('h4', { style: headStyle }, 'Inputs used'), ...t.inputs.map((inp) => (0, dom_1.h)('div', { class: 'kv' }, (0, dom_1.h)('span', {}, inp.label), (0, dom_1.h)('b', {}, fmt(inp.value, inp.format)))), (0, dom_1.h)('h4', { style: headStyle }, 'Result'), (0, dom_1.h)('div', { class: 'kv' }, (0, dom_1.h)('span', {}, t.label), (0, dom_1.h)('b', { style: 'font-size:17px;color:var(--pass-ink)' }, fmt(t.result, (_a = t.resultFormat) !== null && _a !== void 0 ? _a : 'currency'))), ((_c = (_b = t.limitsApplied) === null || _b === void 0 ? void 0 : _b.length) !== null && _c !== void 0 ? _c : 0) > 0
                ? (0, dom_1.h)('div', { style: 'margin-top:14px' }, (0, dom_1.h)('b', { style: 'font-size:12px' }, 'Limits applied: '), ...((_d = t.limitsApplied) !== null && _d !== void 0 ? _d : []).map((x) => (0, dom_1.h)('span', { class: 'pill limit' }, x)))
                : null, ((_f = (_e = t.overridesApplied) === null || _e === void 0 ? void 0 : _e.length) !== null && _f !== void 0 ? _f : 0) > 0
                ? (0, dom_1.h)('div', { style: 'margin-top:8px' }, (0, dom_1.h)('b', { style: 'font-size:12px' }, 'Overrides: '), ...((_g = t.overridesApplied) !== null && _g !== void 0 ? _g : []).map((x) => (0, dom_1.h)('span', { class: 'pill' }, x)))
                : null, ((_j = (_h = t.notes) === null || _h === void 0 ? void 0 : _h.length) !== null && _j !== void 0 ? _j : 0) > 0
                ? (0, dom_1.h)('div', { class: 'note', style: 'margin-top:14px' }, ...((_k = t.notes) !== null && _k !== void 0 ? _k : []).map((n) => (0, dom_1.h)('div', {}, n)))
                : null, sections_1.TRACE_TARGETS[key]
                ? (0, dom_1.h)('div', { class: 'inline', style: 'margin-top:16px' }, (0, dom_1.h)('button', {
                    class: 'btn',
                    onclick: () => {
                        document.querySelectorAll('.modal-bg').forEach((x) => x.remove());
                        this.store.navigate(sections_1.TRACE_TARGETS[key]);
                    },
                }, `Open ${(_l = sections_1.TRACE_TARGETS[key].label) !== null && _l !== void 0 ? _l : 'the inputs'} \u2192`))
                : null);
            this.modal(t.label, body);
        }
        copyModal(title, text) {
            const ta = (0, dom_1.h)('textarea', { class: 'copy' }, text);
            const done = (0, dom_1.h)('div', { class: 'note' }, '');
            const btn = (0, dom_1.h)('button', {
                class: 'btn',
                onclick: () => {
                    ta.select();
                    try {
                        if (navigator.clipboard)
                            void navigator.clipboard.writeText(text);
                        else
                            document.execCommand('copy');
                        done.textContent = 'Copied to the clipboard.';
                    }
                    catch {
                        done.textContent = 'Copy blocked by the browser - select the text above and copy manually.';
                    }
                },
            }, 'Copy to clipboard');
            this.modal(title, (0, dom_1.h)('div', { class: 'content' }, ta, (0, dom_1.h)('div', { class: 'inline', style: 'margin-top:10px' }, btn), done));
        }
        modal(title, content) {
            const bg = (0, dom_1.h)('div', { class: 'modal-bg no-print' });
            const close = () => bg.remove();
            bg.addEventListener('click', (e) => {
                if (e.target === bg)
                    close();
            });
            bg.appendChild((0, dom_1.h)('div', { class: 'modal' }, (0, dom_1.h)('header', {}, (0, dom_1.h)('h3', {}, title), (0, dom_1.h)('span', { style: 'flex:1' }), (0, dom_1.h)('button', { class: 'btn ghost small', onclick: close }, 'Close')), content));
            (document.getElementById('suite-root')||document.body).appendChild(bg);
        }
    }
    exports.App = App;
});
define("src/standalone/main", ["require", "exports", "src/state/store", "src/ui/sections", "src/standalone/app"], function (require, exports, store_1, sections_2, app_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function boot() {
        const root = document.getElementById('root');
        if (!root)
            return;
        const store = new store_1.ScenarioStore();
        const app = new app_1.App(root, store);
        // Exposed so automated tests (and power users) can drive the engine directly.
        window.mortgageSuite = { store, app, sectionIds: sections_2.SECTION_IDS };
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    }
    else {
        boot();
    }
});
